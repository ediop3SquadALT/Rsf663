#!/bin/bash

sudo apt update && sudo apt install -y \
    python2 python3 python3-pip python-pip \
    python2-dev python3-dev libssl-dev libffi-dev \
    build-essential

sudo python2 -m pip install --upgrade pip
sudo python3 -m pip install --upgrade pip

sudo python2 -m pip install requests paramiko telnetlib pycrypto pycryptodome pysnmp ftplib httpbin pyopenssl ndg-httpsclient pyasn1 pymysql pymssql psycopg2

sudo python3 -m pip install requests paramiko pycryptodomex pysnmp ftplib httpbin pyopenssl ndg-httpsclient pyasn1 cryptography pymysql pymssql psycopg2 bleak sockets

# ok lol
echo "Setup complete!"
echo "Setup done. Now press Enter to exit and run the framework by using bash rsf663.sh"
read -p "Press Enter to exit and run the framework..."

