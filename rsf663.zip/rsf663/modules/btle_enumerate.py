#!/usr/bin/env python3
# rsf scanners module
# rsf scanner module
# rsf exploit module
# rsf663 framework
# descriptiom: bluetooth enumeration
import sys
import asyncio
from bleak import BleakScanner, BleakClient


class Exploit:
    """
    Bluetooth LE Enumerator
    """

    def __init__(self, target=""):
        self.target = target

    async def btle_scan(self):
        print(f"[*] Scanning for device {self.target}...")
        devices = await BleakScanner.discover()
        for device in devices:
            if device.address.lower() == self.target.lower():
                return device
        return None

    async def run(self):
        device = await self.btle_scan()
        if not device:
            print(f"[!] Device {self.target} not found during scan.")
            return

        print(f"[+] Found device: {device.name} ({device.address})")

        try:
            async with BleakClient(device) as client:
                connected = await client.is_connected()
                if not connected:
                    print(f"[!] Failed to connect to {self.target}")
                    return

                print("[+] Connected")
                print("[*] Enumerating services and characteristics:")

                for service in client.services:
                    print(f"  Service: {service.uuid} - {service.description}")
                    for char in service.characteristics:
                        props = ','.join(char.properties)
                        try:
                            val = await client.read_gatt_char(char.uuid)
                            try:
                                val_str = val.decode('utf-8').strip()
                                if len(val_str) > 30 or not val_str.isprintable():
                                    val_str = val.hex()
                            except Exception:
                                val_str = val.hex()
                        except Exception:
                            val_str = "<no read permission>"
                        print(f"    Characteristic: {char.uuid} (Properties: {props}) Value: {val_str}")

                print("[+] Done.")

        except Exception as e:
            print(f"[!] Error during BLE interaction: {e}")


def main():
    if len(sys.argv) != 2:
        print(f"Usage: python3 {sys.argv[0]} <MAC_ADDRESS>")
        sys.exit(1)

    mac_address = sys.argv[1]
    exploit = Exploit(mac_address)
    asyncio.run(exploit.run())


if __name__ == "__main__":
    main()

