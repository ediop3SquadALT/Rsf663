# rsf exploit module
import re
import socket
import sys

def print_status(msg):
    print("[*] " + msg)

def print_error(msg):
    print("[!] " + msg)

def send_msearch(target, port=1900, timeout=3):
    try:
        socket.inet_pton(socket.AF_INET, target)
        family = socket.AF_INET
        addr_tuple = (target, port)
        host_header = f"{target}:{port}"
    except OSError:
        try:
            socket.inet_pton(socket.AF_INET6, target)
            family = socket.AF_INET6
            host_header = f"[{target}]:{port}"
            addr_tuple = (target, port, 0, 0)
        except OSError:
            print_error("Invalid IP address format")
            return

    request = (
        "M-SEARCH * HTTP/1.1\r\n"
        f"HOST: {host_header}\r\n"
        'MAN: "ssdp:discover"\r\n'
        "MX: 2\r\n"
        "ST: upnp:rootdevice\r\n\r\n"
    ).encode("utf-8")

    sock = socket.socket(family, socket.SOCK_DGRAM)
    sock.settimeout(timeout)

    try:
        sock.sendto(request, addr_tuple)
        response, _ = sock.recvfrom(1024)
    except socket.timeout:
        print_error("Target did not respond to M-SEARCH request")
        return
    except Exception as e:
        print_error(f"Socket error: {e}")
        return
    finally:
        sock.close()

    response = response.decode("utf-8", errors="ignore")

    info = {}
    regexps = {
        "server": r"Server:\s*(.*?)\r\n",
        "location": r"Location:\s*(.*?)\r\n",
        "usn": r"USN:\s*(.*?)\r\n",
    }

    for key, pattern in regexps.items():
        res = re.findall(pattern, response, re.IGNORECASE)
        info[key] = res[0] if res else ""

    print_status(f"{target}:{port} | {info['server']} | {info['location']} | {info['usn']}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print(f"Usage: python3 {sys.argv[0]} <Target IP>")
        sys.exit(1)

    target_ip = sys.argv[1]
    send_msearch(target_ip)

