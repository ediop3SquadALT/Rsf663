import imp
import socket
import urllib2
from os import listdir
from os.path import isfile, join


class Exploit(object):
    """
    AutoPwn - Automatic Scanner for known vendor-based exploits.
    """

    __info__ = {
        'name': 'AutoPwn',
        'description': 'Scanner module for all vulnerabilities.',
        'authors': [
            'Marcin Bury <marcin.bury[at]reverse-shell.com>',
        ],
        'references': (
            '',
        ),
        'devices': (
            'Multi',
        ),
    }

    target = ''
    port = 80

    def run(self):
        rootpath = '/rsf663/modules/'

        print("[*] Scanning router headers to detect vendor...")
        vendor = None
        try:
            url = "http://{}:{}/".format(self.target, self.port)
            req = urllib2.Request(url)
            res = urllib2.urlopen(req, timeout=5)
            headers = res.info()

            header_str = str(headers)
            for known_vendor in ["tplink", "dlink", "netgear", "huawei", "asus", "zyxel", "mikrotik"]:
                if known_vendor in header_str.lower():
                    vendor = known_vendor
                    break

            if vendor:
                print("[+] Detected vendor: {}".format(vendor))
            else:
                print("[-] Could not detect vendor from headers.")
        except Exception as e:
            print("[-] Failed to connect or fetch headers: {}".format(e))

        print("[*] Searching for matching modules...")

        if vendor:
            modules = [
                f.replace(".py", "")
                for f in listdir(rootpath)
                if isfile(join(rootpath, f)) and vendor in f.lower() and f.endswith(".py") and f != "__init__.py"
            ]
        else:
            modules = []

        if not modules:
            print("[*] Falling back to scanning all modules.")
            modules = [
                f.replace(".py", "")
                for f in listdir(rootpath)
                if isfile(join(rootpath, f)) and f.endswith(".py") and f != "__init__.py"
            ]

        print("[*] Found {} module(s) for scanning.".format(len(modules)))

        vulnerabilities = []

        for module_name in modules:
            module_path = join(rootpath, module_name + ".py")
            try:
                module = imp.load_source('module', module_path)
                exploit = module.Exploit()

                exploit.target = self.target
                exploit.port = self.port

                response = exploit.check()

                if response is True:
                    print("[+] {} is vulnerable".format(module_name))
                    vulnerabilities.append(module_name)
                elif response is False:
                    print("[-] {} is not vulnerable".format(module_name))
                else:
                    print("[*] {} could not be verified".format(module_name))
            except Exception as e:
                print("[-] Error loading {}: {}".format(module_name, e))

        if vulnerabilities:
            print("\n[+] Device is vulnerable!")
            for v in vulnerabilities:
                print(" - {}".format(v))
        else:
            print("\n[-] Device is not vulnerable to any exploits.")

    def check(self):
        raise NotImplementedError("Check method is not available")

