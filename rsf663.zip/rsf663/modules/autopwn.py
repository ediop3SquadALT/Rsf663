#!/usr/bin/env python3
import os
import socket
import threading
import requests
from requests.exceptions import RequestException
import paramiko
import ftplib
import telnetlib
import urllib.parse
import re
import xml.etree.ElementTree as ET
import subprocess
from queue import Queue
import json

class Colors:
    INFO = '\033[94m'
    SUCCESS = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    END = '\033[0m'

class RouterScanner:
    def __init__(self):
        self.target = os.getenv('target')
        if not self.target:
            raise ValueError("Target not set. Use 'set target <IP>' in shell")
        
        self.threads = int(os.getenv('threads', '8'))
        self.vulnerabilities = []
        self.credentials_found = []
        
        self.ports = {
            'http': int(os.getenv('http_port', '80')),
            'https': int(os.getenv('https_port', '443')),
            'ftp': int(os.getenv('ftp_port', '21')),
            'ssh': int(os.getenv('ssh_port', '22')),
            'telnet': int(os.getenv('telnet_port', '23')),
            'upnp': int(os.getenv('upnp_port', '1900')),
            'tftp': int(os.getenv('tftp_port', '69')),
            'smb': int(os.getenv('smb_port', '445')),
            'rtsp': int(os.getenv('rtsp_port', '554')),
            'vnc': int(os.getenv('vnc_port', '5900')),
            'mysql': int(os.getenv('mysql_port', '3306')),
            'mssql': int(os.getenv('mssql_port', '1433')),
            'postgres': int(os.getenv('postgres_port', '5432'))
        }
        
        self.common_credentials = [
            ('admin', 'admin'), ('admin', 'password'), ('root', 'root'),
            ('root', 'password'), ('user', 'user'), ('admin', ''), ('root', ''),
            
            ('cisco', 'cisco'), ('admin', 'cisco'), ('admin', 'admin'),
            
            ('admin', ''), ('user', ''), ('Admin', 'admin'),
            
            ('admin', 'password'), ('admin', '1234'), 
            
            ('admin', 'admin'), ('admin', '1234'),
            
            ('admin', '1234'), ('admin', 'zyad1234'),
            
            ('admin', 'admin'), ('root', 'admin'),
            
            ('admin', ''), ('admin', 'admin')
        ]
        
        self.router_paths = [
            '/', '/admin', '/login', '/config', '/router', '/cgi-bin', '/main.html',
            '/status', '/info', '/setup', '/management', '/gui', '/web', '/webadmin',
            '/adm', '/home', '/index', '/Index', '/INDEX', '/admin.html', '/Admin.html',
            '/login.html', '/Login.html', '/config.html', '/router.html', '/main.htm',
            '/status.htm', '/info.htm', '/setup.htm', '/management.htm', '/gui.htm',
            '/web.htm', '/webadmin.htm', '/adm.htm', '/home.htm', '/index.htm'
        ]

    def print_info(self, message):
        print(f"{Colors.INFO}[*]{Colors.END} {message}")

    def print_success(self, message):
        print(f"{Colors.SUCCESS}[+]{Colors.END} {message}")

    def print_warning(self, message):
        print(f"{Colors.WARNING}[!]{Colors.END} {message}")

    def print_fail(self, message):
        print(f"{Colors.FAIL}[-]{Colors.END} {message}")

    def port_open(self, port):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(1)
            result = sock.connect_ex((self.target, port))
            sock.close()
            return result == 0
        except socket.error:
            return False

    def http_checks(self):
        if self.port_open(self.ports['http']):
            for path in self.router_paths:
                try:
                    url = f"http://{self.target}:{self.ports['http']}{path}"
                    r = requests.get(url, timeout=3)
                    if r.status_code == 200:
                        self.print_success(f"HTTP interface exposed: {url}")
                        self.vulnerabilities.append(('HTTP', self.ports['http'], 'Web interface exposed'))
                        self.check_http_auth(url)
                        self.check_http_vulns(url, r.text)
                        self.check_router_model(r.text)
                        break
                except RequestException:
                    continue

        if self.port_open(self.ports['https']):
            for path in self.router_paths:
                try:
                    url = f"https://{self.target}:{self.ports['https']}{path}"
                    r = requests.get(url, timeout=3, verify=False)
                    if r.status_code == 200:
                        self.print_success(f"HTTPS interface exposed: {url}")
                        self.vulnerabilities.append(('HTTPS', self.ports['https'], 'Web interface exposed'))
                        self.check_http_auth(url)
                        self.check_http_vulns(url, r.text)
                        self.check_router_model(r.text)
                        break
                except RequestException:
                    continue

    def check_http_auth(self, url):
        for cred in self.common_credentials:
            try:
                r = requests.get(url, auth=cred, timeout=3, verify=False)
                if r.status_code == 200:
                    self.print_success(f"HTTP auth works: {cred[0]}/{cred[1]}")
                    self.credentials_found.append(('HTTP', self.ports['http'], cred[0], cred[1]))
            except RequestException:
                continue

    def check_http_vulns(self, url, response_text):
        firmware_patterns = {
            'DD-WRT': 'DD-WRT',
            'Tomato': 'Tomato',
            'OpenWrt': 'OpenWrt',
            'AsusWRT': 'AsusWRT',
            'RouterOS': 'RouterOS',
            'Linksys': 'Linksys',
            'Netgear': 'Netgear',
            'TP-Link': 'TP-Link',
            'D-Link': 'D-Link',
            'ZyXEL': 'ZyXEL',
            'Huawei': 'Huawei',
            'MikroTik': 'MikroTik'
        }

        for vendor, pattern in firmware_patterns.items():
            if re.search(pattern, response_text, re.IGNORECASE):
                self.print_info(f"Possible {vendor} router detected")
                self.vulnerabilities.append(('HTTP', self.ports['http'], f'{vendor} router detected'))

        if any(x in response_text.lower() for x in ['cgi-bin', '/cgi-bin/']):
            self.print_warning("CGI-BIN directory found - potential vulnerability")
            self.vulnerabilities.append(('HTTP', self.ports['http'], 'CGI-BIN directory exposed'))

        if 'phpinfo()' in response_text.lower():
            self.print_warning("PHPInfo detected - potential information disclosure")
            self.vulnerabilities.append(('HTTP', self.ports['http'], 'PHPInfo exposed'))

    def check_router_model(self, response_text):
        model_patterns = [
            r'Model[\s]*:[\s]*([^\s<]+)',  # Model: XYZ123
            r'Product[\s]*:[\s]*([^\s<]+)',  # Product: ABC456
            r'router_model[\s]*=[\s]*["\']([^"\']+)',  # router_model="XYZ"
            r'<title>([^<]+)</title>'  # <title>D-Link DIR-615</title>
        ]

        for pattern in model_patterns:
            match = re.search(pattern, response_text, re.IGNORECASE)
            if match:
                model = match.group(1).strip()
                self.print_info(f"Possible router model detected: {model}")
                self.vulnerabilities.append(('HTTP', self.ports['http'], f'Model detected: {model}'))
                break

    def ftp_checks(self):
        if not self.port_open(self.ports['ftp']):
            return

        try:
            ftp = ftplib.FTP()
            ftp.connect(self.target, self.ports['ftp'], timeout=3)
            try:
                ftp.login()
                self.print_success(f"FTP anonymous login allowed")
                self.vulnerabilities.append(('FTP', self.ports['ftp'], 'Anonymous login allowed'))
                ftp.quit()
                return
            except ftplib.error_perm:
                pass

            for cred in self.common_credentials:
                try:
                    ftp.login(cred[0], cred[1])
                    self.print_success(f"FTP credentials work: {cred[0]}/{cred[1]}")
                    self.credentials_found.append(('FTP', self.ports['ftp'], cred[0], cred[1]))
                    ftp.quit()
                    break
                except ftplib.error_perm:
                    continue
        except Exception as e:
            self.print_fail(f"FTP check failed: {str(e)}")

    def ssh_checks(self):
        if not self.port_open(self.ports['ssh']):
            return

        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        
        for cred in self.common_credentials:
            try:
                ssh.connect(self.target, port=self.ports['ssh'], 
                          username=cred[0], password=cred[1], 
                          timeout=3, banner_timeout=3)
                self.print_success(f"SSH credentials work: {cred[0]}/{cred[1]}")
                self.credentials_found.append(('SSH', self.ports['ssh'], cred[0], cred[1]))
                
                try:
                    stdin, stdout, stderr = ssh.exec_command('uname -a', timeout=2)
                    output = stdout.read().decode().strip()
                    if output:
                        self.print_info(f"SSH banner: {output}")
                        self.vulnerabilities.append(('SSH', self.ports['ssh'], f'SSH banner: {output}'))
                except:
                    pass
                
                ssh.close()
                break
            except (paramiko.AuthenticationException, paramiko.SSHException, socket.error):
                continue
            except Exception as e:
                self.print_fail(f"SSH check error: {str(e)}")
                break

    def telnet_checks(self):
        if not self.port_open(self.ports['telnet']):
            return

        for cred in self.common_credentials:
            try:
                tn = telnetlib.Telnet(self.target, self.ports['telnet'], timeout=3)
                
                tn.read_until(b"login: ", timeout=2)
                tn.write(cred[0].encode('ascii') + b"\n")
                tn.read_until(b"Password: ", timeout=2)
                tn.write(cred[1].encode('ascii') + b"\n")
                
                result = tn.expect([b"#", b"\$", b">"], timeout=2)
                if result[0] >= 0:
                    self.print_success(f"Telnet credentials work: {cred[0]}/{cred[1]}")
                    self.credentials_found.append(('Telnet', self.ports['telnet'], cred[0], cred[1]))
                    
                    tn.write(b"uname -a\n")
                    tn.write(b"cat /etc/passwd\n")
                    output = tn.read_very_eager().decode(errors='ignore')
                    if output:
                        self.print_info(f"Telnet output: {output[:200]}...")
                        self.vulnerabilities.append(('Telnet', self.ports['telnet'], 'Command execution possible'))
                    
                    tn.close()
                    break
                    
                tn.close()
            except (EOFError, ConnectionRefusedError, socket.timeout):
                continue
            except Exception as e:
                self.print_fail(f"Telnet check error: {str(e)}")
                break

    def upnp_checks(self):
        if not self.port_open(self.ports['upnp']):
            return

        try:
            upnp_discover = (
                'M-SEARCH * HTTP/1.1\r\n'
                'HOST: 239.255.255.250:1900\r\n'
                'MAN: "ssdp:discover"\r\n'
                'MX: 2\r\n'
                'ST: upnp:rootdevice\r\n'
                '\r\n'
            )

            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.settimeout(2)
            sock.sendto(upnp_discover.encode(), (self.target, self.ports['upnp']))
            
            try:
                data, addr = sock.recvfrom(4096)
                self.print_success("UPNP service discovered")
                self.vulnerabilities.append(('UPNP', self.ports['upnp'], 'Service discovered'))
                
                response = data.decode(errors='ignore')
                if 'Server:' in response:
                    server = response.split('Server:')[1].split('\r\n')[0].strip()
                    self.print_info(f"UPNP Server: {server}")
                    self.vulnerabilities.append(('UPNP', self.ports['upnp'], f'Server: {server}'))
            except socket.timeout:
                pass
            sock.close()
        except Exception as e:
            self.print_fail(f"UPNP check failed: {str(e)}")

    def tftp_checks(self):
        if not self.port_open(self.ports['tftp']):
            return

        try:
            common_files = [
                'config.xml', 'configuration.cfg', 'router.cfg',
                'backup.cfg', 'startup-config', 'running-config'
            ]
            
            for filename in common_files:
                try:
                    result = subprocess.run(
                        ['tftp', self.target, '-c', f'get {filename}'],
                        timeout=3,
                        capture_output=True
                    )
                    
                    if os.path.exists(filename):
                        self.print_success(f"TFTP file downloaded: {filename}")
                        self.vulnerabilities.append(('TFTP', self.ports['tftp'], f'File downloaded: {filename}'))
                        os.remove(filename)
                        break
                except:
                    continue
        except Exception as e:
            self.print_fail(f"TFTP check failed: {str(e)}")

    def smb_checks(self):
        if not self.port_open(self.ports['smb']):
            return

        try:
            result = subprocess.run(
                ['smbclient', '-L', f'//{self.target}', '-N'],
                timeout=5,
                capture_output=True
            )
            
            if result.returncode == 0:
                output = result.stdout.decode(errors='ignore')
                self.print_success("SMB shares accessible anonymously")
                self.vulnerabilities.append(('SMB', self.ports['smb'], 'Anonymous access'))
                
                shares = re.findall(r'([^\s]+)\s+.*', output)
                for share in shares:
                    if any(x in share.lower() for x in ['admin', 'config', 'backup']):
                        self.print_info(f"Interesting SMB share: {share}")
                        self.vulnerabilities.append(('SMB', self.ports['smb'], f'Share found: {share}'))
        except Exception as e:
            self.print_fail(f"SMB check failed: {str(e)}")

    def rtsp_checks(self):
        if not self.port_open(self.ports['rtsp']):
            return

        try:
            rtsp_url = f"rtsp://{self.target}:{self.ports['rtsp']}/"
            result = subprocess.run(
                ['ffprobe', rtsp_url],
                timeout=5,
                capture_output=True
            )
            
            if result.returncode == 0:
                self.print_success("RTSP stream accessible")
                self.vulnerabilities.append(('RTSP', self.ports['rtsp'], 'Stream accessible'))
        except Exception as e:
            self.print_fail(f"RTSP check failed: {str(e)}")

    def vnc_checks(self):
        if not self.port_open(self.ports['vnc']):
            return

        try:
            vnc = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            vnc.settimeout(3)
            vnc.connect((self.target, self.ports['vnc']))
            
            data = vnc.recv(1024)
            if b'RFB' in data:
                self.print_success("VNC service detected")
                self.vulnerabilities.append(('VNC', self.ports['vnc'], 'Service detected'))
                
                if b'Authentication' not in data:
                    self.print_warning("VNC may not require authentication")
                    self.vulnerabilities.append(('VNC', self.ports['vnc'], 'No authentication'))
            vnc.close()
        except Exception as e:
            self.print_fail(f"VNC check failed: {str(e)}")

    def database_checks(self):
        if self.port_open(self.ports['mysql']):
            for cred in self.common_credentials:
                try:
                    import pymysql
                    conn = pymysql.connect(
                        host=self.target,
                        port=self.ports['mysql'],
                        user=cred[0],
                        password=cred[1],
                        connect_timeout=3
                    )
                    self.print_success(f"MySQL credentials work: {cred[0]}/{cred[1]}")
                    self.credentials_found.append(('MySQL', self.ports['mysql'], cred[0], cred[1]))
                    conn.close()
                    break
                except:
                    continue

        if self.port_open(self.ports['mssql']):
            for cred in self.common_credentials:
                try:
                    import pymssql
                    conn = pymssql.connect(
                        server=self.target,
                        port=self.ports['mssql'],
                        user=cred[0],
                        password=cred[1],
                        login_timeout=3
                    )
                    self.print_success(f"MSSQL credentials work: {cred[0]}/{cred[1]}")
                    self.credentials_found.append(('MSSQL', self.ports['mssql'], cred[0], cred[1]))
                    conn.close()
                    break
                except:
                    continue

        if self.port_open(self.ports['postgres']):
            for cred in self.common_credentials:
                try:
                    import psycopg2
                    conn = psycopg2.connect(
                        host=self.target,
                        port=self.ports['postgres'],
                        user=cred[0],
                        password=cred[1],
                        connect_timeout=3
                    )
                    self.print_success(f"PostgreSQL credentials work: {cred[0]}/{cred[1]}")
                    self.credentials_found.append(('PostgreSQL', self.ports['postgres'], cred[0], cred[1]))
                    conn.close()
                    break
                except:
                    continue

    def run_scan(self):
        self.print_info(f"Starting router scan against {self.target}")
        
        checks = [
            self.http_checks,
            self.ftp_checks,
            self.ssh_checks,
            self.telnet_checks,
            self.upnp_checks,
            self.tftp_checks,
            self.smb_checks,
            self.rtsp_checks,
            self.vnc_checks,
            self.database_checks
        ]
        
        threads = []
        for check in checks:
            t = threading.Thread(target=check)
            t.start()
            threads.append(t)
        
        for t in threads:
            t.join()
        
        self.print_results()

    def print_results(self):
        self.print_info("\n=== Scan Results ===")
        
        if self.vulnerabilities:
            self.print_success("\nVulnerabilities found:")
            for vuln in self.vulnerabilities:
                print(f"  - {vuln[0]} (port {vuln[1]}): {vuln[2]}")
        else:
            self.print_fail("\nNo vulnerabilities found")
            
        if self.credentials_found:
            self.print_success("\nCredentials found:")
            for cred in self.credentials_found:
                print(f"  - {cred[0]} (port {cred[1]}): {cred[2]}/{cred[3]}")
        else:
            self.print_fail("\nNo default credentials found")

def main():
    try:
        scanner = RouterScanner()
        scanner.run_scan()
    except ValueError as e:
        print(f"Error: {str(e)}")
    except Exception as e:
        print(f"Unexpected error: {str(e)}")

if __name__ == '__main__':
    main()
