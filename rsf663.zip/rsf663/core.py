#!/usr/bin/env python3

import os
import sys

# Define the main project directory (rsf663)
PROJECT_DIR = os.path.expanduser("~/rsf663")

# Define the modules directory
MODULES_DIR = os.path.join(PROJECT_DIR, "modules")

# The necessary imports to prepend to each module file
IMPORTS = """import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from rsf663.core import Exploit, Protocol
"""

def remove_existing_imports(content):
    """Removes any existing sys.path.insert, import sys, and import os from the content."""
    new_content = []
    skip_lines = ['import sys', 'import os', 'sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))', 'from rsf663.core import Exploit, Protocol']
    for line in content:
        if not any(skip in line for skip in skip_lines):
            new_content.append(line)
    return new_content

def add_imports_to_file(file_path):
    """Adds necessary imports to a Python file if they're not already present."""
    try:
        with open(file_path, 'r') as file:
            content = file.readlines()

        # Remove any duplicate import statements and sys.path.insert
        content = remove_existing_imports(content)

        # Prepend the necessary imports
        with open(file_path, 'w') as file:
            file.write(IMPORTS + "\n" + "".join(content))
            print(f"Added necessary imports to {file_path}")

    except Exception as e:
        print(f"Error processing {file_path}: {e}")

def set_sys_path_for_module():
    """Ensures that the rsf663 module is found by the Python interpreter."""
    if PROJECT_DIR not in sys.path:
        sys.path.insert(0, PROJECT_DIR)
        print(f"Added {PROJECT_DIR} to sys.path")

def main():
    """Main function to loop through all .py files and add imports."""
    set_sys_path_for_module()  # Ensure the main rsf663 directory is in sys.path
    print(f"[*] Scanning modules in {MODULES_DIR}")

    if not os.path.isdir(MODULES_DIR):
        print(f"[-] Module directory not found: {MODULES_DIR}")
        return

    # Loop through all Python files in the modules directory
    for filename in os.listdir(MODULES_DIR):
        if filename.endswith(".py"):
            file_path = os.path.join(MODULES_DIR, filename)
            print(f"\n[+] Processing module: {file_path}")
            add_imports_to_file(file_path)

if __name__ == "__main__":
    main()

